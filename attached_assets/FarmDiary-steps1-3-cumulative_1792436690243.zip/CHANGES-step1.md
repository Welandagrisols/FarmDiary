# Step 1: security hardening (no new features)

Copy these files over your project, keeping the same paths:

| File | Change |
|---|---|
| `.gitignore` | Ignores `*.keystore`, `credentials.json`, `.env.*` so they can't be committed again |
| `scripts/rls-hardening.sql` | NEW. Run in Supabase after `supabase-patch-fixed.sql` |
| `scripts/enable-rls.sql` | Marked DEPRECATED (do not run) |
| `lib/supabase-storage.ts` | Removed unused `claimUnownedFarms()` |

## What the SQL fixes
1. Anyone could register their own profile as `admin`. Now only `farmer`.
2. A trigger blocks role changes by non-admins.
3. Only an admin can move a farm to another owner.
4. `app_meta` table now has row-level security.

## Not done yet
- `.gitignore` does not remove files already committed. Later: `git rm --cached farm-diary.keystore credentials.json`, then purge history, then move signing to EAS.
- New users have no farm-setup onboarding (dashboard is empty until they create a farm). Step 2.
- The database was not touched; I had no Supabase access. Run the SQL yourself and the verify queries at the bottom.
