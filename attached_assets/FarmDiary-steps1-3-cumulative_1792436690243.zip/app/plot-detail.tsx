import React from "react";
import { View, Text, ScrollView, Pressable, Alert, Platform, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s, toneColors } from "@/constants/formStyles";
import { getTemplate } from "@/constants/farmData";
import { getCropFamily } from "@/constants/cropTemplates";
import { formatDate } from "@/lib/storage";
import { findings, paramRows, retestStatus, seasonsForPlot, testsForPlot } from "@/lib/soil";

export default function PlotDetailScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { plots, soilTests, seasons, removePlot } = useFarm();
  const plot = plots.find((p) => p.id === id);
  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const today = new Date().toISOString().split("T")[0];

  if (!plot) {
    return (
      <View style={[s.container, { paddingTop: topPadding }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={24} color={COLORS.text} /></Pressable>
          <Text style={s.headerTitle}>Plot</Text>
          <View style={s.headerSide} />
        </View>
        <View style={s.scrollContent}><Text style={s.body}>This plot could not be found.</Text></View>
      </View>
    );
  }

  const tests = testsForPlot(plot.id, soilTests);
  const latest = tests[0];
  const rt = retestStatus(plot, soilTests, today);
  const cycles = seasonsForPlot(plot.id, seasons);
  const flagged = latest ? findings(latest) : [];
  const rtTone = rt.status === "due" ? "bad" : rt.status === "soon" ? "warn" : rt.status === "ok" ? "good" : "neutral";
  const rtc = toneColors(rtTone);

  const confirmDelete = () => {
    Alert.alert("Delete plot", `Delete "${plot.name}" and its ${tests.length} soil test${tests.length === 1 ? "" : "s"}? Crop cycles stay but lose the plot link.`, [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => { await removePlot(plot.id); router.back(); } },
    ]);
  };

  return (
    <View style={[s.container, { paddingTop: topPadding }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={24} color={COLORS.text} /></Pressable>
        <Text style={s.headerTitle} numberOfLines={1}>{plot.name}</Text>
        <Pressable style={s.headerSide} hitSlop={12} onPress={() => router.push({ pathname: "/add-plot", params: { id: plot.id } })}>
          <Ionicons name="create-outline" size={22} color={COLORS.primary} />
        </Pressable>
      </View>
      <ScrollView style={s.scroll} contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + 40 }]}>
        <View style={s.section}>
          <Text style={s.body}>{[plot.acres ? `${plot.acres} acres` : null, plot.water_source, `retest every ${plot.retest_months} months`].filter(Boolean).join(" · ")}</Text>
          {plot.notes ? <Text style={s.hint}>{plot.notes}</Text> : null}
          <View style={[s.pill, { backgroundColor: rtc.bg, alignSelf: "flex-start" }]}>
            <Text style={[s.pillText, { color: rtc.fg }]}>
              {rt.status === "none" ? "No soil test yet" : rt.status === "due" ? `Retest due (was due ${formatDate(rt.dueDate)})` : `Next test ${formatDate(rt.dueDate)}`}
            </Text>
          </View>
          <Pressable style={s.primaryBtn} onPress={() => router.push({ pathname: "/add-soil-test", params: { plotId: plot.id } })}>
            <Ionicons name="flask-outline" size={18} color={COLORS.white} />
            <Text style={s.primaryBtnText}>Add soil test</Text>
          </Pressable>
        </View>

        {latest ? (
          <Pressable style={s.section} onPress={() => router.push({ pathname: "/soil-result", params: { id: latest.id } })}>
            <View style={local.rowBetween}>
              <Text style={s.sectionTitle}>Latest soil test · {formatDate(latest.test_date)}</Text>
              <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
            </View>
            {flagged.length ? (
              <View style={s.chipRow}>
                {flagged.map((r) => (
                  <View key={r.key} style={[s.pill, { backgroundColor: toneColors(r.tone).bg }]}>
                    <Text style={[s.pillText, { color: toneColors(r.tone).fg }]}>{r.label}: {r.cls}{r.estimated ? " (est.)" : ""}</Text>
                  </View>
                ))}
              </View>
            ) : (
              <Text style={s.body}>No problems flagged.</Text>
            )}
            <Text style={s.hint}>{(latest.plan || []).length} plan item{(latest.plan || []).length === 1 ? "" : "s"} · tap for full results and plan</Text>
          </Pressable>
        ) : null}

        {tests.length > 1 ? (
          <View style={s.section}>
            <Text style={s.sectionTitle}>Test history</Text>
            {tests.map((t) => {
              const ph = paramRows(t).find((r) => r.key === "ph");
              const oc = paramRows(t).find((r) => r.key === "organic_carbon");
              return (
                <Pressable key={t.id} style={local.rowBetween} onPress={() => router.push({ pathname: "/soil-result", params: { id: t.id } })}>
                  <Text style={s.body}>{formatDate(t.test_date)}</Text>
                  <Text style={s.hint}>{[ph ? `pH ${ph.value}` : null, oc ? `OC ${oc.value}%` : null].filter(Boolean).join(" · ")}</Text>
                </Pressable>
              );
            })}
          </View>
        ) : null}

        <View style={s.section}>
          <Text style={s.sectionTitle}>Crop cycles on this plot</Text>
          {cycles.length === 0 ? (
            <Text style={s.body}>None yet. Choose this plot when you start a season, or link an existing season in Season Control.</Text>
          ) : (
            cycles.map(({ season, sectionIds }) => {
              const t = getTemplate(season.template_id);
              const fam = getCropFamily(season.template_id);
              return (
                <View key={season.id} style={local.cycle}>
                  <Text style={local.cycleTitle}>{t.cropType} · {season.season_name}</Text>
                  <Text style={s.hint}>
                    {[
                      season.status === "closed" ? "Closed" : "Active",
                      sectionIds.map((x) => (x === "section-a" ? "Section A" : "Section B")).join(" + "),
                      fam ? fam.family : null,
                    ].filter(Boolean).join(" · ")}
                  </Text>
                </View>
              );
            })
          )}
        </View>

        <Pressable onPress={confirmDelete}><Text style={s.dangerText}>Delete this plot</Text></Pressable>
      </ScrollView>
    </View>
  );
}

const local = StyleSheet.create({
  rowBetween: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  cycle: { paddingVertical: 4, gap: 2 },
  cycleTitle: { fontFamily: "DMSans_600SemiBold", fontSize: 14, color: COLORS.text },
});
