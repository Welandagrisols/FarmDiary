import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Alert, Platform, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s, toneColors } from "@/constants/formStyles";
import { formatDate, formatKES, SoilPlanItem } from "@/lib/storage";
import { findings, paramRows } from "@/lib/soil";

const PRODUCTS = ["Agricultural lime", "Farm yard manure", "Compost", "NPK 23:23:0", "DAP", "CAN", "Urea"];

export default function SoilResultScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { soilTests, plots, editSoilTest, removeSoilTest } = useFarm();
  const test = soilTests.find((t) => t.id === id);
  const plot = test ? plots.find((p) => p.id === test.plot_id) : undefined;
  const topPadding = Platform.OS === "web" ? 67 : insets.top;

  const [adding, setAdding] = useState(false);
  const [crop, setCrop] = useState("");
  const [product, setProduct] = useState("");
  const [rate, setRate] = useState("");
  const [timing, setTiming] = useState("");
  const [cost, setCost] = useState("");
  const [saving, setSaving] = useState(false);

  if (!test) {
    return (
      <View style={[s.container, { paddingTop: topPadding }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={24} color={COLORS.text} /></Pressable>
          <Text style={s.headerTitle}>Soil Result</Text>
          <View style={s.headerSide} />
        </View>
        <View style={[s.scrollContent]}><Text style={s.body}>This soil test could not be found. It may have been deleted.</Text></View>
      </View>
    );
  }

  const rows = paramRows(test);
  const flagged = findings(test);
  const plan = test.plan || [];
  const planCost = plan.reduce((sum, p) => sum + (p.est_cost_kes || 0), 0);
  const cropChoices = (test.crops_intended || "").split(/[,/]| and /i).map((c) => c.trim()).filter(Boolean);
  const hasEstimates = rows.some((r) => r.estimated);

  const savePlan = async (next: SoilPlanItem[]) => {
    setSaving(true);
    try { await editSoilTest(test.id, { plan: next }); }
    catch (e: any) { Alert.alert("Could not save the plan", e?.message || "Please try again."); }
    finally { setSaving(false); }
  };

  const addItem = async () => {
    if (!product.trim()) return;
    const item: SoilPlanItem = {
      id: Math.random().toString(36).slice(2) + Date.now().toString(36),
      crop: crop.trim() || null,
      product: product.trim(),
      rate: rate.trim(),
      timing: timing.trim(),
      est_cost_kes: parseFloat(cost) > 0 ? parseFloat(cost) : null,
      notes: null,
    };
    await savePlan([...plan, item]);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setProduct(""); setRate(""); setTiming(""); setCost(""); setAdding(false);
  };

  const removeItem = (item: SoilPlanItem) => {
    Alert.alert("Remove plan item", `Remove "${item.product}"?`, [
      { text: "Cancel", style: "cancel" },
      { text: "Remove", style: "destructive", onPress: () => savePlan(plan.filter((p) => p.id !== item.id)) },
    ]);
  };

  const deleteTest = () => {
    Alert.alert("Delete soil test", "This removes the results and the plan. This cannot be undone.", [
      { text: "Cancel", style: "cancel" },
      { text: "Delete", style: "destructive", onPress: async () => { await removeSoilTest(test.id); router.back(); } },
    ]);
  };

  return (
    <View style={[s.container, { paddingTop: topPadding }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={24} color={COLORS.text} /></Pressable>
        <Text style={s.headerTitle}>Soil Result</Text>
        <Pressable style={s.headerSide} hitSlop={12} onPress={() => router.push({ pathname: "/add-soil-test", params: { id: test.id } })}>
          <Ionicons name="create-outline" size={22} color={COLORS.primary} />
        </Pressable>
      </View>
      <ScrollView style={s.scroll} contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + 40 }]} keyboardShouldPersistTaps="handled">
        <View style={s.section}>
          <Text style={local.plotName}>{plot?.name || "Plot"}</Text>
          <Text style={s.body}>
            Sampled {formatDate(test.test_date)}
            {test.report_date ? ` · reported ${formatDate(test.report_date)}` : ""}
          </Text>
          <Text style={s.hint}>
            {[test.lab, test.lab_no ? `Lab no. ${test.lab_no}` : null, test.sample_label, test.depth_cm ? `Depth ${test.depth_cm}` : null].filter(Boolean).join(" · ")}
          </Text>
          {test.crops_intended ? <Text style={s.body}>Crops to be grown: {test.crops_intended}</Text> : null}
        </View>

        <View style={[s.section, { backgroundColor: flagged.length ? COLORS.amberLight : COLORS.primarySurface }]}>
          <Text style={s.sectionTitle}>{flagged.length ? `${flagged.length} result${flagged.length > 1 ? "s" : ""} need attention` : "No problems flagged"}</Text>
          {flagged.length > 0 ? (
            <View style={s.chipRow}>
              {flagged.map((r) => {
                const c = toneColors(r.tone);
                return (
                  <View key={r.key} style={[s.pill, { backgroundColor: COLORS.white }]}>
                    <Text style={[s.pillText, { color: c.fg }]}>{r.label}: {r.cls}{r.estimated ? " (est.)" : ""}</Text>
                  </View>
                );
              })}
            </View>
          ) : (
            <Text style={s.body}>Every result with a class is in a good range. Check the lab recommendation below anyway.</Text>
          )}
        </View>

        <View style={s.section}>
          <Text style={s.sectionTitle}>Results</Text>
          {rows.map((r) => {
            const c = toneColors(r.tone);
            return (
              <View key={r.key} style={local.resRow}>
                <Text style={local.resLabel}>{r.label}</Text>
                <Text style={local.resValue}>{r.value}{r.unit ? ` ${r.unit}` : ""}</Text>
                <View style={[s.pill, { backgroundColor: c.bg, minWidth: 82, alignItems: "center" }]}>
                  <Text style={[s.pillText, { color: c.fg }]}>{r.cls ? `${r.cls}${r.estimated ? " (est.)" : ""}` : "—"}</Text>
                </View>
              </View>
            );
          })}
          {hasEstimates ? <Text style={s.hint}>"est." marks a class the app estimated because the lab report gave none. These are draft cut-offs; use your lab's own interpretation.</Text> : null}
        </View>

        {test.lab_recommendation ? (
          <View style={s.section}>
            <Text style={s.sectionTitle}>Lab recommendation</Text>
            <Text style={s.body}>{test.lab_recommendation}</Text>
          </View>
        ) : null}

        <View style={s.section}>
          <Text style={s.sectionTitle}>Fertilizer and lime plan</Text>
          <Text style={s.hint}>Turn the lab recommendation into steps for each crop. Rates are free text, e.g. "100 kg/acre" or "5 g/plant".</Text>
          {plan.length === 0 && !adding ? <Text style={s.body}>No plan items yet.</Text> : null}
          {plan.map((item) => (
            <View key={item.id} style={local.planItem}>
              <View style={{ flex: 1, gap: 2 }}>
                <Text style={local.planProduct}>{item.product}{item.crop ? ` · ${item.crop}` : ""}</Text>
                {item.rate ? <Text style={s.body}>{item.rate}</Text> : null}
                {item.timing ? <Text style={s.hint}>{item.timing}</Text> : null}
                {item.est_cost_kes ? <Text style={s.hint}>Est. {formatKES(item.est_cost_kes)}</Text> : null}
              </View>
              <Pressable hitSlop={10} onPress={() => removeItem(item)}>
                <Ionicons name="trash-outline" size={18} color={COLORS.textMuted} />
              </Pressable>
            </View>
          ))}
          {planCost > 0 ? <Text style={s.sectionTitle}>Estimated plan cost: {formatKES(planCost)}</Text> : null}

          {adding ? (
            <View style={{ gap: 10 }}>
              {cropChoices.length > 0 ? (
                <View style={s.field}>
                  <Text style={s.fieldLabel}>Crop</Text>
                  <View style={s.chipRow}>
                    {cropChoices.map((c) => (
                      <Pressable key={c} style={[s.chip, crop === c && s.chipActive]} onPress={() => setCrop(crop === c ? "" : c)}>
                        <Text style={[s.chipText, crop === c && s.chipTextActive]}>{c}</Text>
                      </Pressable>
                    ))}
                  </View>
                </View>
              ) : null}
              <View style={s.field}>
                <Text style={s.fieldLabel}>Product <Text style={{ color: COLORS.red }}>*</Text></Text>
                <View style={s.chipRow}>
                  {PRODUCTS.map((p) => (
                    <Pressable key={p} style={[s.chip, product === p && s.chipActive]} onPress={() => setProduct(p)}>
                      <Text style={[s.chipText, product === p && s.chipTextActive]}>{p}</Text>
                    </Pressable>
                  ))}
                </View>
                <TextInput style={s.input} value={product} onChangeText={setProduct} placeholder="or type a product" placeholderTextColor={COLORS.textMuted} />
              </View>
              <View style={s.field}>
                <Text style={s.fieldLabel}>Rate</Text>
                <TextInput style={s.input} value={rate} onChangeText={setRate} placeholder="e.g. 100 kg/acre" placeholderTextColor={COLORS.textMuted} />
              </View>
              <View style={s.field}>
                <Text style={s.fieldLabel}>When</Text>
                <TextInput style={s.input} value={timing} onChangeText={setTiming} placeholder="e.g. At least 2 months before planting" placeholderTextColor={COLORS.textMuted} />
              </View>
              <View style={s.field}>
                <Text style={s.fieldLabel}>Estimated cost (KES)</Text>
                <TextInput style={s.input} value={cost} onChangeText={setCost} placeholder="Optional" placeholderTextColor={COLORS.textMuted} keyboardType="decimal-pad" />
              </View>
              <Pressable style={[s.primaryBtn, !product.trim() && s.saveBtnDisabled]} disabled={!product.trim() || saving} onPress={addItem}>
                <Text style={s.primaryBtnText}>{saving ? "Saving..." : "Add to plan"}</Text>
              </Pressable>
              <Pressable onPress={() => setAdding(false)}><Text style={[s.dangerText, { color: COLORS.textSecondary }]}>Cancel</Text></Pressable>
            </View>
          ) : (
            <Pressable style={s.outlineBtn} onPress={() => setAdding(true)}>
              <Ionicons name="add" size={18} color={COLORS.primary} />
              <Text style={s.outlineBtnText}>Add plan item</Text>
            </Pressable>
          )}
        </View>

        {test.notes ? (
          <View style={s.section}>
            <Text style={s.sectionTitle}>Notes</Text>
            <Text style={s.body}>{test.notes}</Text>
          </View>
        ) : null}

        <Pressable onPress={deleteTest}><Text style={s.dangerText}>Delete this soil test</Text></Pressable>
      </ScrollView>
    </View>
  );
}

const local = StyleSheet.create({
  plotName: { fontFamily: "DMSans_700Bold", fontSize: 20, color: COLORS.text },
  resRow: { flexDirection: "row", alignItems: "center", gap: 8, paddingVertical: 2 },
  resLabel: { flex: 1.4, fontFamily: "DMSans_500Medium", fontSize: 14, color: COLORS.text },
  resValue: { flex: 1, fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.text, textAlign: "right" },
  planItem: {
    flexDirection: "row", alignItems: "flex-start", gap: 10, padding: 12, borderRadius: 10,
    backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border,
  },
  planProduct: { fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.text },
});
