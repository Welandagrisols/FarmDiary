import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Alert, Platform, KeyboardAvoidingView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s } from "@/constants/formStyles";

const WATER = ["Rain-fed", "Irrigated", "Drip"];
const RETEST = [6, 12, 24];

export default function AddPlotScreen() {
  const insets = useSafeAreaInsets();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { plots, createPlot, editPlot } = useFarm();
  const existing = id ? plots.find((p) => p.id === id) : undefined;

  const [name, setName] = useState(existing?.name || "");
  const [acres, setAcres] = useState(existing ? String(existing.acres) : "");
  const [water, setWater] = useState<string | null>(existing?.water_source || null);
  const [retest, setRetest] = useState(existing?.retest_months || 12);
  const [notes, setNotes] = useState(existing?.notes || "");
  const [saving, setSaving] = useState(false);

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const isValid = name.trim().length > 0;

  const handleSave = async () => {
    if (!isValid) return;
    setSaving(true);
    try {
      const data = {
        name: name.trim(),
        acres: parseFloat(acres) || 0,
        water_source: water,
        retest_months: retest,
        notes: notes.trim() || null,
      };
      if (existing) await editPlot(existing.id, data);
      else await createPlot(data);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      router.back();
    } catch (e: any) {
      Alert.alert("Could not save plot", e?.message || "Please check your connection and try again. If this keeps happening, the soil database update may not have been run yet.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <View style={[s.container, { paddingTop: topPadding }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}>
            <Ionicons name="arrow-back" size={24} color={COLORS.text} />
          </Pressable>
          <Text style={s.headerTitle}>{existing ? "Edit Plot" : "Add Plot"}</Text>
          <Pressable style={[s.saveBtn, !isValid && s.saveBtnDisabled]} onPress={handleSave} disabled={saving || !isValid}>
            <Text style={s.saveBtnText}>{saving ? "Saving..." : "Save"}</Text>
          </Pressable>
        </View>
        <ScrollView style={s.scroll} contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + 40 }]} keyboardShouldPersistTaps="handled">
          <View style={s.section}>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Plot name <Text style={{ color: COLORS.red }}>*</Text></Text>
              <TextInput style={s.input} value={name} onChangeText={setName} placeholder="e.g. Lower field, Block 3" placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Size (acres)</Text>
              <TextInput style={s.input} value={acres} onChangeText={setAcres} placeholder="e.g. 1.5" placeholderTextColor={COLORS.textMuted} keyboardType="decimal-pad" />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Water</Text>
              <View style={s.chipRow}>
                {WATER.map((w) => (
                  <Pressable key={w} style={[s.chip, water === w && s.chipActive]} onPress={() => setWater(water === w ? null : w)}>
                    <Text style={[s.chipText, water === w && s.chipTextActive]}>{w}</Text>
                  </Pressable>
                ))}
              </View>
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Retest the soil every</Text>
              <View style={s.chipRow}>
                {RETEST.map((m) => (
                  <Pressable key={m} style={[s.chip, retest === m && s.chipActive]} onPress={() => setRetest(m)}>
                    <Text style={[s.chipText, retest === m && s.chipTextActive]}>{m} months</Text>
                  </Pressable>
                ))}
              </View>
              <Text style={s.hint}>Intensive vegetable plots are usually retested more often than staple crops.</Text>
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Notes</Text>
              <TextInput style={[s.input, s.textArea]} value={notes} onChangeText={setNotes} placeholder="Slope, soil colour, drainage, history..." placeholderTextColor={COLORS.textMuted} multiline />
            </View>
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}
