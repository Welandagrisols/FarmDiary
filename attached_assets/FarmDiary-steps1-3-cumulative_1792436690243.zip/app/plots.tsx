import React, { useCallback, useState } from "react";
import { View, Text, ScrollView, Pressable, RefreshControl, Platform, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s, toneColors } from "@/constants/formStyles";
import { getTemplate } from "@/constants/farmData";
import { formatDate } from "@/lib/storage";
import { latestTest, paramRows, retestStatus, seasonsForPlot } from "@/lib/soil";

const todayStr = () => new Date().toISOString().split("T")[0];

export default function PlotsScreen() {
  const insets = useSafeAreaInsets();
  const { plots, soilTests, seasons, activeSeason, switchSeason, refreshSoil } = useFarm();
  const [refreshing, setRefreshing] = useState(false);
  const topPadding = Platform.OS === "web" ? 67 : insets.top;

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refreshSoil();
    setRefreshing(false);
  }, [refreshSoil]);

  const today = todayStr();
  const dueCount = plots.filter((p) => ["due", "soon"].includes(retestStatus(p, soilTests, today).status)).length;
  const unlinked = seasons.filter((x) => x.status !== "closed" && !x.section_a?.plot_id && !x.section_b?.plot_id);

  const openCycle = async (seasonId: string) => {
    Haptics.selectionAsync();
    await switchSeason(seasonId);
    router.replace("/(tabs)");
  };

  return (
    <View style={[s.container, { paddingTop: topPadding }]}>
      <View style={s.header}>
        <Pressable onPress={() => router.back()} hitSlop={12}><Ionicons name="arrow-back" size={24} color={COLORS.text} /></Pressable>
        <Text style={s.headerTitle}>Plots & Soil</Text>
        <Pressable style={s.headerSide} hitSlop={12} onPress={() => router.push("/add-plot")}>
          <Ionicons name="add-circle-outline" size={26} color={COLORS.primary} />
        </Pressable>
      </View>
      <ScrollView
        style={s.scroll}
        contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + 40 }]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
      >
        {plots.length === 0 ? (
          <View style={s.emptyCard}>
            <Ionicons name="map-outline" size={36} color={COLORS.primary} />
            <Text style={s.emptyTitle}>Add your first plot</Text>
            <Text style={[s.body, { textAlign: "center" }]}>
              A plot is a piece of land you keep growing on. Record soil tests for it, then link each crop cycle to it to see rotation and results over time.
            </Text>
            <Pressable style={s.primaryBtn} onPress={() => router.push("/add-plot")}>
              <Ionicons name="add" size={18} color={COLORS.white} />
              <Text style={s.primaryBtnText}>Add plot</Text>
            </Pressable>
          </View>
        ) : (
          <>
            <View style={local.summary}>
              <View style={local.sumItem}><Text style={local.sumNum}>{plots.length}</Text><Text style={s.hint}>Plots</Text></View>
              <View style={local.sumItem}><Text style={local.sumNum}>{soilTests.length}</Text><Text style={s.hint}>Soil tests</Text></View>
              <View style={local.sumItem}><Text style={[local.sumNum, dueCount > 0 && { color: COLORS.amber }]}>{dueCount}</Text><Text style={s.hint}>Retest due</Text></View>
            </View>

            {plots.map((plot) => {
              const last = latestTest(plot.id, soilTests);
              const rt = retestStatus(plot, soilTests, today);
              const phRow = last ? paramRows(last).find((r) => r.key === "ph") : undefined;
              const cycles = seasonsForPlot(plot.id, seasons).filter((c) => c.season.status !== "closed");
              const rtTone = rt.status === "due" ? "bad" : rt.status === "soon" ? "warn" : rt.status === "ok" ? "good" : "neutral";
              const rtColors = toneColors(rtTone);
              const rtText =
                rt.status === "none" ? "No soil test yet"
                : rt.status === "due" ? "Retest due"
                : rt.status === "soon" ? `Retest by ${formatDate(rt.dueDate)}`
                : `Next test ${formatDate(rt.dueDate)}`;
              return (
                <Pressable key={plot.id} style={s.section} onPress={() => router.push({ pathname: "/plot-detail", params: { id: plot.id } })}>
                  <View style={local.cardTop}>
                    <View style={{ flex: 1 }}>
                      <Text style={local.plotName}>{plot.name}</Text>
                      <Text style={s.hint}>{[plot.acres ? `${plot.acres} acres` : null, plot.water_source].filter(Boolean).join(" · ") || "No details yet"}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
                  </View>
                  <View style={s.chipRow}>
                    <View style={[s.pill, { backgroundColor: rtColors.bg }]}><Text style={[s.pillText, { color: rtColors.fg }]}>{rtText}</Text></View>
                    {phRow ? (
                      <View style={[s.pill, { backgroundColor: toneColors(phRow.tone).bg }]}>
                        <Text style={[s.pillText, { color: toneColors(phRow.tone).fg }]}>pH {phRow.value}{phRow.cls ? ` · ${phRow.cls}` : ""}</Text>
                      </View>
                    ) : null}
                  </View>
                  {cycles.length > 0 ? (
                    <View style={{ gap: 6 }}>
                      <Text style={s.fieldLabel}>Current crop cycles</Text>
                      <View style={s.chipRow}>
                        {cycles.map(({ season }) => (
                          <Pressable key={season.id} style={[s.chip, activeSeason?.id === season.id && s.chipActive]} onPress={() => openCycle(season.id)}>
                            <Text style={[s.chipText, activeSeason?.id === season.id && s.chipTextActive]}>
                              {getTemplate(season.template_id).cropType} · {season.season_name}
                            </Text>
                          </Pressable>
                        ))}
                      </View>
                    </View>
                  ) : (
                    <Text style={s.hint}>No active crop cycle linked to this plot</Text>
                  )}
                </Pressable>
              );
            })}

            {unlinked.length > 0 ? (
              <View style={[s.section, { backgroundColor: COLORS.amberLight }]}>
                <Text style={s.sectionTitle}>{unlinked.length} active cycle{unlinked.length > 1 ? "s" : ""} not linked to a plot</Text>
                <Text style={s.body}>Link them from More, then Season Control, then Edit, so rotation checks and soil history include them.</Text>
              </View>
            ) : null}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const local = StyleSheet.create({
  summary: {
    flexDirection: "row", backgroundColor: COLORS.cardBg, borderRadius: 14, borderWidth: 1, borderColor: COLORS.border, padding: 14,
  },
  sumItem: { flex: 1, alignItems: "center", gap: 2 },
  sumNum: { fontFamily: "DMSans_700Bold", fontSize: 22, color: COLORS.primary },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 8 },
  plotName: { fontFamily: "DMSans_700Bold", fontSize: 17, color: COLORS.text },
});
