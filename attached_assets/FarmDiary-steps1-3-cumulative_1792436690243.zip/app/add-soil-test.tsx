import React, { useState } from "react";
import { View, Text, ScrollView, Pressable, TextInput, Alert, Platform, KeyboardAvoidingView, StyleSheet } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router, useLocalSearchParams } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s } from "@/constants/formStyles";
import { SOIL_PARAMS } from "@/lib/soil";

const today = () => new Date().toISOString().split("T")[0];
const num = (v: string): number | null => {
  const n = parseFloat(v.replace(",", "."));
  return Number.isFinite(n) ? n : null;
};

export default function AddSoilTestScreen() {
  const insets = useSafeAreaInsets();
  const { plotId, id } = useLocalSearchParams<{ plotId?: string; id?: string }>();
  const { plots, soilTests, createSoilTest, editSoilTest } = useFarm();
  const existing = id ? soilTests.find((t) => t.id === id) : undefined;

  const [selPlot, setSelPlot] = useState<string | null>(existing?.plot_id || plotId || (plots.length === 1 ? plots[0].id : null));
  const [testDate, setTestDate] = useState(existing?.test_date || today());
  const [reportDate, setReportDate] = useState(existing?.report_date || "");
  const [lab, setLab] = useState(existing?.lab ?? "KALRO NARL");
  const [labNo, setLabNo] = useState(existing?.lab_no || "");
  const [sampleLabel, setSampleLabel] = useState(existing?.sample_label || "");
  const [depth, setDepth] = useState(existing?.depth_cm || "");
  const [crops, setCrops] = useState(existing?.crops_intended || "");
  const [cost, setCost] = useState(existing?.cost_kes != null ? String(existing.cost_kes) : "");
  const [values, setValues] = useState<Record<string, string>>(() => {
    const v: Record<string, string> = {};
    SOIL_PARAMS.forEach((p) => { const raw = (existing as any)?.[p.key]; if (raw != null) v[p.key] = String(raw); });
    return v;
  });
  const [classes, setClasses] = useState<Record<string, string>>(existing?.classes || {});
  const [rec, setRec] = useState(existing?.lab_recommendation || "");
  const [notes, setNotes] = useState(existing?.notes || "");
  const [saving, setSaving] = useState(false);

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const hasValue = SOIL_PARAMS.some((p) => num(values[p.key] || "") !== null);
  const isValid = !!selPlot && testDate.length === 10 && hasValue;

  const handleSave = async () => {
    if (!isValid || !selPlot) return;
    setSaving(true);
    try {
      const data: any = {
        plot_id: selPlot,
        test_date: testDate,
        report_date: reportDate.length === 10 ? reportDate : null,
        lab: lab.trim() || null,
        lab_no: labNo.trim() || null,
        sample_label: sampleLabel.trim() || null,
        depth_cm: depth.trim() || null,
        crops_intended: crops.trim() || null,
        cost_kes: num(cost),
        classes: Object.fromEntries(Object.entries(classes).filter(([k, v]) => v.trim() && num(values[k] || "") !== null).map(([k, v]) => [k, v.trim()])),
        lab_recommendation: rec.trim() || null,
        notes: notes.trim() || null,
      };
      SOIL_PARAMS.forEach((p) => { data[p.key] = num(values[p.key] || ""); });
      if (existing) {
        await editSoilTest(existing.id, data);
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.back();
      } else {
        const created = await createSoilTest({ ...data, plan: [] });
        Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        router.replace({ pathname: "/soil-result", params: { id: created.id } });
      }
    } catch (e: any) {
      Alert.alert("Could not save soil test", e?.message || "Please check your connection and try again. If this keeps happening, the soil database update may not have been run yet.");
    } finally {
      setSaving(false);
    }
  };

  const ResultRows = ({ group }: { group: "key" | "other" }) => (
    <View style={{ gap: 10 }}>
      {SOIL_PARAMS.filter((p) => p.group === group).map((p) => (
        <View key={p.key} style={local.row}>
          <View style={{ flex: 1.3 }}>
            <Text style={local.label}>{p.label}</Text>
            {p.unit ? <Text style={s.hint}>{p.unit}</Text> : null}
          </View>
          <TextInput
            style={[s.input, local.valueInput]}
            value={values[p.key] || ""}
            onChangeText={(t) => setValues((prev) => ({ ...prev, [p.key]: t }))}
            placeholder="Value"
            placeholderTextColor={COLORS.textMuted}
            keyboardType="decimal-pad"
          />
          <TextInput
            style={[s.input, local.classInput]}
            value={classes[p.key] || ""}
            onChangeText={(t) => setClasses((prev) => ({ ...prev, [p.key]: t }))}
            placeholder="Lab class"
            placeholderTextColor={COLORS.textMuted}
          />
        </View>
      ))}
    </View>
  );

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : "height"}>
      <View style={[s.container, { paddingTop: topPadding }]}>
        <View style={s.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}>
            <Ionicons name="arrow-back" size={24} color={COLORS.text} />
          </Pressable>
          <Text style={s.headerTitle}>{existing ? "Edit Soil Test" : "Add Soil Test"}</Text>
          <Pressable style={[s.saveBtn, !isValid && s.saveBtnDisabled]} onPress={handleSave} disabled={saving || !isValid}>
            <Text style={s.saveBtnText}>{saving ? "Saving..." : "Save"}</Text>
          </Pressable>
        </View>
        <ScrollView style={s.scroll} contentContainerStyle={[s.scrollContent, { paddingBottom: insets.bottom + 40 }]} keyboardShouldPersistTaps="handled">
          <View style={s.section}>
            <Text style={s.sectionTitle}>Plot</Text>
            {plots.length === 0 ? (
              <Pressable style={s.outlineBtn} onPress={() => router.push("/add-plot")}>
                <Ionicons name="add" size={18} color={COLORS.primary} />
                <Text style={s.outlineBtnText}>Add a plot first</Text>
              </Pressable>
            ) : (
              <View style={s.chipRow}>
                {plots.map((p) => (
                  <Pressable key={p.id} style={[s.chip, selPlot === p.id && s.chipActive]} onPress={() => setSelPlot(p.id)}>
                    <Text style={[s.chipText, selPlot === p.id && s.chipTextActive]}>{p.name}</Text>
                  </Pressable>
                ))}
              </View>
            )}
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Report details</Text>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Date sampled (YYYY-MM-DD) <Text style={{ color: COLORS.red }}>*</Text></Text>
              <TextInput style={s.input} value={testDate} onChangeText={setTestDate} placeholder="2025-11-28" placeholderTextColor={COLORS.textMuted} maxLength={10} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Date reported (YYYY-MM-DD)</Text>
              <TextInput style={s.input} value={reportDate} onChangeText={setReportDate} placeholder="2025-12-23" placeholderTextColor={COLORS.textMuted} maxLength={10} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Laboratory</Text>
              <TextInput style={s.input} value={lab} onChangeText={setLab} placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Lab number</Text>
              <TextInput style={s.input} value={labNo} onChangeText={setLabNo} placeholder="e.g. 18040" placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Sample name</Text>
              <TextInput style={s.input} value={sampleLabel} onChangeText={setSampleLabel} placeholder="e.g. Sample 1" placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Soil depth (cm)</Text>
              <TextInput style={s.input} value={depth} onChangeText={setDepth} placeholder="e.g. Top, 0-25" placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Crop(s) to be grown</Text>
              <TextInput style={s.input} value={crops} onChangeText={setCrops} placeholder="e.g. Tomato, Onion" placeholderTextColor={COLORS.textMuted} />
            </View>
            <View style={s.field}>
              <Text style={s.fieldLabel}>Cost of the test (KES)</Text>
              <TextInput style={s.input} value={cost} onChangeText={setCost} placeholder="Optional" placeholderTextColor={COLORS.textMuted} keyboardType="decimal-pad" />
            </View>
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Results</Text>
            <Text style={s.hint}>Copy each value from the lab report, with the lab's class (for example Adequate, Deficient, Mod. acid). Leave blank what the report doesn't give.</Text>
            <ResultRows group="key" />
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Other results (optional)</Text>
            <ResultRows group="other" />
          </View>

          <View style={s.section}>
            <Text style={s.sectionTitle}>Lab recommendation</Text>
            <TextInput style={[s.input, s.textArea, { minHeight: 140 }]} value={rec} onChangeText={setRec} placeholder="Type or paste the lab's Interpretation and Fertilizer Recommendation" placeholderTextColor={COLORS.textMuted} multiline />
            <Text style={s.fieldLabel}>Notes</Text>
            <TextInput style={[s.input, s.textArea]} value={notes} onChangeText={setNotes} placeholder="Optional" placeholderTextColor={COLORS.textMuted} multiline />
          </View>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const local = StyleSheet.create({
  row: { flexDirection: "row", alignItems: "center", gap: 8 },
  label: { fontFamily: "DMSans_600SemiBold", fontSize: 13, color: COLORS.text },
  valueInput: { flex: 1, paddingVertical: 10 },
  classInput: { flex: 1.2, paddingVertical: 10 },
});
