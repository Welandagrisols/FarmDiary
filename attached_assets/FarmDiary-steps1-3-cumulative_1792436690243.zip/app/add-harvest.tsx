import React, { useState, useRef } from "react";
import {
  View, Text, StyleSheet, ScrollView, Pressable, TextInput,
  Alert, Platform, KeyboardAvoidingView,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formatKES } from "@/lib/storage";
import { SEASON_SEED } from "@/constants/farmData";
import { getCropMeta } from "@/constants/cropTemplates";

import * as Haptics from "expo-haptics";

function FieldLabel({ label, required }: { label: string; required?: boolean }) {
  return (
    <Text style={styles.fieldLabel}>
      {label}{required ? <Text style={{ color: COLORS.red }}> *</Text> : null}
    </Text>
  );
}

function NumericInput({
  value,
  onChangeText,
  placeholder,
  suffix,
  inputRef,
  onSubmitEditing,
}: {
  value: string;
  onChangeText: (v: string) => void;
  placeholder: string;
  suffix?: string;
  inputRef?: React.RefObject<TextInput | null>;
  onSubmitEditing?: () => void;
}) {
  return (
    <View style={styles.numericRow}>
      <TextInput
        ref={inputRef}
        style={[styles.input, styles.numericInput]}
        value={value}
        onChangeText={onChangeText}
        placeholder={placeholder}
        placeholderTextColor={COLORS.textMuted}
        keyboardType="decimal-pad"
        returnKeyType="next"
        onSubmitEditing={onSubmitEditing}
      />
      {suffix ? <Text style={styles.inputSuffix}>{suffix}</Text> : null}
    </View>
  );
}

export default function AddHarvestScreen() {
  const insets = useSafeAreaInsets();
  const { addHarvestEntry, activeSeason, farmId } = useFarm();
  const seasonId = activeSeason?.id || SEASON_SEED.id;
  const [saving, setSaving] = useState(false);

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 34 : insets.bottom;

  const meta = getCropMeta(activeSeason?.template_id);
  const SECTIONS = [
    { id: "section-a", label: "Section A", sublabel: activeSeason?.section_a?.variety || "" },
    ...(activeSeason?.section_b && activeSeason.section_b.acres > 0
      ? [{ id: "section-b", label: "Section B", sublabel: activeSeason.section_b.variety || "" }]
      : []),
  ];
  const [unitKey, setUnitKey] = useState(meta.harvestUnits[0].key);
  const unit = meta.harvestUnits.find((u) => u.key === unitKey) || meta.harvestUnits[0];
  const isKgUnit = unit.key === "kg";
  const weightRequired = !isKgUnit && unit.defaultKg > 0;
  const [grade, setGrade] = useState("");
  const [sectionId, setSectionId] = useState("section-a");
  const [harvestDate, setHarvestDate] = useState(new Date().toISOString().split("T")[0]);
  const [bags, setBags] = useState("");
  const [kgPerBag, setKgPerBag] = useState(meta.harvestUnits[0].defaultKg ? String(meta.harvestUnits[0].defaultKg) : "");
  const [pricePerBag, setPricePerBag] = useState("");
  const [buyer, setBuyer] = useState("");
  const [notes, setNotes] = useState("");

  const bagsRef = useRef<TextInput>(null);
  const kgRef = useRef<TextInput>(null);
  const priceRef = useRef<TextInput>(null);
  const buyerRef = useRef<TextInput>(null);
  const notesRef = useRef<TextInput>(null);

  const numBags = parseFloat(bags) || 0;
  const numKgPerBag = isKgUnit ? 1 : parseFloat(kgPerBag) || 0;
  const numPrice = parseFloat(pricePerBag) || 0;
  const totalKg = numBags * numKgPerBag;
  const totalRevenue = numBags * numPrice;

  const isValid = numBags > 0 && (!weightRequired || numKgPerBag > 0) && numPrice > 0 && harvestDate.length === 10;

  const handleSelectUnit = (key: string) => {
    Haptics.selectionAsync();
    const u = meta.harvestUnits.find((x) => x.key === key) || meta.harvestUnits[0];
    setUnitKey(u.key);
    setKgPerBag(u.defaultKg && u.key !== "kg" ? String(u.defaultKg) : "");
  };

  const handleSave = async () => {
    if (!isValid) {
      Alert.alert("Missing fields", `Please fill in quantity, price per ${unit.label.toLowerCase()}${weightRequired ? ", weight" : ""} and date.`);
      return;
    }
    setSaving(true);
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    try {
      await addHarvestEntry({
        farm_id: farmId,
        season_id: seasonId,
        section_id: sectionId,
        harvest_date: harvestDate,
        bags: numBags,
        kg_per_bag: numKgPerBag,
        total_kg: totalKg,
        price_per_bag_kes: numPrice,
        total_revenue_kes: totalRevenue,
        buyer: buyer.trim() || null,
        notes: notes.trim() || null,
        // Only sent when not the default, so older databases keep working until the SQL update is run.
        ...(unit.key !== "bag" ? { unit: unit.key } : {}),
        ...(grade.trim() ? { grade: grade.trim() } : {}),
      });
      router.back();
    } catch {
      Alert.alert("Error", "Could not save harvest record.");
      setSaving(false);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={[styles.container, { paddingTop: topPadding }]}> 
        <View style={styles.header}>
          <Pressable onPress={() => router.back()} hitSlop={12}>
            <Ionicons name="arrow-back" size={24} color={COLORS.text} />
          </Pressable>
          <Text style={styles.headerTitle}>Record Harvest</Text>
          <Pressable
            style={[styles.saveBtn, !isValid && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={saving || !isValid}
          >
            <Text style={styles.saveBtnText}>{saving ? "Saving..." : "Save"}</Text>
          </Pressable>
        </View>

        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: bottomPadding + 40 }]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {totalRevenue > 0 && (
            <View style={styles.previewCard}>
              <Text style={styles.previewLabel}>Revenue Preview</Text>
              <Text style={styles.previewRevenue}>{formatKES(totalRevenue)}</Text>
              <Text style={styles.previewMeta}>
                {numBags} {unit.plural.toLowerCase()}{numKgPerBag > 0 && !isKgUnit ? ` × ${numKgPerBag} kg = ${totalKg.toFixed(0)} kg total` : ""}
              </Text>
            </View>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Section</Text>
            <View style={styles.sectionRow}>
              {SECTIONS.map((s) => (
                <Pressable
                  key={s.id}
                  style={[styles.sectionBtn, sectionId === s.id && styles.sectionBtnActive]}
                  onPress={() => { Haptics.selectionAsync(); setSectionId(s.id); }}
                >
                  <Text style={[styles.sectionBtnLabel, sectionId === s.id && styles.sectionBtnLabelActive]}>
                    {s.label}
                  </Text>
                  <Text style={[styles.sectionBtnSub, sectionId === s.id && { color: COLORS.white + "CC" }]}>
                    {s.sublabel}
                  </Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Counted / Sold In</Text>
            <View style={styles.unitRow}>
              {meta.harvestUnits.map((u) => (
                <Pressable
                  key={u.key}
                  style={[styles.unitChip, unitKey === u.key && styles.unitChipActive]}
                  onPress={() => handleSelectUnit(u.key)}
                >
                  <Text style={[styles.unitChipText, unitKey === u.key && styles.unitChipTextActive]}>{u.plural}</Text>
                </Pressable>
              ))}
            </View>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Harvest Details</Text>

            <View style={styles.field}>
              <FieldLabel label="Harvest Date" required />
              <TextInput
                style={styles.input}
                value={harvestDate}
                onChangeText={setHarvestDate}
                placeholder="YYYY-MM-DD"
                placeholderTextColor={COLORS.textMuted}
                keyboardType="numbers-and-punctuation"
                returnKeyType="next"
                onSubmitEditing={() => bagsRef.current?.focus()}
              />
            </View>

            <View style={styles.field}>
              <FieldLabel label={`Number of ${unit.plural}`} required />
              <NumericInput
                value={bags}
                onChangeText={setBags}
                placeholder="e.g. 120"
                suffix={unit.plural.toLowerCase()}
                inputRef={bagsRef}
                onSubmitEditing={() => kgRef.current?.focus()}
              />
            </View>

            {!isKgUnit && (
              <View style={styles.field}>
                <FieldLabel label={`Weight per ${unit.label}`} required={weightRequired} />
                <NumericInput
                  value={kgPerBag}
                  onChangeText={setKgPerBag}
                  placeholder={weightRequired ? "e.g. 110" : "Optional"}
                  suffix={`kg / ${unit.label.toLowerCase()}`}
                  inputRef={kgRef}
                  onSubmitEditing={() => priceRef.current?.focus()}
                />
              </View>
            )}

            {totalKg > 0 && (
              <View style={styles.calcRow}>
                <Ionicons name="calculator-outline" size={14} color={COLORS.primary} />
                <Text style={styles.calcText}>Total weight: {totalKg.toFixed(0)} kg</Text>
              </View>
            )}

            <View style={styles.field}>
              <FieldLabel label={`Price per ${unit.label} (KES)`} required />
              <NumericInput
                value={pricePerBag}
                onChangeText={setPricePerBag}
                placeholder="e.g. 3500"
                suffix="KES"
                inputRef={priceRef}
                onSubmitEditing={() => buyerRef.current?.focus()}
              />
            </View>

            {totalRevenue > 0 && (
              <View style={styles.calcRow}>
                <Ionicons name="cash-outline" size={14} color={COLORS.primary} />
                <Text style={styles.calcText}>Revenue: {formatKES(totalRevenue)}</Text>
              </View>
            )}
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Buyer & Notes (optional)</Text>

            <View style={styles.field}>
              <FieldLabel label="Grade / Quality" />
              <TextInput
                style={styles.input}
                value={grade}
                onChangeText={setGrade}
                placeholder="e.g. Grade 1, medium, export"
                placeholderTextColor={COLORS.textMuted}
                returnKeyType="next"
              />
            </View>

            <View style={styles.field}>
              <FieldLabel label="Buyer Name" />
              <TextInput
                ref={buyerRef}
                style={styles.input}
                value={buyer}
                onChangeText={setBuyer}
                placeholder="e.g. Nakuru Traders Ltd"
                placeholderTextColor={COLORS.textMuted}
                returnKeyType="next"
                onSubmitEditing={() => notesRef.current?.focus()}
              />
            </View>

            <View style={styles.field}>
              <FieldLabel label="Notes" />
              <TextInput
                ref={notesRef}
                style={[styles.input, styles.textArea]}
                value={notes}
                onChangeText={setNotes}
                placeholder="Any notes about quality, grading, payment terms…"
                placeholderTextColor={COLORS.textMuted}
                multiline
                numberOfLines={3}
                returnKeyType="done"
              />
            </View>
          </View>

          <Pressable
            style={[styles.saveFullBtn, !isValid && styles.saveBtnDisabled]}
            onPress={handleSave}
            disabled={saving || !isValid}
          >
            <Ionicons name="checkmark-circle-outline" size={20} color={COLORS.white} />
            <Text style={styles.saveFullBtnText}>{saving ? "Saving..." : "Save Harvest Record"}</Text>
          </Pressable>
        </ScrollView>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  unitRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  unitChip: {
    paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10,
    backgroundColor: COLORS.borderLight, borderWidth: 1.5, borderColor: COLORS.border,
  },
  unitChipActive: { backgroundColor: COLORS.primarySurface, borderColor: COLORS.primary },
  unitChipText: { fontFamily: "DMSans_500Medium", fontSize: 13, color: COLORS.textSecondary },
  unitChipTextActive: { color: COLORS.primary, fontFamily: "DMSans_700Bold" },
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 12, paddingTop: 8,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerTitle: { fontFamily: "DMSans_700Bold", fontSize: 18, color: COLORS.text },
  saveBtn: {
    backgroundColor: COLORS.primary, borderRadius: 8,
    paddingHorizontal: 14, paddingVertical: 7,
  },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText: { fontFamily: "DMSans_600SemiBold", fontSize: 14, color: COLORS.white },

  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 16 },

  previewCard: {
    backgroundColor: COLORS.primary, borderRadius: 14, padding: 16, alignItems: "center", gap: 4,
  },
  previewLabel: { fontFamily: "DMSans_400Regular", fontSize: 12, color: COLORS.white, opacity: 0.75 },
  previewRevenue: { fontFamily: "DMSans_700Bold", fontSize: 26, color: COLORS.white },
  previewMeta: { fontFamily: "DMSans_400Regular", fontSize: 13, color: COLORS.white, opacity: 0.8 },

  section: {
    backgroundColor: COLORS.cardBg, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: COLORS.border, gap: 14,
  },
  sectionTitle: { fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.text },
  sectionRow: { flexDirection: "row", gap: 10 },
  sectionBtn: {
    flex: 1, borderRadius: 10, padding: 12,
    backgroundColor: COLORS.borderLight, borderWidth: 1, borderColor: COLORS.border, gap: 2,
  },
  sectionBtnActive: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  sectionBtnLabel: { fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.text },
  sectionBtnLabelActive: { color: COLORS.white },
  sectionBtnSub: { fontFamily: "DMSans_400Regular", fontSize: 11, color: COLORS.textMuted },

  field: { gap: 6 },
  fieldLabel: { fontFamily: "DMSans_600SemiBold", fontSize: 13, color: COLORS.textSecondary },
  input: {
    backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 10, padding: 12, fontFamily: "DMSans_400Regular",
    fontSize: 15, color: COLORS.text,
  },
  numericRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  numericInput: { flex: 1 },
  inputSuffix: { fontFamily: "DMSans_500Medium", fontSize: 13, color: COLORS.textSecondary, minWidth: 56 },
  textArea: { minHeight: 80, textAlignVertical: "top" },

  calcRow: {
    flexDirection: "row", alignItems: "center", gap: 6,
    backgroundColor: COLORS.primarySurface, borderRadius: 8, padding: 10,
    marginTop: -6,
  },
  calcText: { fontFamily: "DMSans_600SemiBold", fontSize: 13, color: COLORS.primary },

  saveFullBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    backgroundColor: COLORS.primary, borderRadius: 14, padding: 16,
  },
  saveFullBtnText: { fontFamily: "DMSans_700Bold", fontSize: 16, color: COLORS.white },
});