// Soil test helpers. Pure functions (no React) so they are easy to test.
// The lab's own class is always shown first. The app's estimate is used only when the lab gave no class,
// and is marked "est.". Estimate cut-offs are DRAFT, based on commonly used Kenyan ratings
// (KALRO/NAAIAP). Confirm against your lab's interpretation before relying on them.

import type { PlotRecord, SeasonRecord, SoilTest } from "./storage";
import { getCropFamily } from "../constants/cropTemplates";

export interface SoilParam {
  key: string; // also the SoilTest column name
  label: string;
  unit: string;
  group: "key" | "other";
}

// Same order as the KALRO NARL report.
export const SOIL_PARAMS: SoilParam[] = [
  { key: "ph", label: "Soil pH", unit: "", group: "key" },
  { key: "exch_acidity", label: "Exch. acidity", unit: "meq%", group: "key" },
  { key: "total_n", label: "Total nitrogen", unit: "%", group: "key" },
  { key: "organic_carbon", label: "Total organic carbon", unit: "%", group: "key" },
  { key: "p_mehlich", label: "Phosphorus (Mehlich)", unit: "ppm", group: "key" },
  { key: "p_olsen", label: "Phosphorus (Olsen)", unit: "ppm", group: "key" },
  { key: "k_me", label: "Potassium", unit: "meq%", group: "key" },
  { key: "ca_me", label: "Calcium", unit: "meq%", group: "key" },
  { key: "mg_me", label: "Magnesium", unit: "meq%", group: "key" },
  { key: "mn_me", label: "Manganese", unit: "meq%", group: "other" },
  { key: "cu_ppm", label: "Copper", unit: "ppm", group: "other" },
  { key: "fe_ppm", label: "Iron", unit: "ppm", group: "other" },
  { key: "zn_ppm", label: "Zinc", unit: "ppm", group: "other" },
  { key: "na_me", label: "Sodium", unit: "meq%", group: "other" },
  { key: "ec", label: "Electrical conductivity", unit: "mS/cm", group: "other" },
];

export type Tone = "good" | "warn" | "bad" | "neutral";

export function classTone(cls?: string | null): Tone {
  if (!cls) return "neutral";
  const c = cls.toLowerCase();
  if (/defici|very low|very strong|extreme|severe|toxic/.test(c)) return "bad";
  if (/strong/.test(c)) return "bad";
  if (/low|acid|high|excess|saline|alkal|mod\./.test(c)) return "warn";
  if (/adequate|optim|suffic|good|neutral|medium|ok/.test(c)) return "good";
  return "neutral";
}

// App estimate, only for results where a common Kenyan cut-off exists.
export function estimateClass(key: string, v: number): string | null {
  switch (key) {
    case "ph":
      if (v < 4.5) return "Very strongly acid";
      if (v < 5.0) return "Strongly acid";
      if (v < 5.5) return "Mod. acid";
      if (v < 6.5) return "Slightly acid";
      if (v <= 7.5) return "Neutral";
      return "Alkaline";
    case "organic_carbon": return v <= 2.0 ? "Low" : "Adequate";
    case "total_n": return v < 0.2 ? "Low" : "Adequate";
    case "p_olsen": return v < 10 ? "Low" : "Adequate";
    case "k_me": return v < 0.24 ? "Low" : "Adequate";
    case "ca_me": return v < 2.0 ? "Low" : "Adequate";
    case "mg_me": return v < 1.0 ? "Low" : "Adequate";
    default: return null;
  }
}

export interface ParamRow {
  key: string;
  label: string;
  unit: string;
  group: "key" | "other";
  value: number;
  cls: string | null;
  tone: Tone;
  estimated: boolean;
}

// Only results that have a value.
export function paramRows(test: SoilTest): ParamRow[] {
  const rows: ParamRow[] = [];
  for (const p of SOIL_PARAMS) {
    const raw = (test as any)[p.key];
    if (raw === null || raw === undefined || raw === "" || Number.isNaN(Number(raw))) continue;
    const value = Number(raw);
    const labClass = test.classes?.[p.key]?.trim() || null;
    const est = labClass ? null : estimateClass(p.key, value);
    const cls = labClass || est;
    rows.push({ ...p, value, cls, tone: classTone(cls), estimated: !labClass && !!est });
  }
  return rows;
}

// Results that need attention (not "good" or unclassified).
export function findings(test: SoilTest): ParamRow[] {
  return paramRows(test).filter((r) => r.tone === "warn" || r.tone === "bad");
}

export function testsForPlot(plotId: string, tests: SoilTest[]): SoilTest[] {
  return tests
    .filter((t) => t.plot_id === plotId)
    .sort((a, b) => (a.test_date < b.test_date ? 1 : a.test_date > b.test_date ? -1 : 0)); // newest first
}

export function latestTest(plotId: string, tests: SoilTest[]): SoilTest | null {
  return testsForPlot(plotId, tests)[0] || null;
}

function addMonths(dateStr: string, months: number): string {
  const d = new Date(dateStr + "T00:00:00Z");
  d.setUTCMonth(d.getUTCMonth() + months);
  return d.toISOString().split("T")[0];
}

export type RetestStatus =
  | { status: "none" }
  | { status: "ok" | "soon" | "due"; dueDate: string; daysLeft: number };

// "soon" = due within 30 days; "due" = overdue or due today.
export function retestStatus(plot: PlotRecord, tests: SoilTest[], today: string): RetestStatus {
  const last = latestTest(plot.id, tests);
  if (!last) return { status: "none" };
  const dueDate = addMonths(last.test_date, plot.retest_months || 12);
  const daysLeft = Math.round((Date.parse(dueDate) - Date.parse(today)) / 86400000);
  return { status: daysLeft <= 0 ? "due" : daysLeft <= 30 ? "soon" : "ok", dueDate, daysLeft };
}

// Cycles (seasons) that used a plot, newest first.
export function seasonsForPlot(plotId: string, seasons: SeasonRecord[]): { season: SeasonRecord; sectionIds: string[] }[] {
  const out: { season: SeasonRecord; sectionIds: string[] }[] = [];
  for (const s of seasons) {
    const ids: string[] = [];
    if (s.section_a?.plot_id === plotId) ids.push("section-a");
    if (s.section_b?.plot_id === plotId) ids.push("section-b");
    if (ids.length) out.push({ season: s, sectionIds: ids });
  }
  return out.sort((a, b) => {
    const da = a.season.section_a?.planting_date || a.season.created_at;
    const db = b.season.section_a?.planting_date || b.season.created_at;
    return da < db ? 1 : da > db ? -1 : 0;
  });
}

// Warn when the same crop family was grown on this plot in the last 36 months.
export function rotationWarning(
  plotId: string,
  newTemplateId: string,
  seasons: SeasonRecord[],
  today: string,
  excludeSeasonId?: string
): string | null {
  const fam = getCropFamily(newTemplateId);
  if (!fam) return null;
  const cutoff = addMonths(today, -36);
  const hits = seasonsForPlot(plotId, seasons).filter(({ season }) => {
    if (season.id === excludeSeasonId) return false;
    const f = getCropFamily(season.template_id);
    const when = season.section_a?.planting_date || season.created_at.split("T")[0];
    return f?.family === fam.family && when >= cutoff;
  });
  if (!hits.length) return null;
  const names = hits.slice(0, 3).map(({ season }) => `${season.season_name}`).join(", ");
  return `${fam.family} crops were grown on this plot recently (${names}). Risk of ${fam.risks}. Consider a different crop family or a longer break.`;
}
