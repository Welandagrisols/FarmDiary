import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import {
  ActivityLog,
  addActivityLog,
  addPlot,
  addSoilTest,
  deletePlot,
  deleteSoilTest,
  getPlots,
  getSoilTests,
  PlotRecord,
  SoilTest,
  updatePlot,
  updateSoilTest,
  addCost,
  addFieldObservation,
  addFarmRecord,
  addHarvestRecord,
  addInventoryItem,
  addSeason,
  closeSeason,
  deleteActivityLog,
  deleteCost,
  deleteHarvestRecord,
  deleteInventoryItem,
  deleteObservation,
  getActiveFarmRecord,
  getActiveSeason,
  getActivityLogs,
  getCosts,
  getFarms,
  getHarvestRecords,
  getInventory,
  getObservations,
  getSeasons,
  HarvestRecord,
  InventoryItem,
  ObservationRecord,
  reopenSeason,
  SeasonRecord,
  setActiveFarmId,
  setActiveSeasonId,
  updateActivityLog,
  updateFarmRecord,
  updateSeason,
} from "@/lib/storage";
import { generatePlannedSchedule, getTemplate } from "@/constants/farmData";

const CACHE_KEY = "farm_offline_cache_v1";

type FarmContextValue = {
  costs: Awaited<ReturnType<typeof getCosts>>;
  inventory: InventoryItem[];
  activityLogs: ActivityLog[];
  observations: ObservationRecord[];
  harvestRecords: HarvestRecord[];
  seasons: SeasonRecord[];
  activeSeason: SeasonRecord | null;
  currentSchedule: ReturnType<typeof generatePlannedSchedule>;
  seasonId: string;
  farms: Awaited<ReturnType<typeof getFarms>>;
  activeFarm: Awaited<ReturnType<typeof getActiveFarmRecord>>;
  farmId: string;
  isLoading: boolean;
  isOffline: boolean;
  refresh: () => Promise<void>;
  plots: PlotRecord[];
  soilTests: SoilTest[];
  refreshSoil: () => Promise<void>;
  createPlot: (plot: Omit<PlotRecord, "id" | "created_at" | "farm_id">) => Promise<PlotRecord>;
  editPlot: (id: string, updates: Partial<PlotRecord>) => Promise<void>;
  removePlot: (id: string) => Promise<void>;
  createSoilTest: (test: Omit<SoilTest, "id" | "created_at" | "farm_id">) => Promise<SoilTest>;
  editSoilTest: (id: string, updates: Partial<SoilTest>) => Promise<void>;
  removeSoilTest: (id: string) => Promise<void>;
  addCostEntry: typeof addCost;
  removeCost: typeof deleteCost;
  addInventory: typeof addInventoryItem;
  removeInventory: typeof deleteInventoryItem;
  logActivity: typeof addActivityLog;
  editActivityLog: (id: string, updates: Partial<ActivityLog>) => Promise<void>;
  removeActivityLog: typeof deleteActivityLog;
  addFieldObservation: typeof addFieldObservation;
  removeObservation: typeof deleteObservation;
  totalSpent: number;
  totalRevenue: number;
  getCompletedActivityIds: () => string[];
  getNextActivity: (sectionId: string) => any;
  quickCompleteActivity: any;
  getLastSprayDate: (sectionId: string) => string | null;
  addHarvestEntry: typeof addHarvestRecord;
  removeHarvestRecord: typeof deleteHarvestRecord;
  createSeason: typeof addSeason;
  switchSeason: (targetSeasonId: string) => Promise<void>;
  closeActiveSeason: () => Promise<void>;
  reopenActiveSeason: () => Promise<void>;
  updateActiveSeason: (updates: Partial<SeasonRecord>) => Promise<void>;
  createFarm: typeof addFarmRecord;
  switchFarm: (targetFarmId: string) => Promise<void>;
  updateActiveFarm: (updates: Partial<any>) => Promise<void>;
};

const FarmContext = createContext<FarmContextValue | null>(null);

export function FarmProvider({ children }: { children: React.ReactNode }) {
  const [costs, setCosts] = useState<Awaited<ReturnType<typeof getCosts>>>([]);
  const [inventory, setInventory] = useState<InventoryItem[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  const [observations, setObservations] = useState<ObservationRecord[]>([]);
  const [harvestRecords, setHarvestRecords] = useState<HarvestRecord[]>([]);
  const [seasons, setSeasons] = useState<SeasonRecord[]>([]);
  const [plots, setPlots] = useState<PlotRecord[]>([]);
  const [soilTests, setSoilTests] = useState<SoilTest[]>([]);
  const [activeSeason, setActiveSeason] = useState<SeasonRecord | null>(null);
  const [farms, setFarms] = useState<Awaited<ReturnType<typeof getFarms>>>([]);
  const [activeFarm, setActiveFarm] = useState<Awaited<ReturnType<typeof getActiveFarmRecord>>>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(false);

  const applyData = useCallback((allFarms: any[], farm: any, allSeasons: SeasonRecord[], active: SeasonRecord | null, c: any[], inv: InventoryItem[], logs: ActivityLog[], obs: ObservationRecord[], harvest: HarvestRecord[]) => {
    const farmId = farm?.id || allFarms[0]?.id || "";
    setFarms(allFarms);
    setActiveFarm(farm);
    setSeasons(allSeasons.filter((item) => item.farm_id === farmId));
    setActiveSeason(active && active.farm_id === farmId ? active : allSeasons.find((item) => item.farm_id === farmId && item.status !== "closed") || null);
    setCosts(c.filter((item) => item.farm_id === farmId));
    setInventory(inv.filter((item) => item.farm_id === farmId));
    setActivityLogs(logs.filter((item) => item.farm_id === farmId));
    setObservations(obs.filter((item) => item.farm_id === farmId));
    setHarvestRecords(harvest.filter((item) => item.farm_id === farmId));
  }, []);

  const refresh = useCallback(async () => {
    try {
      const [allFarms, farm, allSeasons, active, c, inv, logs, obs, harvest] = await Promise.all([
        getFarms(),
        getActiveFarmRecord(),
        getSeasons(),
        getActiveSeason(),
        getCosts(),
        getInventory(),
        getActivityLogs(),
        getObservations(),
        getHarvestRecords(),
      ]);

      applyData(allFarms, farm, allSeasons, active, c, inv, logs, obs, harvest);
      setIsOffline(false);

      try {
        await AsyncStorage.setItem(CACHE_KEY, JSON.stringify({ allFarms, farm, allSeasons, active, c, inv, logs, obs, harvest }));
      } catch { /* ignore cache write errors */ }

    } catch (err) {
      console.warn("[FarmContext] Supabase unavailable, loading offline cache:", err);
      try {
        const raw = await AsyncStorage.getItem(CACHE_KEY);
        if (raw) {
          const { allFarms, farm, allSeasons, active, c, inv, logs, obs, harvest } = JSON.parse(raw);
          applyData(allFarms, farm, allSeasons, active, c, inv, logs, obs, harvest);
          setIsOffline(true);
        }
      } catch (cacheErr) {
        console.error("[FarmContext] cache load failed:", cacheErr);
      }
    } finally {
      setIsLoading(false);
    }
  }, [applyData]);

  useEffect(() => { refresh(); }, [refresh]);

  const currentSchedule = useMemo(() => {
    if (!activeSeason) return [];
    const template = getTemplate(activeSeason.template_id);
    const plantingDate = activeSeason.section_a?.planting_date || new Date().toISOString().split("T")[0];
    const plantingDateB = activeSeason.section_b?.planting_date || undefined;
    return generatePlannedSchedule(template, plantingDate, plantingDateB);
  }, [activeSeason]);
  const seasonId = activeSeason?.id || "";
  const farmId = activeFarm?.id || "";

  // Plots and soil tests (kept separate so the app still works before the soil SQL is run).
  const loadSoil = useCallback(async (fid: string) => {
    if (!fid) { setPlots([]); setSoilTests([]); return; }
    const cacheKey = `farm_soil_cache_${fid}`;
    try {
      const [p, t] = await Promise.all([getPlots(), getSoilTests()]);
      const mine = { plots: p.filter((x) => x.farm_id === fid), tests: t.filter((x) => x.farm_id === fid) };
      setPlots(mine.plots);
      setSoilTests(mine.tests);
      AsyncStorage.setItem(cacheKey, JSON.stringify(mine)).catch(() => {});
    } catch (err) {
      try {
        const raw = await AsyncStorage.getItem(cacheKey);
        if (raw) { const c = JSON.parse(raw); setPlots(c.plots || []); setSoilTests(c.tests || []); }
      } catch {}
    }
  }, []);
  useEffect(() => { loadSoil(farmId); }, [farmId, loadSoil]);
  const refreshSoil = useCallback(async () => { await loadSoil(farmId); }, [farmId, loadSoil]);

  const createPlot = useCallback(async (plot: Omit<PlotRecord, "id" | "created_at" | "farm_id">) => {
    const created = await addPlot({ ...plot, farm_id: farmId });
    setPlots((prev) => [...prev, created]);
    return created;
  }, [farmId]);
  const editPlot = useCallback(async (id: string, updates: Partial<PlotRecord>) => {
    const updated = await updatePlot(id, updates);
    setPlots((prev) => prev.map((p) => (p.id === id ? updated : p)));
  }, []);
  const removePlot = useCallback(async (id: string) => {
    const owned = soilTests.filter((t) => t.plot_id === id);
    for (const t of owned) await deleteSoilTest(t.id);
    await deletePlot(id);
    setSoilTests((prev) => prev.filter((t) => t.plot_id !== id));
    setPlots((prev) => prev.filter((p) => p.id !== id));
  }, [soilTests]);
  const createSoilTest = useCallback(async (test: Omit<SoilTest, "id" | "created_at" | "farm_id">) => {
    const created = await addSoilTest({ ...test, farm_id: farmId });
    setSoilTests((prev) => [...prev, created]);
    return created;
  }, [farmId]);
  const editSoilTest = useCallback(async (id: string, updates: Partial<SoilTest>) => {
    const updated = await updateSoilTest(id, updates);
    setSoilTests((prev) => prev.map((t) => (t.id === id ? updated : t)));
  }, []);
  const removeSoilTest = useCallback(async (id: string) => {
    await deleteSoilTest(id);
    setSoilTests((prev) => prev.filter((t) => t.id !== id));
  }, []);
  // Totals are for the active season (a farm can now hold several crops and cycles).
  const totalSpent = useMemo(
    () => costs.filter((cost) => !seasonId || cost.season_id === seasonId).reduce((sum, cost) => sum + cost.amount_kes, 0),
    [costs, seasonId]
  );
  const totalRevenue = useMemo(
    () => harvestRecords.filter((record) => !seasonId || record.season_id === seasonId).reduce((sum, record) => sum + record.total_revenue_kes, 0),
    [harvestRecords, seasonId]
  );

  const getCompletedActivityIds = useCallback(() => {
    const ids = new Set<string>();
    activityLogs.filter((l) => l.season_id === seasonId).forEach((log) => { if (log.schedule_activity_id) ids.add(log.schedule_activity_id); });
    return Array.from(ids);
  }, [activityLogs, seasonId]);

  const getNextActivity = useCallback((_sectionId: string) => {
    const completedIds = getCompletedActivityIds();
    return currentSchedule.find((activity) => !completedIds.includes(activity.id)) || null;
  }, [currentSchedule, getCompletedActivityIds]);

  const quickCompleteActivity = useCallback(async (activity: any, sectionId: string | null) => {
    const today = new Date().toISOString().split("T")[0];
    const isB = sectionId === "section-b";
    const newLog = await addActivityLog({ farm_id: farmId, season_id: seasonId, section_id: sectionId, schedule_activity_id: activity.id, activity_name: activity.name, planned_date: isB ? activity.plannedDateB : activity.plannedDateA, actual_date: today, products_used: [], is_deviation: false, deviation_reason: null, num_workers: 0, labor_cost_kes: 0, total_cost_kes: 0, weather_conditions: null, is_historical: false, notes: "Quick-completed (no costs logged)" });
    setActivityLogs((prev) => [...prev, newLog]);
  }, [farmId, seasonId]);

  const addCostEntry = useCallback(async (cost: Omit<Parameters<typeof addCost>[0], never>) => {
    const newRecord = await addCost(cost);
    setCosts((prev) => [...prev, newRecord]);
    return newRecord;
  }, []);
  const removeCost = useCallback(async (id: string) => {
    await deleteCost(id);
    setCosts((prev) => prev.filter((c) => c.id !== id));
  }, []);
  const addInventory = useCallback(async (item: Omit<Parameters<typeof addInventoryItem>[0], never>) => {
    const newRecord = await addInventoryItem(item);
    setInventory((prev) => [...prev, newRecord]);
    return newRecord;
  }, []);
  const removeInventory = useCallback(async (id: string) => {
    await deleteInventoryItem(id);
    setInventory((prev) => prev.filter((i) => i.id !== id));
  }, []);
  const logActivity = useCallback(async (entry: Omit<Parameters<typeof addActivityLog>[0], never>) => {
    const newRecord = await addActivityLog(entry);
    setActivityLogs((prev) => [...prev, newRecord]);
    return newRecord;
  }, []);
  const removeActivityLog = useCallback(async (id: string) => {
    await deleteActivityLog(id);
    setActivityLogs((prev) => prev.filter((l) => l.id !== id));
  }, []);
  const addObservation = useCallback(async (obs: Omit<Parameters<typeof addFieldObservation>[0], never>) => {
    const newRecord = await addFieldObservation(obs);
    setObservations((prev) => [...prev, newRecord]);
    return newRecord;
  }, []);
  const removeObservation = useCallback(async (id: string) => {
    await deleteObservation(id);
    setObservations((prev) => prev.filter((o) => o.id !== id));
  }, []);
  const addHarvestEntry = useCallback(async (record: Omit<HarvestRecord, "id" | "created_at">) => { const newRecord = await addHarvestRecord(record); setHarvestRecords((prev) => [...prev, newRecord]); }, []);
  const removeHarvestRecord = useCallback(async (id: string) => { await deleteHarvestRecord(id); setHarvestRecords((prev) => prev.filter((r) => r.id !== id)); }, []);
  const createSeason = useCallback(async (season: Omit<SeasonRecord, "id" | "created_at">) => { const newSeason = await addSeason(season); setSeasons((prev) => [...prev, newSeason]); await setActiveSeasonId(newSeason.id); setActiveSeason(newSeason); return newSeason; }, []);
  const switchSeason = useCallback(async (targetSeasonId: string) => { await setActiveSeasonId(targetSeasonId); await refresh(); }, [refresh]);
  const closeActiveSeason = useCallback(async () => { if (!activeSeason) return; const updated = await closeSeason(activeSeason.id); setSeasons((prev) => prev.map((s) => s.id === updated.id ? updated : s)); setActiveSeason(updated); }, [activeSeason]);
  const reopenActiveSeason = useCallback(async () => { if (!activeSeason) return; const updated = await reopenSeason(activeSeason.id); setSeasons((prev) => prev.map((s) => s.id === updated.id ? updated : s)); setActiveSeason(updated); }, [activeSeason]);
  const updateActiveSeason = useCallback(async (updates: Partial<SeasonRecord>) => { if (!activeSeason) return; const updated = await updateSeason(activeSeason.id, updates); setSeasons((prev) => prev.map((s) => s.id === updated.id ? updated : s)); setActiveSeason(updated); }, [activeSeason]);
  const editActivityLog = useCallback(async (id: string, updates: Partial<ActivityLog>) => {
    const updated = await updateActivityLog(id, updates);
    setActivityLogs((prev) => prev.map((l) => l.id === updated.id ? updated : l));
  }, []);
  const createFarm = useCallback(async (farm: Omit<any, "id" | "created_at">) => { const newFarm = await addFarmRecord(farm); setFarms((prev) => [...prev, newFarm]); return newFarm; }, []);
  const switchFarm = useCallback(async (targetFarmId: string) => { await setActiveFarmId(targetFarmId); await refresh(); }, [refresh]);
  const updateActiveFarm = useCallback(async (updates: Partial<any>) => { if (!activeFarm) return; const updated = await updateFarmRecord(activeFarm.id, updates); setFarms((prev) => prev.map((f) => f.id === updated.id ? updated : f)); setActiveFarm(updated); }, [activeFarm]);

  const value = useMemo(() => ({
    costs, inventory, activityLogs, observations, harvestRecords, seasons, activeSeason,
    plots, soilTests, refreshSoil, createPlot, editPlot, removePlot, createSoilTest, editSoilTest, removeSoilTest,
    currentSchedule, seasonId, farms, activeFarm, farmId, isLoading, isOffline, refresh,
    addCostEntry, removeCost, addInventory, removeInventory, logActivity, editActivityLog,
    removeActivityLog, addFieldObservation: addObservation, removeObservation, totalSpent, totalRevenue,
    getCompletedActivityIds, getNextActivity, quickCompleteActivity, getLastSprayDate: () => null,
    addHarvestEntry, removeHarvestRecord, createSeason, switchSeason, closeActiveSeason,
    reopenActiveSeason, updateActiveSeason, createFarm, switchFarm, updateActiveFarm,
  }), [
    costs, inventory, activityLogs, observations, harvestRecords, seasons, activeSeason,
    plots, soilTests, refreshSoil, createPlot, editPlot, removePlot, createSoilTest, editSoilTest, removeSoilTest,
    currentSchedule, seasonId, farms, activeFarm, farmId, isLoading, isOffline, refresh,
    addCostEntry, removeCost, addInventory, removeInventory, logActivity, editActivityLog,
    removeActivityLog, addObservation, removeObservation, totalSpent, totalRevenue,
    getCompletedActivityIds, getNextActivity, quickCompleteActivity,
    addHarvestEntry, removeHarvestRecord, createSeason, switchSeason, closeActiveSeason,
    reopenActiveSeason, updateActiveSeason, createFarm, switchFarm, updateActiveFarm,
  ]);

  return <FarmContext.Provider value={value}>{children}</FarmContext.Provider>;
}

export function useFarm() {
  const ctx = useContext(FarmContext);
  if (!ctx) throw new Error("useFarm must be used within FarmProvider");
  return ctx;
}
