import React from "react";
import { View, Text, Pressable } from "react-native";
import { router } from "expo-router";
import { useFarm } from "@/context/FarmContext";
import COLORS from "@/constants/colors";
import { formStyles as s } from "@/constants/formStyles";
import { getTemplate } from "@/constants/farmData";
import { formatDate } from "@/lib/storage";
import { findings, latestTest, rotationWarning } from "@/lib/soil";

// Optional plot choice for a crop section, with a rotation check and the latest soil plan.
export default function PlotPicker({
  value,
  onChange,
  templateId,
  excludeSeasonId,
}: {
  value: string | null;
  onChange: (plotId: string | null) => void;
  templateId: string;
  excludeSeasonId?: string;
}) {
  const { plots, soilTests, seasons } = useFarm();
  const today = new Date().toISOString().split("T")[0];
  const plot = value ? plots.find((p) => p.id === value) : undefined;

  if (plots.length === 0) {
    return (
      <Pressable onPress={() => router.push("/add-plot")}>
        <Text style={[s.hint, { color: COLORS.primary }]}>Add a plot to track soil tests and crop rotation for this section</Text>
      </Pressable>
    );
  }

  const cropName = getTemplate(templateId).cropType.toLowerCase();
  const warning = plot ? rotationWarning(plot.id, templateId, seasons, today, excludeSeasonId) : null;
  const last = plot ? latestTest(plot.id, soilTests) : null;
  const planForCrop = (last?.plan || []).filter((p) => !p.crop || p.crop.toLowerCase().includes(cropName) || cropName.includes(p.crop.toLowerCase()));
  const flagged = last ? findings(last) : [];

  return (
    <View style={s.field}>
      <Text style={s.fieldLabel}>Plot (optional)</Text>
      <View style={s.chipRow}>
        <Pressable style={[s.chip, !value && s.chipActive]} onPress={() => onChange(null)}>
          <Text style={[s.chipText, !value && s.chipTextActive]}>No plot</Text>
        </Pressable>
        {plots.map((p) => (
          <Pressable key={p.id} style={[s.chip, value === p.id && s.chipActive]} onPress={() => onChange(p.id)}>
            <Text style={[s.chipText, value === p.id && s.chipTextActive]}>{p.name}</Text>
          </Pressable>
        ))}
      </View>

      {warning ? (
        <View style={{ backgroundColor: COLORS.amberLight, borderRadius: 10, padding: 12 }}>
          <Text style={[s.body, { color: COLORS.amber }]}>{warning}</Text>
        </View>
      ) : null}

      {plot && !last ? <Text style={s.hint}>No soil test on this plot yet.</Text> : null}

      {plot && last ? (
        <View style={{ backgroundColor: COLORS.primarySurface, borderRadius: 10, padding: 12, gap: 4 }}>
          <Text style={s.fieldLabel}>Latest soil test ({formatDate(last.test_date)})</Text>
          {flagged.length ? <Text style={s.hint}>Needs attention: {flagged.map((r) => `${r.label} ${r.cls}`).join(", ")}</Text> : null}
          {planForCrop.slice(0, 5).map((p) => (
            <Text key={p.id} style={s.body}>
              {p.product}{p.rate ? `: ${p.rate}` : ""}{p.timing ? ` (${p.timing})` : ""}
            </Text>
          ))}
          {planForCrop.length === 0 ? <Text style={s.hint}>No plan items for this crop yet. Add them from the soil result.</Text> : null}
        </View>
      ) : null}
    </View>
  );
}
