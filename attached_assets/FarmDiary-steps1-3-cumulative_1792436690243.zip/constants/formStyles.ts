// Shared look for the plot and soil screens. Copies the existing form styling
// (same colours, DM Sans fonts, cards and chips as the harvest and season screens).
import { StyleSheet } from "react-native";
import COLORS from "./colors";

export const formStyles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  header: {
    flexDirection: "row", alignItems: "center", justifyContent: "space-between",
    paddingHorizontal: 16, paddingBottom: 12, paddingTop: 8,
    borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  headerTitle: { fontFamily: "DMSans_700Bold", fontSize: 18, color: COLORS.text, flex: 1, textAlign: "center" },
  headerSide: { minWidth: 56, alignItems: "flex-end" },
  saveBtn: { backgroundColor: COLORS.primary, borderRadius: 8, paddingHorizontal: 14, paddingVertical: 7 },
  saveBtnDisabled: { opacity: 0.4 },
  saveBtnText: { fontFamily: "DMSans_600SemiBold", fontSize: 14, color: COLORS.white },
  scroll: { flex: 1 },
  scrollContent: { padding: 16, gap: 16 },
  section: {
    backgroundColor: COLORS.cardBg, borderRadius: 14, padding: 16,
    borderWidth: 1, borderColor: COLORS.border, gap: 14,
  },
  sectionTitle: { fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.text },
  hint: { fontFamily: "DMSans_400Regular", fontSize: 12, color: COLORS.textMuted },
  body: { fontFamily: "DMSans_400Regular", fontSize: 14, color: COLORS.text, lineHeight: 20 },
  field: { gap: 6 },
  fieldLabel: { fontFamily: "DMSans_600SemiBold", fontSize: 13, color: COLORS.textSecondary },
  input: {
    backgroundColor: COLORS.background, borderWidth: 1, borderColor: COLORS.border,
    borderRadius: 10, padding: 12, fontFamily: "DMSans_400Regular", fontSize: 15, color: COLORS.text,
  },
  textArea: { minHeight: 90, textAlignVertical: "top" },
  chipRow: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  chip: {
    paddingHorizontal: 14, paddingVertical: 9, borderRadius: 10,
    backgroundColor: COLORS.borderLight, borderWidth: 1.5, borderColor: COLORS.border,
  },
  chipActive: { backgroundColor: COLORS.primarySurface, borderColor: COLORS.primary },
  chipText: { fontFamily: "DMSans_500Medium", fontSize: 13, color: COLORS.textSecondary },
  chipTextActive: { color: COLORS.primary, fontFamily: "DMSans_700Bold" },
  pill: { borderRadius: 8, paddingHorizontal: 9, paddingVertical: 4 },
  pillText: { fontFamily: "DMSans_600SemiBold", fontSize: 12 },
  primaryBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    backgroundColor: COLORS.primary, borderRadius: 14, padding: 15,
  },
  primaryBtnText: { fontFamily: "DMSans_700Bold", fontSize: 15, color: COLORS.white },
  outlineBtn: {
    flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8,
    borderRadius: 14, padding: 14, borderWidth: 1.5, borderColor: COLORS.primary, backgroundColor: COLORS.cardBg,
  },
  outlineBtnText: { fontFamily: "DMSans_700Bold", fontSize: 14, color: COLORS.primary },
  dangerText: { fontFamily: "DMSans_600SemiBold", fontSize: 14, color: COLORS.red, textAlign: "center", padding: 8 },
  emptyCard: {
    backgroundColor: COLORS.cardBg, borderRadius: 14, padding: 24, alignItems: "center", gap: 10,
    borderWidth: 1, borderColor: COLORS.border,
  },
  emptyTitle: { fontFamily: "DMSans_700Bold", fontSize: 16, color: COLORS.text, textAlign: "center" },
});

import type { Tone } from "../lib/soil";
export function toneColors(tone: Tone): { bg: string; fg: string } {
  switch (tone) {
    case "good": return { bg: COLORS.primarySurface, fg: COLORS.primary };
    case "warn": return { bg: COLORS.amberLight, fg: COLORS.amber };
    case "bad": return { bg: COLORS.redLight, fg: COLORS.red };
    default: return { bg: COLORS.borderLight, fg: COLORS.textSecondary };
  }
}
