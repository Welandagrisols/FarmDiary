// Crop templates and per-crop settings.
// IMPORTANT: these are DRAFT schedules for an agronomist to review. Fertilizer rates,
// spray choices and pre-harvest intervals must be confirmed against the product label,
// KEPHIS/PCPB guidance and local agronomic advice before they are used with farmers.
// Prices are left at 0 on purpose: enter real costs as inputs are bought.

import type { CropTemplate, CropTemplateStage, PlannedProduct } from "./farmData";

export type RiskLevel = "LOW" | "MEDIUM" | "HIGH";

export interface VarietyOption {
  label: string;
  blightRisk: RiskLevel; // stored as "blight_risk" in the data; shown as the crop's riskLabel
  maturityDays: number;
  note: string;
}

export interface PlanRow {
  category: string;
  subcategory: string;
  description: string;
  defaultAmount: string;
}

export interface HarvestUnit {
  key: string; // saved with each harvest record
  label: string; // singular, e.g. "Bag"
  plural: string; // e.g. "Bags"
  defaultKg: number; // typical kg per unit, 0 if unknown (e.g. bunches)
}

export interface CropMeta {
  riskLabel: string; // e.g. "Blight risk", "Disease pressure"
  plantingVerb: string; // "Planting", "Transplanting", "Sowing"
  varieties: VarietyOption[];
  prePlanting: PlanRow[];
  harvestUnits: HarvestUnit[];
}

const prod = (name: string, rate: string): PlannedProduct => ({
  name,
  rate,
  qty: "As needed",
  unitPrice: 0,
  unit: "unit",
});

const stage = (
  id: string,
  title: string,
  offsetDays: number,
  activityType: string,
  purpose: string,
  alert: string | null,
  products: PlannedProduct[] = []
): CropTemplateStage => ({
  id,
  title,
  offsetDays,
  activityType,
  purpose,
  alert,
  products,
  estimatedLaborCost: 0,
  estimatedTotalCost: 0,
});

const PRE_PLAN_COMMON = (seedLabel: string): PlanRow[] => [
  { category: "Pre-Planting", subcategory: "Land Lease / Rent", description: "Land lease / rent", defaultAmount: "" },
  { category: "Pre-Planting", subcategory: "Ploughing — 1st Pass", description: "Land preparation / ploughing", defaultAmount: "" },
  { category: "Pre-Planting", subcategory: "Soil Testing", description: "Soil test", defaultAmount: "" },
  { category: "Pre-Planting", subcategory: seedLabel, description: seedLabel, defaultAmount: "" },
  { category: "Pre-Planting", subcategory: "Basal Fertilizer (DAP / NPSb)", description: "Basal fertilizer / manure", defaultAmount: "" },
  { category: "Pre-Planting", subcategory: "Lime Application", description: "Lime (if soil is acidic)", defaultAmount: "" },
  { category: "Labor", subcategory: "Planting Labor", description: "Planting / transplanting labor", defaultAmount: "" },
];

// ── Potato (existing template; its settings moved here from the season setup screen) ──
export const POTATO_META: CropMeta = {
  riskLabel: "Blight risk",
  plantingVerb: "Planting",
  varieties: [
    { label: "Stephen's", blightRisk: "HIGH", maturityDays: 72, note: "72 days, HIGH blight risk" },
    { label: "Shangi", blightRisk: "MEDIUM", maturityDays: 82, note: "72–90 days, MEDIUM blight risk" },
    { label: "Kenya Mpya", blightRisk: "LOW", maturityDays: 95, note: "90–100 days, LOW blight risk" },
    { label: "Markies", blightRisk: "LOW", maturityDays: 110, note: "100–120 days, LOW blight risk" },
    { label: "Dutch Robjin", blightRisk: "MEDIUM", maturityDays: 95, note: "90–100 days, MEDIUM blight risk" },
    { label: "Unica", blightRisk: "MEDIUM", maturityDays: 95, note: "90–100 days, MEDIUM blight risk" },
    { label: "Custom", blightRisk: "MEDIUM", maturityDays: 90, note: "Enter your own variety" },
  ],
  prePlanting: [
    { category: "Pre-Planting", subcategory: "Land Lease / Rent", description: "Land lease / rent", defaultAmount: "8000" },
    { category: "Pre-Planting", subcategory: "Ploughing — 1st Pass", description: "Ploughing — 1st pass", defaultAmount: "3500" },
    { category: "Pre-Planting", subcategory: "Ploughing — 2nd Pass", description: "Ploughing — 2nd pass", defaultAmount: "3500" },
    { category: "Pre-Planting", subcategory: "Harrowing / Levelling", description: "Harrowing / levelling", defaultAmount: "2000" },
    { category: "Pre-Planting", subcategory: "Seed Tubers Purchase", description: "Seed tubers purchase", defaultAmount: "12000" },
    { category: "Pre-Planting", subcategory: "Basal Fertilizer (DAP / NPSb)", description: "Basal fertilizer (DAP / NPSb)", defaultAmount: "6400" },
    { category: "Labor", subcategory: "Planting Labor", description: "Planting labor", defaultAmount: "3000" },
    { category: "Pre-Planting", subcategory: "Lime Application", description: "Lime application", defaultAmount: "1500" },
  ],
  harvestUnits: [
    { key: "bag", label: "Bag", plural: "Bags", defaultKg: 110 },
    { key: "crate", label: "Crate", plural: "Crates", defaultKg: 25 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
  ],
};

// ── Coriander (direct-seeded, leaf production) ──
const CORIANDER: CropTemplate = {
  id: "coriander-template",
  cropType: "Coriander",
  variety: "Local (Dhania)",
  maturityDays: 40,
  germinationDays: 10,
  stopSprayingDaysBeforeHarvest: 7,
  prePlantingLeadDays: 7,
  blightRisk: "LOW",
  notes: "Short-season leafy crop. Plan staggered sowings for a steady supply. DRAFT: agronomist to review.",
  stages: [
    stage("cor-pre-planting", "Pre-Planting", -7, "Cost Capture",
      "Land preparation, soil test, manure or basal fertilizer, seed purchase and bed preparation.",
      "Use a fine, well-drained seedbed and clean seed."),
    stage("cor-planting", "Sowing", 0, "Planting",
      "Sow seed in rows on the prepared bed, cover lightly and water.",
      "Keep the seedbed moist until germination (about 7–14 days)."),
    stage("cor-weeding", "Thinning & Weeding", 14, "Weeding",
      "Thin to the recommended spacing and weed by hand.", null),
    stage("cor-topdress", "Top-Dressing", 20, "Fertilizer",
      "Light nitrogen top-dressing for leaf growth, based on soil test or agronomist advice.",
      "Avoid over-applying nitrogen: soft leaves are more prone to disease.",
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("cor-scouting", "Pest & Disease Scouting", 25, "Observation",
      "Check for aphids, leaf spots and powdery mildew. Spray only if needed and follow the label.",
      "Check the pre-harvest interval on the label before any spray."),
    stage("cor-harvest", "Harvest", 40, "Harvest",
      "Cut leaves at marketable size (about 35–45 days). Harvest in the morning and bunch quickly.",
      "Cool and sell quickly: coriander wilts within hours."),
  ],
};

export const CORIANDER_META: CropMeta = {
  riskLabel: "Disease pressure",
  plantingVerb: "Sowing",
  varieties: [
    { label: "Local (Dhania)", blightRisk: "LOW", maturityDays: 40, note: "About 35–45 days for leaf harvest" },
    { label: "Custom", blightRisk: "LOW", maturityDays: 40, note: "Enter your own variety" },
  ],
  prePlanting: PRE_PLAN_COMMON("Seed Purchase"),
  harvestUnits: [
    { key: "bunch", label: "Bunch", plural: "Bunches", defaultKg: 0 },
    { key: "sack", label: "Sack", plural: "Sacks", defaultKg: 0 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
  ],
};

// ── Tomato (transplanted, staked, repeated picking) ──
const TOMATO: CropTemplate = {
  id: "tomato-template",
  cropType: "Tomato",
  variety: "Hybrid / open-pollinated",
  maturityDays: 75,
  germinationDays: 7,
  stopSprayingDaysBeforeHarvest: 7,
  prePlantingLeadDays: 14,
  blightRisk: "HIGH",
  notes: "Offsets are in days after transplanting. Harvest is repeated over several weeks. DRAFT: agronomist to review.",
  stages: [
    stage("tom-pre-planting", "Pre-Transplant", -14, "Cost Capture",
      "Land preparation, soil test, lime if acidic, manure, seedlings (or nursery), stakes and irrigation set-up.",
      "Avoid fields where tomato, potato, capsicum or other solanaceous crops grew recently (bacterial wilt risk)."),
    stage("tom-planting", "Transplanting", 0, "Planting",
      "Transplant healthy seedlings with basal fertilizer and water in.", null),
    stage("tom-gap-filling", "Establishment & Gap Filling", 7, "Observation",
      "Replace dead seedlings and check establishment.", null),
    stage("tom-topdress-1", "First Top-Dressing & Weeding", 21, "Fertilizer",
      "Nitrogen top-dressing and weeding; mulch where possible.", null,
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("tom-staking", "Staking & Pruning", 21, "Crop Management",
      "Stake and train plants and prune as required for the variety.",
      "Remove infected leaves and clean tools between plants."),
    stage("tom-spray-1", "Preventive Spray Round 1", 21, "Spray",
      "Preventive fungicide and pest scouting (blights, whitefly, Tuta absoluta).",
      "Rotate modes of action and follow the label pre-harvest interval.",
      [prod("Fungicide (agronomist to specify)", "Per label")]),
    stage("tom-spray-2", "Preventive Spray Round 2", 35, "Spray",
      "Repeat preventive protection and scouting.",
      "Increase vigilance in wet weather.",
      [prod("Fungicide / insecticide (agronomist to specify)", "Per label")]),
    stage("tom-flowering", "Flowering: Second Top-Dressing & Calcium", 42, "Fertilizer",
      "Potassium and calcium support at flowering and fruit set; keep irrigation even.",
      "Uneven watering and low calcium can cause blossom-end rot.",
      [prod("Potassium / calcium source (agronomist to specify)", "Per soil test / label")]),
    stage("tom-spray-3", "Preventive Spray Round 3", 49, "Spray",
      "Continue protection until fruit set; stop on schedule before picking.",
      "Check the pre-harvest interval on the label.",
      [prod("Fungicide / insecticide (agronomist to specify)", "Per label")]),
    stage("tom-harvest", "Harvest (repeated picking)", 70, "Harvest",
      "Start picking at the colour stage the market wants; pick every few days for several weeks.",
      "Grade and pack carefully to reduce losses."),
  ],
};

export const TOMATO_META: CropMeta = {
  riskLabel: "Blight / disease risk",
  plantingVerb: "Transplanting",
  varieties: [
    { label: "Anna F1", blightRisk: "MEDIUM", maturityDays: 75, note: "Indeterminate hybrid, repeated picking" },
    { label: "Kilele F1", blightRisk: "MEDIUM", maturityDays: 75, note: "Indeterminate hybrid, repeated picking" },
    { label: "Cal J", blightRisk: "HIGH", maturityDays: 70, note: "Determinate open-pollinated" },
    { label: "Money Maker", blightRisk: "HIGH", maturityDays: 80, note: "Indeterminate open-pollinated" },
    { label: "Custom", blightRisk: "MEDIUM", maturityDays: 75, note: "Enter your own variety" },
  ],
  prePlanting: PRE_PLAN_COMMON("Seedlings / Seed Purchase"),
  harvestUnits: [
    { key: "crate", label: "Crate", plural: "Crates", defaultKg: 60 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
    { key: "sack", label: "Sack", plural: "Sacks", defaultKg: 0 },
  ],
};

// ── Cabbage (transplanted, single harvest) ──
const CABBAGE: CropTemplate = {
  id: "cabbage-template",
  cropType: "Cabbage",
  variety: "Hybrid / open-pollinated",
  maturityDays: 80,
  germinationDays: 7,
  stopSprayingDaysBeforeHarvest: 14,
  prePlantingLeadDays: 14,
  blightRisk: "MEDIUM",
  notes: "Offsets are in days after transplanting. Watch for diamondback moth and aphids. DRAFT: agronomist to review.",
  stages: [
    stage("cab-pre-planting", "Pre-Transplant", -14, "Cost Capture",
      "Land preparation, soil test, lime if acidic, manure, seedlings (or nursery) and irrigation set-up.",
      "Avoid fields where brassicas grew recently (clubroot and black rot risk)."),
    stage("cab-planting", "Transplanting", 0, "Planting",
      "Transplant healthy seedlings with basal fertilizer and water in.", null),
    stage("cab-weeding", "Gap Filling & First Weeding", 10, "Weeding",
      "Replace dead seedlings and weed carefully.", null),
    stage("cab-topdress-1", "First Top-Dressing", 21, "Fertilizer",
      "Nitrogen top-dressing for leaf growth.", null,
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("cab-spray-1", "Pest Scouting & Spray 1", 21, "Spray",
      "Scout for diamondback moth, aphids and cutworms; spray only when thresholds are reached.",
      "Rotate products and follow the label pre-harvest interval.",
      [prod("Insecticide (agronomist to specify)", "Per label")]),
    stage("cab-topdress-2", "Second Top-Dressing", 35, "Fertilizer",
      "Second nitrogen dose before head formation, based on crop condition and soil test.", null,
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("cab-spray-2", "Pest Scouting & Spray 2", 42, "Spray",
      "Continue scouting through head formation.",
      "Stop all sprays in time for the label pre-harvest interval.",
      [prod("Insecticide / fungicide (agronomist to specify)", "Per label")]),
    stage("cab-heading", "Head Formation", 55, "Observation",
      "Monitor head development, water stress and pests.", null),
    stage("cab-harvest", "Harvest", 80, "Harvest",
      "Cut firm, well-formed heads; harvest in batches as they mature.",
      "Heads split if left too long or after heavy rain."),
  ],
};

export const CABBAGE_META: CropMeta = {
  riskLabel: "Pest / disease risk",
  plantingVerb: "Transplanting",
  varieties: [
    { label: "Gloria F1", blightRisk: "MEDIUM", maturityDays: 75, note: "About 70–80 days after transplanting" },
    { label: "Copenhagen Market", blightRisk: "MEDIUM", maturityDays: 85, note: "About 80–90 days after transplanting" },
    { label: "Custom", blightRisk: "MEDIUM", maturityDays: 80, note: "Enter your own variety" },
  ],
  prePlanting: PRE_PLAN_COMMON("Seedlings / Seed Purchase"),
  harvestUnits: [
    { key: "head", label: "Head", plural: "Heads", defaultKg: 2 },
    { key: "sack", label: "Sack", plural: "Sacks", defaultKg: 0 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
  ],
};

// ── Onion (transplanted bulb onion) ──
const ONION: CropTemplate = {
  id: "onion-template",
  cropType: "Onion",
  variety: "Red bulb onion",
  maturityDays: 110,
  germinationDays: 7,
  stopSprayingDaysBeforeHarvest: 14,
  prePlantingLeadDays: 14,
  blightRisk: "MEDIUM",
  notes: "Offsets are in days after transplanting. Curing and storage decide how much of the crop is saleable. DRAFT: agronomist to review.",
  stages: [
    stage("oni-pre-planting", "Pre-Transplant", -14, "Cost Capture",
      "Land preparation, soil test, manure, seedlings (or nursery) and irrigation set-up.",
      "Use well-drained soil; waterlogging causes rot."),
    stage("oni-planting", "Transplanting", 0, "Planting",
      "Transplant seedlings at the recommended spacing and water in.", null),
    stage("oni-weeding", "First Weeding", 14, "Weeding",
      "Weed early: onions compete poorly with weeds.", null),
    stage("oni-topdress-1", "First Top-Dressing", 21, "Fertilizer",
      "Nitrogen top-dressing during leaf growth.", null,
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("oni-spray-1", "Thrips & Disease Scouting", 28, "Spray",
      "Scout for thrips, downy mildew and purple blotch; spray only when needed.",
      "Follow the label pre-harvest interval.",
      [prod("Insecticide / fungicide (agronomist to specify)", "Per label")]),
    stage("oni-topdress-2", "Second Top-Dressing", 42, "Fertilizer",
      "Final nitrogen dose before bulbing; avoid late nitrogen.",
      "Late nitrogen delays bulbing and reduces storage life.",
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("oni-spray-2", "Disease Protection Round", 56, "Spray",
      "Continue scouting during bulbing.", null,
      [prod("Fungicide (agronomist to specify)", "Per label")]),
    stage("oni-bulbing", "Bulbing & Irrigation Taper", 85, "Observation",
      "Reduce irrigation as bulbs mature and tops begin to fall.", null),
    stage("oni-harvest", "Harvest & Curing", 110, "Harvest",
      "Lift when most tops have fallen, then cure and dry well before storage or sale.",
      "Poor curing causes high storage losses."),
  ],
};

export const ONION_META: CropMeta = {
  riskLabel: "Disease risk",
  plantingVerb: "Transplanting",
  varieties: [
    { label: "Red Creole", blightRisk: "MEDIUM", maturityDays: 120, note: "Long-storing red onion" },
    { label: "Bombay Red", blightRisk: "MEDIUM", maturityDays: 110, note: "Red bulb onion" },
    { label: "Texas Grano", blightRisk: "MEDIUM", maturityDays: 110, note: "Short-day yellow onion" },
    { label: "Custom", blightRisk: "MEDIUM", maturityDays: 110, note: "Enter your own variety" },
  ],
  prePlanting: PRE_PLAN_COMMON("Seedlings / Seed Purchase"),
  harvestUnits: [
    { key: "net", label: "Net bag", plural: "Net bags", defaultKg: 50 },
    { key: "sack", label: "Sack", plural: "Sacks", defaultKg: 0 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
  ],
};

// ── Capsicum (transplanted, repeated picking) ──
const CAPSICUM: CropTemplate = {
  id: "capsicum-template",
  cropType: "Capsicum",
  variety: "Sweet pepper",
  maturityDays: 80,
  germinationDays: 7,
  stopSprayingDaysBeforeHarvest: 7,
  prePlantingLeadDays: 14,
  blightRisk: "MEDIUM",
  notes: "Offsets are in days after transplanting. Picking continues for many weeks. DRAFT: agronomist to review.",
  stages: [
    stage("cap-pre-planting", "Pre-Transplant", -14, "Cost Capture",
      "Land preparation, soil test, lime if acidic, manure, seedlings (or nursery), stakes and irrigation set-up.",
      "Avoid fields where solanaceous crops grew recently."),
    stage("cap-planting", "Transplanting", 0, "Planting",
      "Transplant healthy seedlings with basal fertilizer and water in.", null),
    stage("cap-gap-filling", "Establishment & Gap Filling", 7, "Observation",
      "Replace dead seedlings and check establishment.", null),
    stage("cap-topdress-1", "First Top-Dressing & Weeding", 21, "Fertilizer",
      "Nitrogen top-dressing and weeding.", null,
      [prod("Nitrogen top-dressing (e.g. CAN)", "Per soil test / agronomist advice")]),
    stage("cap-staking", "Staking", 28, "Crop Management",
      "Stake plants to support fruit load.", null),
    stage("cap-spray-1", "Pest & Disease Scouting", 28, "Spray",
      "Scout for thrips, mites, aphids and fungal or bacterial disease; spray only when needed.",
      "Follow the label pre-harvest interval.",
      [prod("Insecticide / fungicide (agronomist to specify)", "Per label")]),
    stage("cap-flowering", "Flowering: Top-Dressing & Calcium", 42, "Fertilizer",
      "Potassium and calcium support at flowering and fruit set; keep irrigation even.",
      "Uneven watering can cause blossom-end rot.",
      [prod("Potassium / calcium source (agronomist to specify)", "Per soil test / label")]),
    stage("cap-spray-2", "Protection Round 2", 56, "Spray",
      "Continue scouting and protection through fruiting.",
      "Check the pre-harvest interval before each spray.",
      [prod("Insecticide / fungicide (agronomist to specify)", "Per label")]),
    stage("cap-harvest", "Harvest (repeated picking)", 75, "Harvest",
      "Pick fruit at the size and colour the market wants; pick regularly.",
      "Handle gently and grade to reduce losses."),
  ],
};

export const CAPSICUM_META: CropMeta = {
  riskLabel: "Pest / disease risk",
  plantingVerb: "Transplanting",
  varieties: [
    { label: "California Wonder", blightRisk: "MEDIUM", maturityDays: 80, note: "Open-pollinated green pepper" },
    { label: "Yolo Wonder", blightRisk: "MEDIUM", maturityDays: 80, note: "Open-pollinated green pepper" },
    { label: "Custom", blightRisk: "MEDIUM", maturityDays: 80, note: "Enter your own variety" },
  ],
  prePlanting: PRE_PLAN_COMMON("Seedlings / Seed Purchase"),
  harvestUnits: [
    { key: "crate", label: "Crate", plural: "Crates", defaultKg: 0 },
    { key: "kg", label: "Kg", plural: "Kg", defaultKg: 1 },
    { key: "sack", label: "Sack", plural: "Sacks", defaultKg: 0 },
  ],
};

export const EXTRA_CROP_TEMPLATES: CropTemplate[] = [CORIANDER, TOMATO, CABBAGE, ONION, CAPSICUM];

const META_BY_ID: Record<string, CropMeta> = {
  "potato-template-stephen-shangi": POTATO_META,
  "coriander-template": CORIANDER_META,
  "tomato-template": TOMATO_META,
  "cabbage-template": CABBAGE_META,
  "onion-template": ONION_META,
  "capsicum-template": CAPSICUM_META,
};

// Falls back to the potato settings so existing seasons keep working unchanged.
export function getCropMeta(templateId?: string | null): CropMeta {
  return (templateId && META_BY_ID[templateId]) || POTATO_META;
}

// ── Harvest unit helpers ──
export function unitFor(meta: CropMeta, key?: string | null): { label: string; plural: string } {
  const k = key || "bag";
  const found = meta.harvestUnits.find((u) => u.key === k);
  if (found) return { label: found.label, plural: found.plural };
  const label = k.charAt(0).toUpperCase() + k.slice(1);
  return { label, plural: label + "s" };
}

// Totals in the unit used by most records. "mixed" is true when records used different units.
export function summarizeHarvest(
  records: { bags: number; unit?: string | null }[],
  meta: CropMeta
): { qty: number; label: string; plural: string; mixed: boolean } {
  const recCount: Record<string, number> = {};
  const qty: Record<string, number> = {};
  records.forEach((r) => {
    const k = r.unit || "bag";
    recCount[k] = (recCount[k] || 0) + 1;
    qty[k] = (qty[k] || 0) + r.bags;
  });
  const keys = Object.keys(recCount);
  const main = keys.sort((a, b) => recCount[b] - recCount[a])[0] || meta.harvestUnits[0].key;
  const u = unitFor(meta, main);
  return { qty: qty[main] || 0, label: u.label, plural: u.plural, mixed: keys.length > 1 };
}

// ── Crop families, used for rotation warnings ──
const FAMILY_BY_ID: Record<string, { family: string; risks: string }> = {
  "potato-template-stephen-shangi": { family: "Solanaceae", risks: "bacterial wilt, blights and nematodes" },
  "tomato-template": { family: "Solanaceae", risks: "bacterial wilt, blights and nematodes" },
  "capsicum-template": { family: "Solanaceae", risks: "bacterial wilt, blights and nematodes" },
  "cabbage-template": { family: "Brassicaceae", risks: "clubroot, black rot and diamondback moth build-up" },
  "onion-template": { family: "Alliaceae", risks: "white rot, downy mildew and thrips build-up" },
  "coriander-template": { family: "Apiaceae", risks: "soil-borne disease and pest carry-over" },
};

export function getCropFamily(templateId?: string | null): { family: string; risks: string } | null {
  return (templateId && FAMILY_BY_ID[templateId]) || null;
}
