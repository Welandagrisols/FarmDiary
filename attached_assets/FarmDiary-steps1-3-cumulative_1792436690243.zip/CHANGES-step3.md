# Step 3: soil module (patch on top of step 2)

Apply step 2 first. Then copy these files over your project (same paths) and run the SQL.
No keystore or credentials are in this zip.

## Database (run once, in this order)
1. `scripts/supabase-patch-fixed.sql` (already run) and `scripts/rls-hardening.sql` (step 1)
2. `scripts/soil-module.sql` (NEW): creates `plots` and `soil_tests` with row-level security.
The app keeps working if you have not run it yet; the Plots screen will just be empty and saving a plot will show an error.

## What's new
- **Plots**: a named piece of land that persists across crop cycles (More > Plots & Soil).
- **Soil tests**: enter a lab report the way the KALRO NARL report is laid out: each result has a value and the lab's own class (Adequate, Deficient, Mod. acid ...), plus lab number, sample name, depth, crops to be grown, and the lab's recommendation text.
- **Result screen**: flags results that need attention using the lab's class. If the lab gave no class, the app shows a draft estimate marked "est.".
- **Fertilizer and lime plan**: turn the lab recommendation into plan items per crop (product, rate, timing, estimated cost). The app does not calculate lime or fertilizer rates itself; you or the lab decide.
- **Retest reminders**: per plot (6, 12 or 24 months), shown on the Plots screen and in More.
- **Link plots to crop cycles**: choose a plot for Section A and B when starting a season, or in Season Control > Edit for existing seasons.
- **Rotation check**: warns when the same crop family was grown on the plot in the last 3 years (potato, tomato and capsicum count as one family).
- **Farm overview of cycles**: the Plots screen lists each plot's active crop cycles. Tap one to switch to it.

## Files
New: components/PlotPicker.tsx, constants/formStyles.ts, lib/soil.ts, scripts/soil-module.sql,
app/plots.tsx, app/plot-detail.tsx, app/add-plot.tsx, app/add-soil-test.tsx, app/soil-result.tsx
Changed: app/_layout.tsx, app/(tabs)/more.tsx, app/season-setup.tsx, app/season-control.tsx,
constants/cropTemplates.ts, context/FarmContext.tsx, lib/storage.ts

## Test checklist (phone)
1. Run soil-module.sql. Open More > Plots & Soil: empty state shows.
2. Add a plot (name, acres, water, retest months). It appears in the list.
3. Open the plot > Add soil test. Enter the KALRO sample: pH 5.16 (Mod. acid), exch. acidity 0.4, N 0.41, OC 4.06, P Mehlich 39.6, K 1.18, Ca 5.4, Mg 3.71, Mn 0.65, Cu 0.26 (Deficient), Fe 87.5, Zn 21.12, Na 0.14, all others Adequate. Paste the recommendation text.
4. Result screen: "2 results need attention" (pH and copper). Add plan items (e.g. Agricultural lime, 100 kg/acre, at least 2 months before planting).
5. More > Season Control > Edit: link the potato season's Section A to the plot. The plot detail shows the cycle.
6. Start a new Tomato season on the same plot: the rotation warning appears (Solanaceae).
7. Start an Onion season on that plot: no warning, and the soil plan items for onion show under the plot picker.
8. Plots screen: tap a cycle chip to switch to that season.
9. Turn off the internet, reopen Plots: the last loaded plots and tests still show (read-only offline).

## Known limits
- Soil data is read from a cache offline, but adding a plot or test offline fails. Your existing screens (costs, activities, harvests) behave the same way today: the offline write queue in the code is not connected to them. Wiring it in is a separate, larger step.
- Estimate cut-offs for pH, carbon, N, Olsen P, K, Ca and Mg are draft values for when the lab gives no class. Check them.
- Soil values are typed in by hand. Reading a lab PDF automatically would need a server-side key and is a possible next step.
- A season still has at most two sections (A and B); use separate cycles for more.
