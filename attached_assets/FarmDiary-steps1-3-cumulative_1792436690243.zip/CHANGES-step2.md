# Step 2: multi-crop (patch)

Copy the files in this zip over your project, same paths. Then run `scripts/multi-crop-upgrade.sql` in Supabase.
Run the SQL BEFORE recording a non-potato harvest in a unit other than bags. Potato harvests work either way.
No keystore or credentials are in this zip.

## What's new
- Crops: Potato (unchanged), Coriander, Tomato, Cabbage, Onion, Capsicum. Each has its own schedule, varieties, pre-planting cost rows and harvest units. They are DRAFTS for agronomist review (spray choices, rates, pre-harvest intervals).
- New season setup: choose the crop first. The schedule, varieties and cost planner follow it.
- Every season uses its own crop's schedule (existing potato seasons are unchanged).
- Harvest: choose bag / crate / bunch / head / net bag / sack / kg per crop, optional grade, fractional quantities, repeated pickings.
- Harvest, cost and report screens now show the active season only (before, they mixed all seasons).
- Dashboard shows a "Set up your first farm" card for new users with no farm.
- Labels follow the crop ("Blight risk" for potato, "Disease risk" etc. for others).

## Files
New: constants/cropTemplates.ts, scripts/multi-crop-upgrade.sql
Changed: constants/farmData.ts, context/FarmContext.tsx, lib/storage.ts, app/season-setup.tsx, app/add-harvest.tsx, app/harvest.tsx,
app/season-report.tsx, app/season-control.tsx, app/cost-breakdown.tsx, app/farm-setup.tsx, app/(tabs)/index.tsx, app/(tabs)/costs.tsx,
app/(tabs)/more.tsx, components/ActivityLogDetailModal.tsx

## Test checklist (on your phone)
1. Open the app: your potato season, schedule, costs and harvests look exactly as before.
2. More > Season: start a new season, choose Tomato. Check the varieties change and the cost planner rows have no amounts.
3. Finish setup. Schedule tab shows the tomato stages with dates counted from your planting date.
4. Record a harvest: units show Crates / Kg / Sacks. Save one in crates, one in kg. Harvest screen shows the totals.
5. Switch back to the potato season (Season Control). Costs, harvests and totals are the potato ones only.
6. Season Report for each season: labels and units match the crop.
7. Start a coriander season. Record a harvest in bunches with no weight. It should save.
8. Sign in as a brand-new user: dashboard shows "Set up your first farm".

## Known limits (next steps)
- A season still has at most two blocks (Section A and B). A real plot record that persists across cycles comes with the soil module.
- Estimated costs are blank for the new crops (enter real costs as you buy).
- Not tested on a device or against your Supabase.
