-- ============================================================
-- Farm Diary: multi-crop upgrade (step 2)
-- Run in the Supabase SQL editor. Safe to re-run. Additive only:
-- no data is deleted or rewritten.
-- ============================================================

-- Quantities can now be fractional (e.g. 37.5 kg, 2.5 crates).
ALTER TABLE public.harvest_records ALTER COLUMN bags TYPE NUMERIC;

-- What the quantity is counted in ('bag', 'crate', 'bunch', 'kg', ...). Older rows are bags.
ALTER TABLE public.harvest_records ADD COLUMN IF NOT EXISTS unit TEXT NOT NULL DEFAULT 'bag';

-- Optional quality grade for each harvest or picking.
ALTER TABLE public.harvest_records ADD COLUMN IF NOT EXISTS grade TEXT;

-- Check: all existing harvest rows should show unit = 'bag'.
-- SELECT unit, COUNT(*) FROM public.harvest_records GROUP BY unit;
