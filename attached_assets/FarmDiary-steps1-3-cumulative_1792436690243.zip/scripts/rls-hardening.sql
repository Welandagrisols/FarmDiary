-- ============================================================
-- Farm Diary: RLS hardening (step 1)
-- Run AFTER scripts/supabase-patch-fixed.sql. Safe to re-run.
-- Run in the Supabase SQL editor.
-- ============================================================

-- 1. A new user can only register as a 'farmer'.
--    (Before: any signed-in user could insert their own profile with role 'admin'.)
DROP POLICY IF EXISTS "profiles_insert" ON public.user_profiles;
CREATE POLICY "profiles_insert" ON public.user_profiles
  FOR INSERT
  WITH CHECK ((id = auth.uid()::text AND role = 'farmer') OR is_admin());

-- 2. Backstop: only an admin can assign or change roles.
--    Allowed when auth.uid() is null (SQL editor / service role), so you can still bootstrap the first admin.
CREATE OR REPLACE FUNCTION public.guard_profile_role()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF auth.uid() IS NOT NULL AND NOT public.is_admin() THEN
    IF TG_OP = 'INSERT' AND NEW.role <> 'farmer' THEN
      RAISE EXCEPTION 'Only an admin can assign roles';
    ELSIF TG_OP = 'UPDATE' AND NEW.role IS DISTINCT FROM OLD.role THEN
      RAISE EXCEPTION 'Only an admin can change roles';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_profile_role_trg ON public.user_profiles;
CREATE TRIGGER guard_profile_role_trg
  BEFORE INSERT OR UPDATE ON public.user_profiles
  FOR EACH ROW EXECUTE FUNCTION public.guard_profile_role();

-- 3. A farm can only be handed to another user by an admin.
DROP POLICY IF EXISTS "farms_update" ON public.farms;
CREATE POLICY "farms_update" ON public.farms
  FOR UPDATE
  USING (user_id = auth.uid()::text OR is_admin())
  WITH CHECK (user_id = auth.uid()::text OR is_admin());

-- 4. app_meta had no RLS, so anyone with the public key could read or write it.
DO $$
BEGIN
  IF to_regclass('public.app_meta') IS NOT NULL THEN
    ALTER TABLE public.app_meta ENABLE ROW LEVEL SECURITY;
    DROP POLICY IF EXISTS "app_meta_authenticated" ON public.app_meta;
    CREATE POLICY "app_meta_authenticated" ON public.app_meta
      FOR ALL TO authenticated USING (true) WITH CHECK (true);
  END IF;
END $$;

-- ============================================================
-- VERIFY (run these and read the results)
-- ============================================================
-- a) Tables in public with RLS OFF (expect no rows):
-- SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
--  WHERE n.nspname = 'public' AND c.relkind = 'r' AND NOT c.relrowsecurity;
--
-- b) Every live policy (expect no 'user_id IS NULL' and no 'true' except app_meta):
-- SELECT tablename, policyname, cmd, qual, with_check FROM pg_policies
--  WHERE schemaname = 'public' ORDER BY tablename, policyname;
--
-- c) Farms nobody owns (assign them in the admin screen):
-- SELECT id, name FROM public.farms WHERE user_id IS NULL;
--
-- d) Who is an admin (expect only you):
-- SELECT email, role FROM public.user_profiles WHERE role = 'admin';
