-- ============================================================
-- Farm Diary: soil module (step 3)
-- Run in the Supabase SQL editor AFTER supabase-patch-fixed.sql
-- and scripts/rls-hardening.sql. Safe to re-run. Additive only.
-- ============================================================

-- Plots: a named piece of land that persists across crop cycles.
CREATE TABLE IF NOT EXISTS public.plots (
  id            text PRIMARY KEY,
  farm_id       text NOT NULL,
  name          text NOT NULL,
  acres         numeric NOT NULL DEFAULT 0,
  water_source  text,
  retest_months integer NOT NULL DEFAULT 12,
  notes         text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- Soil tests: one row per lab report for a plot. Fields follow the KALRO NARL report layout:
-- each result has a value and the lab's own class (Adequate, Deficient, Mod. acid, ...).
CREATE TABLE IF NOT EXISTS public.soil_tests (
  id               text PRIMARY KEY,
  farm_id          text NOT NULL,
  plot_id          text NOT NULL,
  test_date        text NOT NULL,          -- date the sample was taken
  report_date      text,                   -- date the lab reported
  lab              text,
  lab_no           text,
  sample_label     text,
  depth_cm         text,
  crops_intended   text,                   -- "Crop(s) to be grown" on the report
  cost_kes         numeric,
  ph               numeric,
  exch_acidity     numeric,                -- meq%
  total_n          numeric,                -- %
  organic_carbon   numeric,                -- %
  p_mehlich        numeric,                -- ppm
  p_olsen          numeric,                -- ppm
  k_me             numeric,                -- meq%
  ca_me            numeric,                -- meq%
  mg_me            numeric,                -- meq%
  mn_me            numeric,                -- meq%
  cu_ppm           numeric,
  fe_ppm           numeric,
  zn_ppm           numeric,
  na_me            numeric,                -- meq%
  ec               numeric,                -- mS/cm
  classes          jsonb NOT NULL DEFAULT '{}'::jsonb,   -- lab class per result, e.g. {"ph":"Mod. acid"}
  lab_recommendation text,                 -- the lab's "Interpretation and Fertilizer Recommendation" text
  notes            text,
  plan             jsonb NOT NULL DEFAULT '[]'::jsonb,   -- our plan items (product, rate, timing, crop)
  created_at       timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS plots_farm_idx ON public.plots (farm_id);
CREATE INDEX IF NOT EXISTS soil_tests_farm_idx ON public.soil_tests (farm_id);
CREATE INDEX IF NOT EXISTS soil_tests_plot_idx ON public.soil_tests (plot_id);

ALTER TABLE public.plots      ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.soil_tests ENABLE ROW LEVEL SECURITY;

-- Same access pattern as the other farm tables: owner of the farm, or an admin.
DROP POLICY IF EXISTS "plots_select" ON public.plots;
DROP POLICY IF EXISTS "plots_insert" ON public.plots;
DROP POLICY IF EXISTS "plots_update" ON public.plots;
DROP POLICY IF EXISTS "plots_delete" ON public.plots;
CREATE POLICY "plots_select" ON public.plots FOR SELECT USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "plots_insert" ON public.plots FOR INSERT WITH CHECK (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "plots_update" ON public.plots FOR UPDATE USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "plots_delete" ON public.plots FOR DELETE USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());

DROP POLICY IF EXISTS "soil_tests_select" ON public.soil_tests;
DROP POLICY IF EXISTS "soil_tests_insert" ON public.soil_tests;
DROP POLICY IF EXISTS "soil_tests_update" ON public.soil_tests;
DROP POLICY IF EXISTS "soil_tests_delete" ON public.soil_tests;
CREATE POLICY "soil_tests_select" ON public.soil_tests FOR SELECT USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "soil_tests_insert" ON public.soil_tests FOR INSERT WITH CHECK (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "soil_tests_update" ON public.soil_tests FOR UPDATE USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());
CREATE POLICY "soil_tests_delete" ON public.soil_tests FOR DELETE USING (farm_id IN (SELECT my_farm_ids()) OR is_admin());

-- Check (expect both tables listed with RLS on):
-- SELECT relname, relrowsecurity FROM pg_class WHERE relname IN ('plots','soil_tests');
