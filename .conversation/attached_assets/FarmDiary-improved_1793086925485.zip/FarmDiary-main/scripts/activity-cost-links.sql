-- Farm Diary — link cost entries to the activity that created them.
-- Safe to re-run. Back up first. Nothing here deletes or rewrites existing amounts.
--
-- Part 1 adds costs.activity_log_id. Until it exists the app keeps working exactly as before
-- (it checks for the column and simply does not link anything).
-- Part 2 links OLD cost entries to their activity, but only when the match is exact and unambiguous.
-- Anything it cannot match with certainty is left unlinked; those entries keep working as ordinary costs.

-- ── Part 1: the link ─────────────────────────────────────────────────────────────────────────
ALTER TABLE public.costs
  ADD COLUMN IF NOT EXISTS activity_log_id TEXT REFERENCES public.activity_logs(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS costs_activity_log_idx ON public.costs (activity_log_id);

-- Activities record days as a decimal (half days); some older schemas made the cost column an integer,
-- which would reject a half-day labour cost. Widening integer -> numeric loses nothing.
ALTER TABLE public.costs ALTER COLUMN days_worked TYPE NUMERIC;

-- ── Part 2: link existing entries (exact matches only) ───────────────────────────────────────
-- A labour entry matches an activity when farm, crop cycle, block, date, the text "Labor — <activity name>"
-- and the amount all agree. An input entry matches when farm, cycle, block, date, product name and
-- the product's total all agree. If an entry could belong to more than one activity (for example two identical
-- jobs on the same day) it is skipped.
WITH candidates AS (
  SELECT c.id AS cost_id, a.id AS log_id
  FROM public.costs c
  JOIN public.activity_logs a
    ON a.farm_id = c.farm_id
   AND a.season_id = c.season_id
   AND a.actual_date = c.cost_date
   AND a.section_id IS NOT DISTINCT FROM c.section_id
  WHERE c.activity_log_id IS NULL
    AND (
      (c.cost_category = 'Labor'
        AND a.labor_cost_kes > 0
        AND btrim(c.description) = 'Labor — ' || btrim(a.activity_name)
        AND c.amount_kes = a.labor_cost_kes)
      OR
      (c.cost_category = 'Inputs'
        AND EXISTS (
          SELECT 1
          FROM jsonb_array_elements(CASE WHEN jsonb_typeof(a.products_used) = 'array' THEN a.products_used ELSE '[]'::jsonb END) p
          WHERE btrim(p ->> 'name') = btrim(c.description)
            AND (CASE WHEN p ->> 'total' ~ '^-?[0-9]+(\.[0-9]+)?$' THEN (p ->> 'total')::numeric END) = c.amount_kes))
    )
), unambiguous AS (
  SELECT cost_id, min(log_id) AS log_id
  FROM candidates
  GROUP BY cost_id
  HAVING count(DISTINCT log_id) = 1
)
UPDATE public.costs c
SET activity_log_id = u.log_id
FROM unambiguous u
WHERE c.id = u.cost_id
  AND c.activity_log_id IS NULL;

-- How it went:
SELECT
  count(*) FILTER (WHERE activity_log_id IS NOT NULL) AS linked_entries,
  count(*) FILTER (WHERE activity_log_id IS NULL AND cost_category IN ('Labor', 'Inputs')) AS unlinked_labour_and_input_entries
FROM public.costs;
