# Farm Diary — upgrade notes

This folder is the full app with every improvement made in this review folded in. Details are in `docs/improvements/`.

## What is NOT in this zip (on purpose)
`credentials.json` and `farm-diary.keystore` were left out so signing secrets are not passed around in a zip.
If you replace your whole folder with this one, copy your own two files back in first.
Please also check whether they were ever pushed to GitHub; if they were, treat the keystore password as exposed.

## To switch everything on (in this order)
1. **Back up your Supabase database.**
2. In the Supabase SQL editor run, in this order (each is safe to re-run):
   - `scripts/activity-cost-links.sql` (links costs to activities, fixes half-day labour, backfills old entries exactly)
   - `scripts/soil-module.sql` (plots, soil tests, private bucket for lab reports). It needs `scripts/sales-control.sql` to have been run already.
3. On the server add the secret `ANTHROPIC_API_KEY` (optional `SOIL_PARSE_MODEL`). Without it, lab reports are still saved but not read.
   After you have migrated old data, set `DISABLE_MIGRATE=true` to switch the migrate endpoint off.
4. Make a **new native build** (EAS). The camera permission for scanning reports only arrives with a new build.
5. Restart the app once after step 2.
6. **On Replit:** replace your project files with this folder (keep your own `credentials.json` and keystore), then run `npm install` once. The design refresh adds the Manrope font package and removes DM Sans, so a fresh install is needed.

## What improved
- **Revenue and costs agree everywhere**: Dashboard, Costs tab, Season Report, Season History and Export use one rule (`lib/season-finance.ts`).
- **Closed crop cycles are read-only**, with a clear message; closing a season warns about unchecked sales.
- **Activities and costs are linked**: editing an activity shows and applies the matching ledger change and stock change; removing one asks what to do with its costs.
- **Soil tests and plots**: tests belong to the farm or a plot (not a season); photo/PDF reports (KALRO format first) are stored, read and saved straight away, kept exactly as printed, and checked by you before confirming.
- **Fertilizer plan** from a soil test: the lab's (or an advisor's) advice scaled to the plot's area, nutrients totalled, substitutes and cost, shareable as text. It never invents rates (see `docs/improvements/FERTILIZER-PLAN.md`).
- **Design refresh** following your design guide: Manrope, larger text, white shadowed cards, dark hero cards, a floating tab bar with a green active pill, and a brand row on each tab. Before/after pictures are in `docs/improvements/screenshots/`; details in `docs/improvements/DESIGN.md`.
- **Safer migration endpoint**, backup import that no longer duplicates or mixes cycles, correct input cost categories, error messages that actually reach the screen.

## What was checked
82 automated tests, TypeScript, lint (0 errors), an Android bundle and the server build all pass. Both new SQL scripts were run on a real PostgreSQL 16.
**Not checked:** the app on a phone, your live database, and the real report reader on your PDF (needs your API key).

## Known gaps
Older activities stay unlinked unless the backfill matches them exactly; you still cannot edit a cost entry directly; removing an activity does not return its stock;
sales, plots, soil tests and personal expenses are not in the JSON backup; no database-level block on writing to a closed cycle; two-user data isolation has not been tested.
