---
name: Season finance rules
description: One shared rule for season totals, read-only closed cycles, single-cycle backups.
---

# Season money totals and closed cycles

- Every screen that shows costs, revenue or net for a crop cycle (Dashboard, Costs tab, Season Report, Season History, Export) must use `lib/season-finance.ts`. Never re-add inline `reduce` totals.
- Revenue rule: sales with status `recorded` or `void_requested` count; `pending_check` and `discount_pending` are shown separately and not counted; voided never count. New harvest entries are saved with revenue 0, so only old harvest records with no `recorded_by` add revenue (owners/managers/admins only). Counting both would double-count.
- A closed crop cycle is read-only: `lib/season-rules.ts` (`assertSeasonOpen`) is enforced in `FarmContext` for costs, activities, observations and harvests, and in the sales screen. Screens must show the thrown message (`lib/write-errors.ts`), never swallow it.
- Backups (`app/export.tsx`, `lib/backup-import.ts`) hold ONE crop cycle (`format_version` 2). Older mixed-cycle files are refused on import. Sales, plots, soil tests and personal expenses are not in the backup.
