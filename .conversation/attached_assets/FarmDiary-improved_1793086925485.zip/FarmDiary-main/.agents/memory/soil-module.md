---
name: Soil module
description: Soil tests belong to a farm or plot, not a season; reports are read on the server and kept as printed.
---

# Soil tests and plots

- A soil test belongs to the whole farm (`plot_id` null) or to a plot, never to a season, so it stays usable across seasons and crop cycles. Plots are archived, not deleted.
- Lab reports (photo or PDF) are sent to `POST /api/farms/:farmId/soil/parse` (`server/soil.ts`): the original is stored in the private `soil-reports` bucket, read by the Anthropic API (needs `ANTHROPIC_API_KEY`, optional `SOIL_PARSE_MODEL`), and every sample saved at once. If reading fails the file is still saved and can be re-read or typed in.
- Values are kept exactly as the lab printed them (unit, method, rating wording). Never convert or calculate. Suspicious values are flagged for a person to check; results stay "to confirm" until confirmed. Cleaning rules live in `lib/soil.ts`.
- Reference format: KALRO National Agricultural Research Laboratories "Soil Test Report" (day-first dates, only a received date, meq% and ppm units, value + class columns, written fertilizer advice). Fixture: `tests/fixtures/kalro-narl-sample.ts`.
- Do not record the farmer's name, address or phone number from a report.
- Database: `scripts/soil-module.sql`.

## Fertilizer plan
- `lib/fertilizer.ts` only does arithmetic on advice that already exists (the lab's, or advice typed in by an advisor and marked `source: "advisor"`). Never add made-up recommendations, soil thresholds or default fertilizer rates.
- A rate is scaled only when its basis (per acre/ha/plant/tree/hole) is written; otherwise show it as written and say so. Never guess a basis.
- Grades: written NPK grade first, then typical declared grades (`STANDARD_PRODUCTS`), and say when a grade is assumed.
