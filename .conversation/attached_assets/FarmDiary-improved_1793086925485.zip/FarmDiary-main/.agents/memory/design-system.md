---
name: Design system
description: Colours, Manrope type scale, white shadowed cards, ink hero cards, floating green tab bar.
---

- Tokens live in `constants/colors.ts` (`COLORS`, `CARD_SHADOW`, `CATEGORY_COLORS`). Font is Manrope. Never use a font size under 12.
- Cards are white, radius 20, `...CARD_SHADOW`, no border. Hero cards and selected filter pills use `COLORS.ink`; buttons and the active tab use `COLORS.primary`. No gradients.
- Main tabs use `components/FloatingTabBar.tsx` and start with `components/BrandRow.tsx`. Do not mount `SyncBadge`: the sync provider was never turned on in this app and using it crashes every tab.
- Styles only: do not change logic when restyling.
