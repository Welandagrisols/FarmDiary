---
name: Activity cost links
description: Activities and their cost entries are linked and edited together.
---

# Activities and their cost entries are linked

- Cost entries created by an activity carry `costs.activity_log_id` (needs `scripts/activity-cost-links.sql`; the app probes for the column in `lib/activity-links.ts` and works without it).
- Editing an activity goes through `planActivityCostSync` in `lib/activity-costs.ts`: update changed amounts, create entries only for labour/products newly added, delete entries for removed ones, move linked entries with the date. Never recreate an entry that is missing. Show the plan to the person before saving. Order: ledger, then activity, then stock.
- Removing an activity with linked costs asks: keep the costs (unlinks them) or remove them too (`lib/confirm-remove-activity.ts`).
- `relatedCostsForLog` decides which costs show under an activity: linked entries first, same-day matching only for old unlinked data.
- Input cost subcategory comes from the product (`lib/cost-subcategory.ts`), never a fixed "Fungicide".
