import React, { useEffect, useState, useCallback } from "react";
import { BrandRow } from "@/components/BrandRow";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  RefreshControl,
  Platform,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { router } from "expo-router";
import { Ionicons } from "@expo/vector-icons";
import { useFarm } from "@/context/FarmContext";
import COLORS, { CARD_SHADOW } from "@/constants/colors";
import { getTemplate } from "@/constants/farmData";
import { formatHarvestTotals, getCropMeta } from "@/constants/cropTemplates";
import {
  getGrowthStage,
  getDaysSincePlanting,
  getDaysUntil,
  formatKES,
  formatDate,
  getSeasonBlocks,
} from "@/lib/storage";
import { FarmRole, getFarmRole, getSales, SaleRecord } from "@/lib/sales-storage";
import { seasonCostTotal, seasonFinance } from "@/lib/season-finance";

function getUrgencyColor(daysUntil: number) {
  if (daysUntil <= 0) return COLORS.red;
  if (daysUntil <= 3) return COLORS.red;
  if (daysUntil <= 7) return COLORS.amber;
  return COLORS.primary;
}

function getUrgencyBg(daysUntil: number) {
  if (daysUntil <= 3) return COLORS.redLight;
  if (daysUntil <= 7) return COLORS.amberLight;
  return COLORS.primarySurface;
}

function getActivityTypeIcon(type: string) {
  switch (type) {
    case "Spray": return "water-outline";
    case "Herbicide": return "leaf-outline";
    case "Earthing Up + Fertilizer":
    case "Earthing Up": return "layers-outline";
    case "Harvest": return "basket-outline";
    case "Observation": return "eye-outline";
    default: return "checkmark-circle-outline";
  }
}

export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const {
    costs,
    refresh,
    retryLoad,
    loadError,
    getCompletedActivityIds,
    getNextActivity,
    getLastSprayDate,
    activeSeason,
    currentSchedule,
    harvestRecords,
    activeFarm,
    inventory,
  } = useFarm();
  const [dismissedAlert, setDismissedAlert] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [sales, setSales] = useState<SaleRecord[]>([]);
  const [farmRole, setFarmRole] = useState<FarmRole>("none");
  const [salesLoadError, setSalesLoadError] = useState("");
  const [salesRefreshToken, setSalesRefreshToken] = useState(0);

  useEffect(() => {
    let current = true;
    const loadSales = async () => {
      if (!activeFarm?.id || !activeSeason?.id) {
        setSales([]);
        setFarmRole("none");
        return;
      }
      try {
        const role = await getFarmRole(activeFarm.id);
        if (!current) return;
        setFarmRole(role);
        if (["admin", "owner", "manager", "seller"].includes(role)) {
          setSales(await getSales(activeFarm.id, activeSeason.id));
        } else {
          setSales([]);
        }
        setSalesLoadError("");
      } catch (error: any) {
        if (!current) return;
        setSales([]);
        setSalesLoadError(error?.message || "Sales data could not be loaded.");
      }
    };
    loadSales();
    return () => { current = false; };
  }, [activeFarm?.id, activeSeason?.id, salesRefreshToken]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await refresh();
    setSalesRefreshToken((value) => value + 1);
    setRefreshing(false);
  }, [refresh]);

  const completedIds = getCompletedActivityIds();
  const plannedBudget = currentSchedule.reduce((sum, a) => sum + a.estimatedTotalCost, 0);
  const totalSpent = seasonCostTotal(costs, activeSeason?.id ?? "");
  const seasonHarvest = harvestRecords.filter((record) => record.season_id === activeSeason?.id);
  const cropMeta = getCropMeta(activeSeason?.template_id);
  const harvestQuantitySummary = formatHarvestTotals(seasonHarvest, cropMeta);
  const budgetPercent = plannedBudget > 0 ? Math.min((totalSpent / plannedBudget) * 100, 100) : null;
  const blocks = getSeasonBlocks(activeSeason);
  const totalAcres = blocks.reduce((sum, block) => sum + (Number(block.acres) || 0), 0);
  const canViewFinancials = ["admin", "owner", "manager"].includes(farmRole);
  const finance = seasonFinance({
    seasonId: activeSeason?.id ?? "",
    costs,
    harvest: harvestRecords,
    sales,
    includeHarvestRevenue: canViewFinancials,
  });
  const totalRevenue = finance.revenue;
  const netProfit = finance.net;

  const lowStockItems = inventory.filter((item) => {
    if (item.low_stock_threshold == null) return false;
    const remaining = item.quantity_purchased - item.quantity_used;
    return remaining <= item.low_stock_threshold;
  });

  const hasOverdue = currentSchedule.some((activity) => {
    if (completedIds.includes(activity.id)) return false;
    const plannedDate = activity.plannedDate || activity.plannedDateA || activity.plannedDateB;
    return plannedDate ? getDaysUntil(plannedDate) < -3 : false;
  });

  const topPadding = Platform.OS === "web" ? 67 : insets.top;
  const bottomPadding = Platform.OS === "web" ? 34 : 0;

  const sections = blocks.map((block) => ({
    id: block.id,
    label: block.name,
    variety: block.variety,
    acres: block.acres,
    planting_date: block.planting_date,
    blight_risk: block.blight_risk,
  }));

  const seasonStatusLabel = activeSeason?.status === "closed"
    ? "Closed"
    : activeSeason?.status === "planning"
    ? "Planning"
    : "Active";

  return (
    <ScrollView
      style={[styles.container]}
      contentContainerStyle={[
        styles.content,
        { paddingTop: topPadding + 16, paddingBottom: bottomPadding + 100 },
      ]}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={COLORS.primary} />}
      showsVerticalScrollIndicator={false}
    >
      {loadError ? (
        <View style={styles.errorBanner}>
          <Ionicons name="cloud-offline-outline" size={16} color={COLORS.red} />
          <Text style={styles.errorBannerText}>{loadError}</Text>
          <Pressable onPress={retryLoad} style={styles.retryBtn}>
            <Text style={styles.retryBtnText}>Retry</Text>
          </Pressable>
        </View>
      ) : null}

      <BrandRow showFarm={false} />

      <View style={styles.header}>
        <View style={{ flex: 1 }}>
          <Text style={styles.farmName} numberOfLines={1}>{activeFarm?.name || "My Farm"}</Text>
          <Text style={styles.farmSub}>
            {activeSeason ? getTemplate(activeSeason.template_id).cropType : (activeFarm?.crop_type || "Farm")} — {activeSeason?.season_name || "No active season"}
          </Text>
        </View>
        <Pressable
          style={styles.headerBadge}
          onPress={() => router.push("/season-control")}
        >
          <Ionicons
            name={activeSeason?.status === "active" ? "leaf" : "leaf-outline"}
            size={14}
            color={COLORS.primary}
          />
          <Text style={styles.headerBadgeText}>{seasonStatusLabel}</Text>
        </Pressable>
      </View>

      {activeSeason && (
        <View style={styles.summaryCard}>
          <Ionicons name="leaf" size={190} color="rgba(255,255,255,0.05)" style={styles.heroWatermark} pointerEvents="none" />
          <View style={styles.summaryHeader}>
            <View style={styles.summaryTitleWrap}>
              <View style={styles.summaryKicker}>
                <Ionicons name="leaf-outline" size={14} color={COLORS.accentOnInk} />
                <Text style={styles.summaryKickerText}>Season Summary</Text>
              </View>
              <Text style={styles.summaryTitle}>{activeSeason.season_name}</Text>
              <Text style={styles.summarySubtitle}>
                {seasonStatusLabel} · {activeSeason.season_type} · {totalAcres} acres
              </Text>
            </View>
            <Pressable style={styles.summaryAction} onPress={() => router.push("/season-control")}>
              <Ionicons name="options-outline" size={18} color={COLORS.white} />
            </Pressable>
          </View>

          <View style={styles.summaryGrid}>
            {canViewFinancials ? (
              <View style={[styles.summaryItem, styles.summaryItemWide]}>
                <Text style={[styles.summaryValue, styles.summaryHeroValue, netProfit >= 0 ? styles.summaryPositive : styles.summaryNegative]}>
                  {formatKES(netProfit)}
                </Text>
                <Text style={styles.summaryText}>Net profit</Text>
              </View>
            ) : null}
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{totalAcres}</Text>
              <Text style={styles.summaryText}>Planted acres</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>{currentSchedule.length - completedIds.length}</Text>
              <Text style={styles.summaryText}>Pending tasks</Text>
            </View>
            <View style={styles.summaryItem}>
              <Text style={styles.summaryValue}>
                {budgetPercent !== null ? `${budgetPercent.toFixed(0)}%` : "—"}
              </Text>
              <Text style={styles.summaryText}>Budget used</Text>
            </View>
          </View>

          <View style={styles.summaryFooter}>
            <View style={styles.summaryPill}>
              <Ionicons name="calendar-outline" size={13} color={COLORS.inkMuted} />
              <Text style={styles.summaryPillText}>{currentSchedule.length} planned</Text>
            </View>
            <View style={styles.summaryPill}>
              <Ionicons name="checkmark-circle-outline" size={13} color={COLORS.inkMuted} />
              <Text style={styles.summaryPillText}>{completedIds.length} done</Text>
            </View>
            <View style={styles.summaryPill}>
              <Ionicons name="wallet-outline" size={13} color={COLORS.inkMuted} />
              <Text style={styles.summaryPillText}>{formatKES(totalSpent)} spent</Text>
            </View>
          </View>
        </View>
      )}

      {activeSeason && (
        <Pressable style={styles.harvestCard} onPress={() => router.push("/season-report")}>
          <View style={styles.harvestHeader}>
            <View>
              <Text style={styles.harvestLabel}>Harvest Report</Text>
              <Text style={styles.harvestTitle}>
                {harvestRecords.some((r) => r.season_id === activeSeason.id) ? "Season complete" : "Harvest pending"}
              </Text>
            </View>
            <View style={styles.harvestBadge}>
              <Ionicons name="receipt-outline" size={14} color={COLORS.primary} />
            </View>
          </View>
          <View style={styles.harvestGrid}>
            <View style={styles.harvestItem}>
              <Text style={styles.harvestValue} numberOfLines={2}>{harvestQuantitySummary}</Text>
              <Text style={styles.harvestText}>Harvest quantity</Text>
            </View>
            <View style={styles.harvestItem}>
              <Text style={styles.harvestValue}>
                {canViewFinancials || farmRole === "seller" ? formatKES(totalRevenue) : "—"}
              </Text>
              <Text style={styles.harvestText}>
                {canViewFinancials ? "Sales revenue" : farmRole === "seller" ? "My checked sales" : "Sales restricted"}
              </Text>
            </View>
            {canViewFinancials ? (
              <View style={styles.harvestItem}>
                <Text style={[styles.harvestValue, netProfit >= 0 ? styles.summaryPositive : styles.summaryNegative]}>
                  {formatKES(netProfit)}
                </Text>
                <Text style={styles.harvestText}>Net</Text>
              </View>
            ) : null}
          </View>
          {salesLoadError ? (
            <Text style={{ color: COLORS.red, fontFamily: "Manrope_400Regular", fontSize: 12, marginTop: 8 }}>
              Sales ledger unavailable: {salesLoadError}
            </Text>
          ) : null}
        </Pressable>
      )}

      {lowStockItems.length > 0 && (
        <Pressable style={styles.lowStockCard} onPress={() => router.push("/inventory")}>
          <View style={styles.lowStockHeader}>
            <Ionicons name="warning-outline" size={16} color={COLORS.amber} />
            <Text style={styles.lowStockTitle}>Low Stock Alert</Text>
            <View style={styles.lowStockBadge}><Text style={styles.lowStockBadgeText}>{lowStockItems.length}</Text></View>
          </View>
          <View style={styles.lowStockList}>
            {lowStockItems.slice(0, 3).map((item) => {
              const remaining = item.quantity_purchased - item.quantity_used;
              return (
                <View key={item.id} style={styles.lowStockRow}>
                  <Text style={styles.lowStockItemName} numberOfLines={1}>{item.product_name}</Text>
                  <Text style={styles.lowStockItemQty}>{remaining} {item.unit} left</Text>
                </View>
              );
            })}
            {lowStockItems.length > 3 && (
              <Text style={styles.lowStockMore}>+{lowStockItems.length - 3} more items</Text>
            )}
          </View>
        </Pressable>
      )}

      {hasOverdue && !dismissedAlert && (
        <View style={styles.alertBanner}>
          <Ionicons name="warning" size={18} color={COLORS.white} />
          <Text style={styles.alertText}>Activity overdue — check schedule</Text>
          <Pressable onPress={() => setDismissedAlert(true)} hitSlop={12}>
            <Ionicons name="close" size={18} color={COLORS.white} />
          </Pressable>
        </View>
      )}

      {!activeSeason && (
        <Pressable style={styles.noSeasonCard} onPress={() => router.push("/season-setup") }>
          <Ionicons name="add-circle-outline" size={28} color={COLORS.primary} />
          <View style={styles.noSeasonText}>
            <Text style={styles.noSeasonTitle}>Start your season</Text>
            <Text style={styles.noSeasonSub}>Set your planting date to generate a full schedule</Text>
          </View>
          <Ionicons name="chevron-forward" size={18} color={COLORS.textMuted} />
        </Pressable>
      )}

      {sections.map((section, index) => {
        const sectionColor = index === 0
          ? COLORS.primary
          : index % 2 === 1
          ? COLORS.teal
          : COLORS.amber;
        const daysSincePlanting = getDaysSincePlanting(section.planting_date);
        const growthStage = getGrowthStage(section.planting_date);
        const nextActivity = getNextActivity(section.id);
        const nextDate = nextActivity?.plannedDate || null;
        const daysUntilNext = nextDate ? getDaysUntil(nextDate) : 999;
        const urgencyColor = getUrgencyColor(daysUntilNext);
        const urgencyBg = getUrgencyBg(daysUntilNext);

        const lastSpray = getLastSprayDate(section.id);
        const daysSinceSpray = lastSpray
          ? Math.floor((new Date().getTime() - new Date(lastSpray).getTime()) / (1000 * 60 * 60 * 24))
          : null;
        // The fixed spray interval is only established for the potato schedule.
        // Other crops show their crop-specific schedule and require local advice.
        const sprayWarning = getTemplate(activeSeason?.template_id).id === "potato-template-stephen-shangi"
          && section.blight_risk === "HIGH" && daysSinceSpray !== null && daysSinceSpray >= 10;
        const sprayAlert = getTemplate(activeSeason?.template_id).id === "potato-template-stephen-shangi"
          && section.blight_risk === "HIGH" && daysSinceSpray !== null && daysSinceSpray >= 12;

        return (
          <View key={section.id} style={styles.sectionCard}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionLabelRow}>
                <View style={[styles.sectionBadge, { backgroundColor: sectionColor }]}>
                  <Text style={styles.sectionBadgeText}>{section.label}</Text>
                </View>
                <Text style={styles.sectionVariety}>{section.variety}</Text>
              </View>
              <View style={[styles.blightBadge, { backgroundColor: section.blight_risk === "HIGH" ? COLORS.redLight : COLORS.amberLight }]}>
                <Text style={[styles.blightText, { color: section.blight_risk === "HIGH" ? COLORS.red : COLORS.amber }]}>
                  {section.blight_risk} RISK
                </Text>
              </View>
            </View>

            <View style={styles.sectionStats}>
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{Math.max(0, daysSincePlanting)}</Text>
                <Text style={styles.statLabel}>Days Old</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue}>{section.acres}</Text>
                <Text style={styles.statLabel}>Acres</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Text style={styles.statValue} numberOfLines={1} adjustsFontSizeToFit>{growthStage.split("—")[0].trim()}</Text>
                <Text style={styles.statLabel}>Stage</Text>
              </View>
            </View>

            {nextActivity && (
              <View style={[styles.nextActivity, { backgroundColor: urgencyBg }]}>
                <View style={styles.nextActivityLeft}>
                  <Ionicons name={getActivityTypeIcon(nextActivity.activityType) as any} size={18} color={urgencyColor} />
                  <View style={styles.nextActivityText}>
                    <Text style={[styles.nextActivityName, { color: urgencyColor }]} numberOfLines={1}>
                      {nextActivity.name}
                    </Text>
                    <Text style={styles.nextActivityDate}>
                      {nextDate ? formatDate(nextDate) : "—"}
                    </Text>
                  </View>
                </View>
                <View style={styles.daysUntilBadge}>
                  <Text style={[styles.daysUntilText, { color: urgencyColor }]}>
                    {daysUntilNext === 0 ? "Today" : daysUntilNext < 0 ? `${Math.abs(daysUntilNext)}d late` : `${daysUntilNext}d`}
                  </Text>
                </View>
              </View>
            )}

            <View style={[styles.sprayBar, sprayAlert ? styles.sprayBarAlert : sprayWarning ? styles.sprayBarWarn : styles.sprayBarOk]}>
              <Ionicons
                name={sprayAlert ? "warning" : "water-outline"}
                size={14}
                color={sprayAlert ? COLORS.red : sprayWarning ? COLORS.amber : COLORS.primary}
              />
              {daysSinceSpray !== null ? (
                <Text style={[styles.sprayBarText, { color: sprayAlert ? COLORS.red : sprayWarning ? COLORS.amber : COLORS.primary }]}>
                  {sprayAlert
                    ? `OVERDUE — Last spray ${daysSinceSpray}d ago (max 12d!)`
                    : sprayWarning
                    ? `Last spray ${daysSinceSpray}d ago — spray soon`
                    : `Last spray ${daysSinceSpray}d ago`}
                </Text>
              ) : (
                <Text style={[styles.sprayBarText, { color: COLORS.textMuted }]}>No spray recorded yet</Text>
              )}
            </View>
          </View>
        );
      })}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.background },
  content: { paddingHorizontal: 20, gap: 14 },
  errorBanner: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: COLORS.redLight, borderRadius: 12, padding: 12 },
  errorBannerText: {
    flex: 1,
    fontFamily: "Manrope_400Regular",
    fontSize: 14,
    color: COLORS.red,
    lineHeight: 18,
  },
  retryBtn: { backgroundColor: COLORS.red, borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 },
  retryBtnText: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 13,
    color: COLORS.white,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    gap: 12,
  },
  farmName: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 32,
    letterSpacing: -0.5,
    color: COLORS.text,
  },
  farmSub: {
    marginTop: 4,
    fontFamily: "Manrope_400Regular",
    fontSize: 15,
    color: COLORS.textSecondary,
  },
  headerBadge: { flexDirection: "row", alignItems: "center", gap: 5, backgroundColor: COLORS.primarySurface, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 8 },
  headerBadgeText: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 13,
    color: COLORS.primary,
  },
  summaryCard: {
    backgroundColor: COLORS.ink,
    borderRadius: 24,
    padding: 20,
    gap: 16,
    overflow: "hidden",
    ...CARD_SHADOW,
  },
  summaryHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 12 },
  summaryTitleWrap: { flex: 1, gap: 4 },
  summaryKicker: { flexDirection: "row", alignItems: "center", gap: 6 },
  summaryKickerText: {
    fontFamily: "Manrope_700Bold",
    fontSize: 12,
    color: COLORS.accentOnInk,
    textTransform: "uppercase",
    letterSpacing: 0.8,
  },
  summarySubtitle: {
    fontFamily: "Manrope_400Regular",
    fontSize: 14,
    color: COLORS.inkMuted,
    lineHeight: 19,
  },
  summaryTitle: {
    fontFamily: "Manrope_700Bold",
    fontSize: 20,
    color: COLORS.inkText,
  },
  summaryAction: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: COLORS.inkLine,
  },
  summaryGrid: { flexDirection: "row", flexWrap: "wrap", gap: 10 },
  summaryItem: {
    flexGrow: 1,
    flexBasis: "30%",
    backgroundColor: COLORS.inkSoft,
    borderRadius: 16,
    padding: 14,
    gap: 4,
  },
  summaryValue: {
    fontFamily: "Manrope_700Bold",
    fontSize: 22,
    color: COLORS.inkText,
    letterSpacing: -0.5,
    fontVariant: ["tabular-nums"],
  },
  summaryPositive: {
    color: COLORS.accentOnInk,
  },
  summaryNegative: {
    color: COLORS.dangerOnInk,
  },
  summaryText: {
    fontFamily: "Manrope_500Medium",
    fontSize: 13,
    color: COLORS.inkMuted,
  },
  summaryFooter: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  summaryPill: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: COLORS.inkSoft,
    borderRadius: 999,
    paddingHorizontal: 12,
    paddingVertical: 7,
  },
  summaryPillText: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 13,
    color: COLORS.inkText,
  },
  harvestCard: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    padding: 16,
    gap: 12,
    ...CARD_SHADOW,
  },
  harvestHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start", gap: 12 },
  harvestLabel: {
    fontFamily: "Manrope_700Bold",
    fontSize: 12,
    color: COLORS.textSecondary,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  harvestTitle: { fontFamily: "Manrope_700Bold", fontSize: 18, color: COLORS.text, marginTop: 2 },
  harvestBadge: { width: 30, height: 30, borderRadius: 15, alignItems: "center", justifyContent: "center", backgroundColor: COLORS.primarySurface },
  harvestGrid: { flexDirection: "row", gap: 8 },
  harvestItem: { flex: 1, backgroundColor: COLORS.background, borderRadius: 14, padding: 10, gap: 3 },
  harvestValue: {
    fontFamily: "Manrope_700Bold",
    fontSize: 15,
    color: COLORS.text,
  },
  harvestText: {
    fontFamily: "Manrope_400Regular",
    fontSize: 12,
    color: COLORS.textSecondary,
  },
  alertBanner: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: COLORS.red, borderRadius: 14, paddingHorizontal: 14, paddingVertical: 12 },
  alertText: {
    flex: 1,
    color: COLORS.white,
    fontFamily: "Manrope_600SemiBold",
    fontSize: 13,
  },
  noSeasonCard: {
    flexDirection: "row",
    alignItems: "center",
    gap: 12,
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    padding: 16,
    ...CARD_SHADOW,
  },
  noSeasonText: { flex: 1 },
  noSeasonTitle: {
    fontFamily: "Manrope_700Bold",
    fontSize: 17,
    color: COLORS.text,
  },
  noSeasonSub: {
    fontFamily: "Manrope_400Regular",
    fontSize: 13,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  sectionCard: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    padding: 14,
    gap: 12,
    ...CARD_SHADOW,
  },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  sectionLabelRow: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  sectionBadge: { borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  sectionBadgeText: {
    fontFamily: "Manrope_700Bold",
    fontSize: 13,
    color: COLORS.white,
  },
  sectionVariety: {
    flex: 1,
    fontFamily: "Manrope_700Bold",
    fontSize: 16,
    color: COLORS.text,
  },
  blightBadge: { borderRadius: 999, paddingHorizontal: 8, paddingVertical: 5 },
  blightText: {
    fontFamily: "Manrope_700Bold",
    fontSize: 12,
  },
  sectionStats: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", backgroundColor: COLORS.background, borderRadius: 14, padding: 12 },
  statItem: { flex: 1, alignItems: "center" },
  statValue: {
    fontFamily: "Manrope_700Bold",
    fontSize: 18,
    color: COLORS.text,
    letterSpacing: -0.5,
    fontVariant: ["tabular-nums"],
  },
  statLabel: {
    fontFamily: "Manrope_400Regular",
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  statDivider: { width: 1, height: 28, backgroundColor: COLORS.borderLight },
  nextActivity: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderRadius: 14, padding: 12 },
  nextActivityLeft: { flexDirection: "row", alignItems: "center", gap: 10, flex: 1 },
  nextActivityText: { flex: 1 },
  nextActivityName: {
    fontFamily: "Manrope_700Bold",
    fontSize: 15,
  },
  nextActivityDate: {
    fontFamily: "Manrope_400Regular",
    fontSize: 12,
    color: COLORS.textSecondary,
    marginTop: 2,
  },
  daysUntilBadge: { backgroundColor: COLORS.white, borderRadius: 999, paddingHorizontal: 10, paddingVertical: 5 },
  daysUntilText: {
    fontFamily: "Manrope_700Bold",
    fontSize: 12,
  },
  lowStockCard: {
    backgroundColor: COLORS.cardBg,
    borderRadius: 20,
    padding: 14,
    gap: 10,
    ...CARD_SHADOW,
  },
  lowStockHeader: { flexDirection: "row", alignItems: "center", gap: 8 },
  lowStockTitle: {
    flex: 1,
    fontFamily: "Manrope_700Bold",
    fontSize: 15,
    color: COLORS.text,
  },
  lowStockBadge: { backgroundColor: COLORS.amberLight, borderRadius: 999, width: 22, height: 22, alignItems: "center", justifyContent: "center" },
  lowStockBadgeText: {
    fontFamily: "Manrope_700Bold",
    fontSize: 12,
    color: COLORS.amber,
  },
  lowStockList: { gap: 6 },
  lowStockRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  lowStockItemName: {
    flex: 1,
    fontFamily: "Manrope_400Regular",
    fontSize: 14,
    color: COLORS.text,
  },
  lowStockItemQty: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 14,
    color: COLORS.amber,
  },
  lowStockMore: {
    fontFamily: "Manrope_400Regular",
    fontSize: 13,
    color: COLORS.textMuted,
  },
  sprayBar: { flexDirection: "row", alignItems: "center", gap: 8, borderRadius: 12, paddingHorizontal: 12, paddingVertical: 10 },
  sprayBarOk: { backgroundColor: COLORS.primarySurface },
  sprayBarWarn: { backgroundColor: COLORS.amberLight },
  sprayBarAlert: { backgroundColor: COLORS.redLight },
  sprayBarText: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 13,
    flex: 1,
  },
  heroWatermark: {
    position: "absolute",
    right: -34,
    bottom: -40,
  },
  summaryItemWide: {
    flexBasis: "100%",
    paddingVertical: 16,
  },
  summaryHeroValue: {
    fontFamily: "Manrope_600SemiBold",
    fontSize: 34,
  },
});