import assert from "node:assert/strict";
import test from "node:test";
import {
  compareWithPrevious, normalizeDate, normalizeParsedReport, normalizeRating, normalizeResult,
  resolveParameterKey, sortNewestFirst, testsForTarget, type SoilTestRecord,
} from "../lib/soil";

const TODAY = new Date("2026-10-22T08:00:00Z");

test("report with several samples becomes one cleaned sample per column", () => {
  const out = normalizeParsedReport({
    is_soil_report: true, lab_name: "  Crop Nutrition Labs ", report_date: "2026-10-01",
    samples: [
      { label: "Field 1", sample_date: "2026-09-20", depth: "0-20 cm", sampling_method: "Composite",
        results: [
          { key: "ph_water", label_on_report: "pH", value: 5.6, unit: "", confidence: "high", rating: "Acidic?" },
          { key: "phosphorus", label_on_report: "P (Olsen)", value: "12,5", unit: "ppm", rating: "Low", method: "Olsen" },
        ] },
      { label: "Field 2", results: [{ key: "ph_water", label_on_report: "pH", value: 6.2, confidence: "high" }] },
    ],
  }, TODAY)!;
  assert.equal(out.isSoilReport, true);
  assert.equal(out.lab_name, "Crop Nutrition Labs");
  assert.equal(out.samples.length, 2);
  assert.equal(out.samples[0].sampling_method, "composite");
  const p = out.samples[0].results[1];
  assert.equal(p.value, 12.5);           // comma decimal read correctly
  assert.equal(p.unit, "ppm");           // unit kept exactly as printed, not converted
  assert.equal(p.rating, "low");
  assert.equal(out.samples[0].status, "parsed");
});

test("an unreadable or impossible value is flagged for review, not trusted", () => {
  const out = normalizeParsedReport({
    is_soil_report: true,
    samples: [{ results: [{ key: "ph_water", label_on_report: "pH", value: 56, confidence: "high" }] }],
  }, TODAY)!;
  assert.deepEqual(out.samples[0].results[0].flags, ["out_of_range"]);
  assert.equal(out.samples[0].status, "needs_review");
});

test("percentages over 100 or implausible organic carbon are flagged", () => {
  const oc = normalizeResult({ key: "organic_carbon", label_on_report: "OC", value: 45, unit: "%" })!;
  assert.ok(oc.flags.includes("out_of_range"));
  const clay = normalizeResult({ key: "clay", label_on_report: "Clay", value: 130, unit: "%" })!;
  assert.ok(clay.flags.includes("out_of_range"));
  const ok = normalizeResult({ key: "organic_carbon", label_on_report: "OC", value: 2.1, unit: "%" })!;
  assert.deepEqual(ok.flags, []);
});

test("negative numbers are rejected and the row dropped when nothing else is readable", () => {
  assert.equal(normalizeResult({ key: "zinc", label_on_report: "Zn", value: -3, unit: "ppm" }), null);
});

test("non-numeric readings such as <0.5 are kept as text, never turned into zero", () => {
  const r = normalizeResult({ key: "boron", label_on_report: "B", value: "<0.1", unit: "ppm" })!;
  assert.equal(r.value, null);
  assert.equal(r.text, "<0.1");
});

test("unknown parameters keep what the lab printed instead of being discarded", () => {
  const r = normalizeResult({ key: "other", label_on_report: "Lime requirement", value: 2.5, unit: "t/ha" })!;
  assert.equal(r.key, "other:lime_requirement");
  assert.equal(r.reported_label, "Lime requirement");
});

test("labels printed on the report map to the right parameter", () => {
  assert.equal(resolveParameterKey("Exch. K"), "potassium");
  assert.equal(resolveParameterKey("pH (H2O)"), "ph_water");
  assert.equal(resolveParameterKey("Cation Exchange Capacity"), "cec");
  assert.equal(resolveParameterKey("mystery"), null);
  const r = normalizeResult({ key: "wrong-key", label_on_report: "Olsen P", value: 8, unit: "mg/kg" })!;
  assert.equal(r.key, "phosphorus");
});

test("ratings are normalised but the lab's own wording is kept", () => {
  assert.deepEqual(normalizeRating("Optimum"), { rating: "adequate", text: "Optimum" });
  assert.deepEqual(normalizeRating("Very Low"), { rating: "very_low", text: "Very Low" });
  assert.deepEqual(normalizeRating("Sandy-ish"), { rating: null, text: "Sandy-ish" });
});

test("dates must be real, valid ISO dates and not in the future", () => {
  assert.equal(normalizeDate("2026-09-20", TODAY), "2026-09-20");
  assert.equal(normalizeDate("2026-02-30", TODAY), null);
  assert.equal(normalizeDate("20/09/2026", TODAY), "2026-09-20"); // day-first, as Kenyan labs print
  assert.equal(normalizeDate("Sept 2026", TODAY), null);
  assert.equal(normalizeDate("2027-01-01", TODAY), null);
});

test("a non-soil document or garbage output is not accepted as a soil report", () => {
  assert.equal(normalizeParsedReport("nope"), null);
  assert.equal(normalizeParsedReport({ is_soil_report: false, samples: [] }, TODAY)!.isSoilReport, false);
  assert.equal(normalizeParsedReport({ is_soil_report: true, samples: [] }, TODAY)!.isSoilReport, false);
});

const rec = (over: Partial<SoilTestRecord>): SoilTestRecord => ({
  id: "t", farm_id: "f1", plot_id: null, sample_label: null, sample_date: "2026-01-01", received_date: null, report_date: null,
  lab_name: null, lab_reference: null, location_on_report: null, intended_crops: [], sample_depth: null, sampling_method: "unknown",
  results: [], recommendations: null, recommendation_items: [], report_files: [], source: "pdf", status: "parsed", extraction_notes: null, created_by: null, confirmed_by: null,
  confirmed_at: null, created_at: "2026-01-02T00:00:00Z", updated_at: "2026-01-02T00:00:00Z", ...over,
});
const ph = (value: number, unit: string | null = null) =>
  normalizeResult({ key: "ph_water", label_on_report: "pH", value, unit, confidence: "high" })!;

test("comparison uses the previous test on the SAME plot, never another plot or the whole farm", () => {
  const history = [
    rec({ id: "farm-old", sample_date: "2025-03-01", results: [ph(4.0)] }),
    rec({ id: "plotA-old", plot_id: "A", sample_date: "2025-06-01", results: [ph(5.0)] }),
    rec({ id: "plotB-old", plot_id: "B", sample_date: "2025-09-01", results: [ph(7.0)] }),
  ];
  const current = rec({ id: "plotA-new", plot_id: "A", sample_date: "2026-06-01", results: [ph(5.8)] });
  const c = compareWithPrevious(history, current, current.results[0]);
  assert.equal(c.previous?.testId, "plotA-old");
  assert.ok(Math.abs((c.change ?? 0) - 0.8) < 1e-9);
});

test("a change is not calculated when the unit differs between tests", () => {
  const p = (v: number, unit: string) => normalizeResult({ key: "phosphorus", label_on_report: "P", value: v, unit })!;
  const history = [rec({ id: "old", sample_date: "2025-01-01", results: [p(10, "ppm")] })];
  const current = rec({ id: "new", sample_date: "2026-01-01", results: [p(20, "kg/ha")] });
  const c = compareWithPrevious(history, current, current.results[0]);
  assert.equal(c.change, null);
  assert.equal(c.unitDiffers, true);
});

test("tests stay usable across seasons: lookup is by farm/plot and date, not by season", () => {
  const tests = [rec({ id: "a", plot_id: "A" }), rec({ id: "b", plot_id: null }), rec({ id: "c", plot_id: "A", sample_date: "2026-05-01" })];
  assert.deepEqual(testsForTarget(tests, "A").map((t) => t.id).sort(), ["a", "c"]);
  assert.deepEqual(testsForTarget(tests, null).map((t) => t.id), ["b"]);
  assert.equal(sortNewestFirst(tests)[0].id, "c");
});

// ───────── the real KALRO NARL report supplied as the reference format ─────────
import { canonicalUnit, formatResultValue, testDate } from "../lib/soil";
import { KALRO_ADVICE, KALRO_READER_OUTPUT } from "./fixtures/kalro-narl-sample";

test("KALRO report: header, dates, crops and lab details are captured as printed", () => {
  const out = normalizeParsedReport(KALRO_READER_OUTPUT, TODAY)!;
  assert.equal(out.isSoilReport, true);
  assert.equal(out.lab_reference, "18040");
  assert.equal(out.location_on_report, "KAPLETUNDO, SOTIK, BOMET");
  assert.deepEqual(out.intended_crops, ["Passion", "Onion", "Potato"]);
  assert.equal(out.received_date, "2025-12-04");
  assert.equal(out.report_date, "2025-12-23");
  const s = out.samples[0];
  assert.equal(s.label, "SAMPLE 1");
  assert.equal(s.sample_date, null); // the report only gives the received date: it must not be passed off as the sampling date
  assert.equal(s.depth, "Top");
});

test("KALRO report: all 13 filled rows are kept, blank rows are not invented", () => {
  const s = normalizeParsedReport(KALRO_READER_OUTPUT, TODAY)!.samples[0];
  assert.equal(s.results.length, 13);
  assert.ok(!s.results.some((r) => r.key === "ec"));
  const by = (k: string) => s.results.find((r) => r.key === k)!;
  assert.equal(by("ph_water").value, 5.16);
  assert.equal(by("ph_water").rating, null);               // "Mod. acid" is an acidity class, not a low/high rating
  assert.equal(by("ph_water").rating_text, "Mod. acid");   // ...but the lab's wording is kept
  assert.equal(formatResultValue(by("potassium")), "1.18 meq%");
  assert.equal(by("phosphorus").method, "Mehlich");
  assert.equal(formatResultValue(by("phosphorus")), "39.6 ppm");
  assert.equal(by("copper").rating, "low");                // Deficient
  assert.equal(by("copper").rating_text, "Deficient");
  assert.equal(by("organic_carbon").value, 4.06);
});

test("KALRO report: manganese printed in meq% is flagged as an unusual unit but does not block saving", () => {
  const s = normalizeParsedReport(KALRO_READER_OUTPUT, TODAY)!.samples[0];
  const mn = s.results.find((r) => r.key === "manganese")!;
  assert.deepEqual(mn.flags, ["unusual_unit"]);
  assert.equal(mn.unit, "meq%");                           // not converted
  assert.equal(s.status, "parsed");
});

test("KALRO report: the written advice is kept word for word and split into per-crop actions", () => {
  const s = normalizeParsedReport(KALRO_READER_OUTPUT, TODAY)!.samples[0];
  assert.equal(s.recommendations, KALRO_ADVICE.replace(/\s+/g, " ").trim());
  assert.equal(s.recommendation_items.length, 12);
  const lime = s.recommendation_items[0];
  assert.equal(lime.rate, "100kg/acre");
  assert.equal(lime.timing, "at least 2 months before planting");
  assert.ok(s.recommendation_items.every((i) => i.action.length > 0));
});

test("dates printed day-first by the lab are read correctly if the reader passes them through unchanged", () => {
  assert.equal(normalizeDate("04-12-2025", TODAY), "2025-12-04");
  assert.equal(normalizeDate("23-12-25", TODAY), "2025-12-23");
  assert.equal(normalizeDate("31-02-2025", TODAY), null);
});

test("a test with only a received date is ordered by that date, not by when it was uploaded", () => {
  const t = rec({ sample_date: null, received_date: "2025-12-04", report_date: "2025-12-23", created_at: "2026-10-22T00:00:00Z" });
  assert.equal(testDate(t), "2025-12-04");
});

test("units that mean the same number are compared across labs; different quantities are not", () => {
  assert.equal(canonicalUnit("meq%"), canonicalUnit("cmol(+)/kg"));
  assert.equal(canonicalUnit("ppm"), canonicalUnit("mg/kg"));
  assert.notEqual(canonicalUnit("kg/ha"), canonicalUnit("ppm"));
  const k = (v: number, unit: string) => normalizeResult({ key: "potassium", label_on_report: "K", value: v, unit })!;
  const history = [rec({ id: "old", sample_date: "2025-01-01", results: [k(1.0, "cmol(+)/kg")] })];
  const current = rec({ id: "new", sample_date: "2026-01-01", results: [k(1.18, "meq%")] });
  const c = compareWithPrevious(history, current, current.results[0]);
  assert.equal(c.unitDiffers, false);
  assert.ok(Math.abs((c.change ?? 0) - 0.18) < 1e-9);
});
