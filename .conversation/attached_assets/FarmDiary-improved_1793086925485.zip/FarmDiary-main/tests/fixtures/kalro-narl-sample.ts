// What the reader is expected to return for the real KALRO NARL "Soil Test Report" PDF supplied as the
// reference format (one sample, value + class columns, meq%/ppm units, day-first dates, written advice).
// Hand-written from the report so the cleaning/validation and saving logic can be tested without calling the reader.
const r = (key: string, label_on_report: string, value: number, unit: string, rating: string, extra: Record<string, unknown> = {}) =>
  ({ key, label_on_report, value, unit, rating, confidence: "high", ...extra });

export const KALRO_ADVICE =
  "The soil reaction is moderately acid. Copper is deficient. Passion, Onion Potato: Liming is recommended at 100kg/acre using Agricultural Lime, Broadcast lime after ploughing, mixing it with top soil (25cm), at least 2 months before planting. Place 3 handfuls (Potato,Onion) and 5kg (Passion) of well decomposed Farm Yard manure per hole. During planting, apply 150kg/acre (Potato), 50g (Passion) and 5g (Onion) of N:P:K (23:23:0) fertilizer . Top dress Potato with 100kg/acre using CAN fertilizer. At 30 and 45 days after planting, apply 5g/plant and 10g/plant of CAN fertilizer (Onion). After every 3 months, apply 5kg/tree of manure and 50g/tree of CAN fertilizer until onset of flowering (Passion)";

export const KALRO_READER_OUTPUT = {
  is_soil_report: true,
  lab_name: "Kenya Agricultural & Livestock Research Organization (KALRO) – National Agricultural Research Laboratories",
  lab_reference: "18040",
  location_on_report: "KAPLETUNDO, SOTIK, BOMET",
  intended_crops: ["PASSION", "ONION", "POTATO"],
  received_date: "2025-12-04",
  report_date: "2025-12-23",
  notes: null,
  samples: [
    {
      label: "SAMPLE 1",
      sample_date: null,
      depth: "Top",
      sampling_method: "unknown",
      recommendations: KALRO_ADVICE,
      recommendation_items: [
        { crop: "Passion, Onion, Potato", action: "Apply Agricultural Lime: broadcast after ploughing and mix with top soil (25cm)", rate: "100kg/acre", timing: "at least 2 months before planting" },
        { crop: "Potato", action: "Place well decomposed farm yard manure per hole", rate: "3 handfuls", timing: "at planting" },
        { crop: "Onion", action: "Place well decomposed farm yard manure per hole", rate: "3 handfuls", timing: "at planting" },
        { crop: "Passion", action: "Place well decomposed farm yard manure per hole", rate: "5kg", timing: "at planting" },
        { crop: "Potato", action: "Apply N:P:K (23:23:0) fertilizer", rate: "150kg/acre", timing: "during planting" },
        { crop: "Passion", action: "Apply N:P:K (23:23:0) fertilizer", rate: "50g", timing: "during planting" },
        { crop: "Onion", action: "Apply N:P:K (23:23:0) fertilizer", rate: "5g", timing: "during planting" },
        { crop: "Potato", action: "Top dress with CAN fertilizer", rate: "100kg/acre", timing: null },
        { crop: "Onion", action: "Apply CAN fertilizer", rate: "5g/plant", timing: "30 days after planting" },
        { crop: "Onion", action: "Apply CAN fertilizer", rate: "10g/plant", timing: "45 days after planting" },
        { crop: "Passion", action: "Apply manure", rate: "5kg/tree", timing: "every 3 months until onset of flowering" },
        { crop: "Passion", action: "Apply CAN fertilizer", rate: "50g/tree", timing: "every 3 months until onset of flowering" },
      ],
      results: [
        r("ph_water", "Soil pH", 5.16, "", "Mod. acid"),
        r("exchangeable_acidity", "Exch. Acidity meq%", 0.4, "meq%", "Adequate"),
        r("total_nitrogen", "Total Nitrogen %", 0.41, "%", "Adequate"),
        r("organic_carbon", "Total Org. Carbon %", 4.06, "%", "Adequate"),
        r("phosphorus", "Phosphorus (Mehlich) ppm", 39.6, "ppm", "Adequate", { method: "Mehlich" }),
        r("potassium", "Potassium meq%", 1.18, "meq%", "Adequate"),
        r("calcium", "Calcium meq%", 5.4, "meq%", "Adequate"),
        r("magnesium", "Magnesium meq%", 3.71, "meq%", "Adequate"),
        r("manganese", "Manganese meq%", 0.65, "meq%", "Adequate"),
        r("copper", "Copper ppm", 0.26, "ppm", "Deficient"),
        r("iron", "Iron ppm", 87.5, "ppm", "Adequate"),
        r("zinc", "Zinc ppm", 21.12, "ppm", "Adequate"),
        r("sodium", "Sodium meq%", 0.14, "meq%", "Adequate"),
        // "Phosphorus (Olsen) ppm" and "Electr. Conductivity mS/cm" are blank on the report, so they are not returned.
      ],
    },
  ],
};
