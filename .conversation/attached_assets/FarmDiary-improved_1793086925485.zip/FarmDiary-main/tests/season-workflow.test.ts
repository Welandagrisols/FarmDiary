import assert from "node:assert/strict";
import test from "node:test";
import { groupBySeason, seasonCostTotal, seasonFinance } from "../lib/season-finance";
import { assertSeasonOpen, CLOSED_SEASON_MESSAGE, isSeasonClosed } from "../lib/season-rules";

// One realistic crop cycle on one farm, followed through every screen's numbers.
const S1 = "season-1", S2 = "season-2";
const costs = [
  { season_id: S1, amount_kes: 2000 },   // labour
  { season_id: S1, amount_kes: "3000" }, // inputs (a numeric string must not concatenate)
  { season_id: S2, amount_kes: 999 },    // another cycle, must not leak in
];
const harvest = [
  { season_id: S1, recorded_by: null, total_revenue_kes: 5000 },     // old record that carries its own revenue
  { season_id: S1, recorded_by: "user-1", total_revenue_kes: 0 },    // new record: money is in the sales ledger
  { season_id: S1, recorded_by: "user-1", total_revenue_kes: 800 },  // must NOT be added on top of its sales
  { season_id: S2, recorded_by: null, total_revenue_kes: 7777 },
];
const sales = [
  { season_id: S1, status: "recorded", total_kes: 10000 },
  { season_id: S1, status: "recorded", total_kes: 4000 },
  { season_id: S1, status: "void_requested", total_kes: 1000 },      // still counts until the void is approved
  { season_id: S1, status: "pending_check", total_kes: 2500 },       // not yet checked: shown, not counted
  { season_id: S1, status: "discount_pending", total_kes: 300 },
  { season_id: S1, status: "voided", total_kes: 700 },               // never counts
  { season_id: S2, status: "recorded", total_kes: 9999 },
];

test("every screen gets the same revenue, costs and net for the same cycle", () => {
  const f = seasonFinance({ seasonId: S1, costs, harvest, sales, includeHarvestRevenue: true });
  assert.equal(f.costs, 5000);
  assert.equal(f.legacyHarvestRevenue, 5000);
  assert.equal(f.salesRevenue, 15000);
  assert.equal(f.pendingSalesValue, 2800);
  assert.equal(f.revenue, 20000);
  assert.equal(f.net, 15000);
  assert.equal(f.marginPct, 75);
});

test("new harvest entries (saved with revenue 0 or a recorder) never double-count against sales", () => {
  const f = seasonFinance({ seasonId: S1, costs: [], harvest: [{ season_id: S1, recorded_by: "u", total_revenue_kes: 800 }], sales: [], includeHarvestRevenue: true });
  assert.equal(f.revenue, 0);
});

test("a role that cannot see financials gets no old-harvest revenue, only the sales it can see", () => {
  const f = seasonFinance({ seasonId: S1, costs, harvest, sales, includeHarvestRevenue: false });
  assert.equal(f.legacyHarvestRevenue, 0);
  assert.equal(f.revenue, 15000);
});

test("another cycle's costs, harvests and sales never leak into this one", () => {
  const f2 = seasonFinance({ seasonId: S2, costs, harvest, sales, includeHarvestRevenue: true });
  assert.equal(f2.costs, 999);
  assert.equal(f2.revenue, 7777 + 9999);
  assert.equal(seasonCostTotal(costs, "no-such-season"), 0);
});

test("a cycle with no sales and no revenue has no margin instead of a divide-by-zero", () => {
  const f = seasonFinance({ seasonId: S1, costs, harvest: [], sales: [], includeHarvestRevenue: true });
  assert.equal(f.revenue, 0);
  assert.equal(f.net, -5000);
  assert.equal(f.marginPct, null);
});

test("sales loaded for a whole farm can be split per cycle for Season History", () => {
  const bySeason = groupBySeason(sales);
  assert.equal(bySeason.get(S1)?.length, 6);
  const h1 = seasonFinance({ seasonId: S1, costs, harvest, sales: bySeason.get(S1) ?? [], includeHarvestRevenue: true });
  const h2 = seasonFinance({ seasonId: S2, costs, harvest, sales: bySeason.get(S2) ?? [], includeHarvestRevenue: true });
  assert.equal(h1.net, 15000);
  assert.equal(h2.net, 7777 + 9999 - 999);
});

test("a closed cycle refuses new or changed records, an open one does not", () => {
  const seasons = [{ id: S1, status: "closed" }, { id: S2, status: "active" }];
  assert.equal(isSeasonClosed(seasons, S1), true);
  assert.equal(isSeasonClosed(seasons, S2), false);
  assert.equal(isSeasonClosed(seasons, "unknown"), false);
  assert.throws(() => assertSeasonOpen(seasons, S1), { message: CLOSED_SEASON_MESSAGE });
  assert.doesNotThrow(() => assertSeasonOpen(seasons, S2));
  assert.doesNotThrow(() => assertSeasonOpen(seasons, null));
});

import { resolveInputSubcategory, UNKNOWN_INPUT_SUBCATEGORY } from "../lib/cost-subcategory";

test("an input's cost subcategory comes from the product, not a fixed 'Fungicide'", () => {
  const stock = [{ product_name: "CAN Fertilizer", category: "Fertilizer" }, { product_name: "Mystery", category: "" }];
  const catalog = [{ product: "Kenthane 800WP", category: "Fungicide" }];
  assert.equal(resolveInputSubcategory("can fertilizer ", stock, catalog), "Fertilizer");
  assert.equal(resolveInputSubcategory("Kenthane 800WP", stock, catalog), "Fungicide");
  assert.equal(resolveInputSubcategory("Mystery", stock, catalog), UNKNOWN_INPUT_SUBCATEGORY);
  assert.equal(resolveInputSubcategory("Never heard of it", stock, catalog), UNKNOWN_INPUT_SUBCATEGORY);
});
