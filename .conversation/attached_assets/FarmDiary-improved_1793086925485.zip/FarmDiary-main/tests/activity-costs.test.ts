import assert from "node:assert/strict";
import test from "node:test";
import {
  describePlan, inventoryDeltas, planActivityCostSync, relatedCostsForLog,
  type ActivityCostPlan, type CostContext, type PlanInput,
} from "../lib/activity-costs";
import type { CostEntry, ProductUsed } from "../lib/storage";

const prod = (name: string, qty: number, unitPrice: number): ProductUsed => ({
  name, qty, unit: "kg", unit_price: unitPrice, total: qty * unitPrice, is_deviation: false, actual_product: null, deviation_reason: null,
});
const cost = (over: Partial<CostEntry> & { id: string }): CostEntry => ({
  farm_id: "f1", season_id: "s1", section_id: "b1", cost_category: "Inputs", cost_subcategory: "Fertilizer", description: "x",
  cost_date: "2026-03-01", is_pre_planting: false, is_historical: false, amount_kes: 0, quantity: null, unit: null, unit_price_kes: null,
  product_name: null, supplier: null, receipt_reference: null, num_workers: null, days_worked: null, rate_per_worker_per_day: null,
  facilitator_name: null, trip_from: null, trip_to: null, is_deviation: false, planned_product: null, deviation_reason: null,
  notes: null, weather_conditions: null, created_at: "2026-03-01T08:00:00Z", activity_log_id: "log1", ...over,
} as CostEntry);

const ctx: CostContext = {
  activityLogId: "log1", farmId: "f1", seasonId: "s1", sectionId: "b1", activityName: "Top dressing", date: "2026-03-01",
  isPrePlanting: false, isHistorical: false, notes: null, weather: "Sunny",
};
const urea = prod("Urea", 2, 600), can = prod("CAN", 1, 800);
const linked = [
  cost({ id: "L", cost_category: "Labor", cost_subcategory: "Casual Labor — Other", description: "Labor — Top dressing", amount_kes: 2000, quantity: 3, num_workers: 3, days_worked: 2, rate_per_worker_per_day: 333.33 }),
  cost({ id: "U", description: "Urea", amount_kes: 1200, quantity: 2, created_at: "2026-03-01T08:00:01Z" }),
  cost({ id: "C", description: "CAN", amount_kes: 800, quantity: 1, created_at: "2026-03-01T08:00:02Z" }),
  cost({ id: "T", cost_category: "Facilitation", cost_subcategory: "Fuel", description: "Fuel", amount_kes: 500 }),
];
const base = (over: Partial<PlanInput> = {}): PlanInput => ({
  context: ctx,
  before: { labourCost: 2000, products: [urea, can] },
  after: { labourCost: 2000, numWorkers: 3, daysWorked: 2, labourSubcategory: "Casual Labor — Other", products: [urea, can] },
  linked,
  inputSubcategory: (name) => (name === "Seed" ? "Seeds" : "Other Inputs"),
  ...over,
});
const after = (over: Partial<PlanInput["after"]>) => ({ ...base().after, ...over });

test("an edit that changes no money or date leaves the ledger alone", () => {
  const plan = planActivityCostSync(base());
  assert.equal(plan.isEmpty, true);
  assert.deepEqual(plan.notes, []);
});

test("raising labour updates the linked labour entry, and nothing else", () => {
  const plan = planActivityCostSync(base({ after: after({ labourCost: 2500 }) }));
  assert.equal(plan.updates.length, 1);
  assert.equal(plan.updates[0].id, "L");
  assert.equal(plan.updates[0].updates.amount_kes, 2500);
  assert.equal(plan.updates[0].updates.rate_per_worker_per_day, 416.67);
  assert.equal(plan.creates.length + plan.deletes.length, 0);
});

test("setting labour to zero removes the labour entry", () => {
  const plan = planActivityCostSync(base({ after: after({ labourCost: 0 }) }));
  assert.deepEqual(plan.deletes.map((d) => d.id), ["L"]);
});

test("changing a product's quantity updates its entry; adding and removing products add and remove entries", () => {
  const more = planActivityCostSync(base({ after: after({ products: [prod("Urea", 3, 600), can] }) }));
  assert.equal(more.updates[0].id, "U");
  assert.equal(more.updates[0].updates.amount_kes, 1800);
  assert.equal(more.updates[0].updates.quantity, 3);

  const added = planActivityCostSync(base({ after: after({ products: [urea, can, prod("Seed", 1, 500)] }) }));
  assert.equal(added.creates.length, 1);
  assert.equal(added.creates[0].cost.description, "Seed");
  assert.equal(added.creates[0].cost.cost_subcategory, "Seeds");
  assert.equal(added.creates[0].cost.activity_log_id, "log1");
  assert.equal(added.creates[0].cost.amount_kes, 500);

  const removed = planActivityCostSync(base({ after: after({ products: [urea] }) }));
  assert.deepEqual(removed.deletes.map((d) => d.id), ["C"]);
});

test("renaming a product replaces its entry", () => {
  const plan = planActivityCostSync(base({ after: after({ products: [urea, prod("Calcium nitrate", 1, 800)] }) }));
  assert.deepEqual(plan.deletes.map((d) => d.id), ["C"]);
  assert.equal(plan.creates[0].cost.description, "Calcium nitrate");
});

test("changing the date moves every linked entry, including ones this screen does not edit", () => {
  const plan = planActivityCostSync(base({ context: { ...ctx, date: "2026-03-05", isPrePlanting: true } }));
  assert.deepEqual(plan.updates.map((u) => u.id).sort(), ["C", "L", "T", "U"]);
  assert.ok(plan.updates.every((u) => u.updates.cost_date === "2026-03-05" && u.updates.is_pre_planting === true));
  assert.ok(!plan.updates.find((u) => u.id === "T")?.updates.amount_kes);
});

test("a labour or product entry that is missing is never recreated; the person is told instead", () => {
  const withoutLabour = linked.filter((c) => c.id !== "L");
  const plan = planActivityCostSync(base({ linked: withoutLabour, after: after({ labourCost: 2500 }) }));
  assert.equal(plan.creates.length, 0);
  assert.match(plan.notes[0], /no linked labour cost entry/);

  const withoutUrea = linked.filter((c) => c.id !== "U");
  const p2 = planActivityCostSync(base({ linked: withoutUrea, after: after({ products: [prod("Urea", 5, 600), can] }) }));
  assert.equal(p2.creates.length, 0);
  assert.match(p2.notes[0], /Urea changed/);
});

test("an older activity with no linked entries can still be edited for non-money fields without noise", () => {
  const plan = planActivityCostSync(base({ linked: [] }));
  assert.equal(plan.isEmpty, true);
  assert.deepEqual(plan.notes, []);
});

test("labour or a product added to an activity that had none does create entries", () => {
  const plan = planActivityCostSync({
    ...base({ linked: [] }),
    before: { labourCost: 0, products: [] },
    after: after({ labourCost: 1500, products: [prod("Seed", 2, 250)] }),
  });
  assert.equal(plan.creates.length, 2);
  assert.deepEqual(plan.creates.map((c) => c.cost.cost_category).sort(), ["Inputs", "Labor"]);
  assert.ok(plan.creates.every((c) => c.cost.activity_log_id === "log1"));
});

test("two lines of the same product are matched in order", () => {
  const twoUrea = [urea, prod("Urea", 1, 600)];
  const l2 = [linked[0], cost({ id: "U1", description: "Urea", amount_kes: 1200, quantity: 2 }), cost({ id: "U2", description: "Urea", amount_kes: 600, quantity: 1, created_at: "2026-03-01T09:00:00Z" })];
  const plan = planActivityCostSync(base({ linked: l2, before: { labourCost: 2000, products: twoUrea }, after: after({ products: [urea, prod("Urea", 4, 600)] }) }));
  assert.deepEqual(plan.updates.map((u) => [u.id, u.updates.amount_kes]), [["U2", 2400]]);
});

// ── the point of all this: after any edit, the ledger equals the activity ──

function applyPlan(entries: CostEntry[], plan: ActivityCostPlan): CostEntry[] {
  let out = entries.filter((c) => !plan.deletes.some((d) => d.id === c.id));
  out = out.map((c) => { const u = plan.updates.find((x) => x.id === c.id); return u ? { ...c, ...u.updates } : c; });
  return [...out, ...plan.creates.map((c, i) => ({ ...(c.cost as CostEntry), id: `new${i}`, created_at: "2026-03-02T00:00:00Z" }))];
}
const ledgerTotal = (rows: CostEntry[]) => rows.filter((c) => c.cost_category === "Labor" || c.cost_category === "Inputs").reduce((s, c) => s + c.amount_kes, 0);

test("after any sequence of edits the linked ledger total equals the activity's labour plus inputs", () => {
  const edits: { labour: number; products: ProductUsed[] }[] = [
    { labour: 2500, products: [urea, can] },
    { labour: 2500, products: [prod("Urea", 3, 600), can, prod("Seed", 1, 500)] },
    { labour: 0, products: [prod("Seed", 2, 500)] },
    { labour: 1800, products: [] },
    { labour: 1800, products: [prod("Foliar", 1, 950), prod("Foliar", 2, 950)] },
  ];
  let ledger = [...linked];
  let current = { labour: 2000, products: [urea, can] };
  for (const e of edits) {
    const plan = planActivityCostSync(base({
      linked: ledger.filter((c) => c.activity_log_id === "log1"),
      before: { labourCost: current.labour, products: current.products },
      after: after({ labourCost: e.labour, products: e.products }),
    }));
    ledger = applyPlan(ledger, plan);
    current = e;
    const expected = e.labour + e.products.reduce((s, p) => s + p.total, 0);
    assert.equal(ledgerTotal(ledger), expected, `after edit to labour ${e.labour}`);
  }
  assert.equal(ledger.find((c) => c.id === "T")?.amount_kes, 500); // the transport entry was never touched
});

test("the confirmation text spells out every ledger change", () => {
  const plan = planActivityCostSync(base({ after: after({ labourCost: 2500, products: [prod("Urea", 3, 600), prod("Seed", 1, 500)] }) }));
  const lines = describePlan(plan);
  assert.ok(lines.includes("Labour: KES 2,000 → KES 2,500"));
  assert.ok(lines.includes("Input: Urea: KES 1,200 → KES 1,800"));
  assert.ok(lines.includes("Add Input: Seed: KES 500"));
  assert.ok(lines.includes("Remove Input: CAN: KES 800"));
});

test("By-activity view: linked costs belong to their own activity only, old data falls back to the day", () => {
  const log1 = { id: "log1", actual_date: "2026-03-01", section_id: "b1", season_id: "s1" };
  const log2 = { id: "log2", actual_date: "2026-03-01", section_id: "b1", season_id: "s1" };
  const costs = [...linked, cost({ id: "other", activity_log_id: "log2", description: "Weeding", cost_category: "Labor", amount_kes: 700 }), cost({ id: "manual", activity_log_id: null, description: "Misc", amount_kes: 100 })];
  assert.deepEqual(relatedCostsForLog(log1, costs).map((c) => c.id).sort(), ["C", "L", "T", "U"]);
  assert.deepEqual(relatedCostsForLog(log2, costs).map((c) => c.id), ["other"]);
  const legacy = { id: "old", actual_date: "2026-03-01", section_id: "b1", season_id: "s1" };
  assert.deepEqual(relatedCostsForLog(legacy, costs).map((c) => c.id), ["manual"]); // never another activity's linked costs
});

test("stock changes by the difference in quantity used", () => {
  const d = inventoryDeltas([prod("Urea", 2, 600), prod("CAN", 1, 800)], [prod("urea ", 3, 600), prod("Seed", 4, 10)]);
  assert.deepEqual(d, { urea: 1, can: -1, seed: 4 });
  assert.deepEqual(inventoryDeltas([urea], [urea]), {});
});
