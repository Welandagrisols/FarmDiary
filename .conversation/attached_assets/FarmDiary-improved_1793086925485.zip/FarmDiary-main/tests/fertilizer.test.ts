import assert from "node:assert/strict";
import test from "node:test";
import {
  ACRES_PER_HECTARE, buildPlanLines, buildPlanText, cropsForPlan, detectProduct, flaggedByLab, formatQuantity,
  itemAppliesToCrop, parseRate, planTotals, scaleRate, solveSubstitute, SWAP_CANDIDATES, totalKgByProduct,
} from "../lib/fertilizer";
import { normalizeParsedReport, type RecommendationItem } from "../lib/soil";
import { KALRO_READER_OUTPUT } from "./fixtures/kalro-narl-sample";

const TODAY = new Date("2026-10-22T08:00:00Z");
const report = normalizeParsedReport(KALRO_READER_OUTPUT, TODAY)!;
const sample = report.samples[0];
const items: RecommendationItem[] = sample.recommendation_items;
const close = (a: number, b: number, eps = 1e-6) => assert.ok(Math.abs(a - b) < eps, `${a} vs ${b}`);

test("rates are read as printed, including the basis written in the advice", () => {
  assert.deepEqual(parseRate("100kg/acre"), { amount: 100, unit: "kg", basis: "acre", basisFromAdvice: false });
  assert.deepEqual(parseRate("5g/plant"), { amount: 5, unit: "g", basis: "plant", basisFromAdvice: false });
  assert.deepEqual(parseRate("50g/tree"), { amount: 50, unit: "g", basis: "tree", basisFromAdvice: false });
  assert.deepEqual(parseRate("2 t/ha"), { amount: 2, unit: "t", basis: "ha", basisFromAdvice: false });
  assert.deepEqual(parseRate("1,5 kg per acre"), { amount: 1.5, unit: "kg", basis: "acre", basisFromAdvice: false });
  assert.deepEqual(parseRate("3 handfuls", "Place farm yard manure per hole"), { amount: 3, unit: "handful", basis: "hole", basisFromAdvice: true });
  assert.equal(parseRate("5g", "Apply N:P:K fertilizer")?.basis, null); // the report does not say per what: never guessed
  assert.equal(parseRate("a lot"), null);
  assert.equal(parseRate(null), null);
});

test("products are recognised from a written grade or a well-known name, and a plain 'can' is not CAN", () => {
  const npk = detectProduct("Apply N:P:K (23:23:0) fertilizer")!;
  assert.deepEqual(npk.grade, { n: 23, p2o5: 23, k2o: 0 });
  assert.equal(npk.gradeSource, "report");
  const can = detectProduct("Top dress with CAN fertilizer")!;
  assert.deepEqual(can.grade, { n: 26, p2o5: 0, k2o: 0 });
  assert.equal(can.gradeSource, "standard");
  assert.equal(detectProduct("Apply NPK 17-17-17 at planting")?.label, "NPK 17:17:17");
  assert.equal(detectProduct("you can apply it later"), null);
  assert.equal(detectProduct("Apply Agricultural Lime: broadcast")?.kind, "lime");
  assert.equal(detectProduct("Place farm yard manure per hole")?.kind, "organic");
  assert.equal(detectProduct("ratio 30:60:90")?.grade, undefined); // impossible grade (over 100%) is ignored
});

test("a per-acre rate is scaled to the plot, per hectare is converted, and per-plant needs a count", () => {
  const acre = scaleRate(parseRate("100kg/acre")!, { areaAcres: 1.5, count: null });
  assert.ok(acre.ok && acre.kg === 150);
  const ha = scaleRate(parseRate("100kg/ha")!, { areaAcres: 1, count: null });
  assert.ok(ha.ok); close(ha.ok ? ha.amount : 0, 100 / ACRES_PER_HECTARE);
  const noCount = scaleRate(parseRate("5g/plant")!, { areaAcres: 1, count: null });
  assert.ok(!noCount.ok && /number of plants/.test(noCount.reason));
  const noArea = scaleRate(parseRate("100kg/acre")!, { areaAcres: null, count: null });
  assert.ok(!noArea.ok && /area/.test(noArea.reason));
  const plants = scaleRate(parseRate("5g/plant")!, { areaAcres: 1, count: 10000 });
  assert.ok(plants.ok && plants.kg === 50);
});

test("KALRO report, potato on 1.5 acres: lime, fertilizer and top dressing are scaled and the nutrients added up", () => {
  const lines = buildPlanLines(items, "Potato", { areaAcres: 1.5, count: 2000 });
  assert.equal(lines.length, 4); // lime (all three crops), manure, NPK, CAN top dressing: nothing meant only for onion or passion
  const lime = lines.find((l) => l.product?.kind === "lime")!;
  assert.ok(lime.scaled?.ok && lime.scaled.kg === 150 && lime.supply === null);
  const totals = planTotals(lines, 1.5);
  close(totals.plot.n, 150 * 1.5 * 0.23 + 100 * 1.5 * 0.26); // 51.75 kg N from the NPK + 39 kg N from the CAN = 90.75
  close(totals.plot.p2o5, 150 * 1.5 * 0.23);
  close(totals.plot.k2o, 0);
  close(totals.perAcre!.n, 34.5 + 26);                    // 60.5 kg N per acre
  close(totals.perAcre!.p2o5, 34.5);
  const kg = totalKgByProduct(lines);
  assert.deepEqual(kg.find((k) => k.label === "Lime"), { label: "Lime", kg: 150 });
  assert.deepEqual(kg.find((k) => k.label === "CAN"), { label: "CAN", kg: 150 });
});

test("rates with no stated basis are shown as printed, not scaled or counted", () => {
  const lines = buildPlanLines(items, "Onion", { areaAcres: 1, count: 10000 });
  const npk = lines.find((l) => l.product?.label === "NPK 23:23:0")!;
  assert.ok(npk.scaled && !npk.scaled.ok);
  assert.equal(npk.supply, null);
  const totals = planTotals(lines, 1);
  assert.equal(totals.skipped, 1);                         // the unreadable NPK line is reported as skipped
  close(totals.plot.n, 5 * 10000 / 1000 * 0.26 + 10 * 10000 / 1000 * 0.26); // CAN at 5 g and 10 g per plant
});

test("advice applies to a crop when it names that crop, lists it among several, or names none", () => {
  assert.equal(itemAppliesToCrop({ crop: "Passion, Onion, Potato" }, "Onion"), true);
  assert.equal(itemAppliesToCrop({ crop: "Potato" }, "Onion"), false);
  assert.equal(itemAppliesToCrop({ crop: null }, "Onion"), true);
  assert.equal(itemAppliesToCrop({ crop: "All crops" }, "Onion"), true);
  assert.deepEqual(cropsForPlan(items, ["PASSION", "Onion", "Potato", "Maize"]), ["Passion", "Onion", "Potato", "Maize"]);
});

test("a product on hand can stand in for the recommended one, and the shortfall is reported", () => {
  const target = { n: 34.5, p2o5: 34.5, k2o: 0 }; // what 150 kg of 23:23:0 supplies
  const find = (...labels: string[]) => SWAP_CANDIDATES.filter((c) => labels.includes(c.label));

  const dapUrea = solveSubstitute(target, find("DAP", "Urea"))!;
  assert.equal(dapUrea.exact, true);
  close(dapUrea.amounts.find((a) => a.label === "DAP")!.kg, 75);
  close(dapUrea.amounts.find((a) => a.label === "Urea")!.kg, 21 / 0.46, 1e-6);
  close(dapUrea.delivered.n, 34.5); close(dapUrea.delivered.p2o5, 34.5);

  const dapCan = solveSubstitute(target, find("DAP", "CAN"))!;
  assert.equal(dapCan.exact, true);

  const canOnly = solveSubstitute(target, find("CAN"))!;
  assert.equal(canOnly.exact, false);
  close(canOnly.coverage.n!, 1);
  close(canOnly.coverage.p2o5!, 0);                        // CAN has no phosphate: the plan says so

  assert.equal(solveSubstitute({ n: 0, p2o5: 0, k2o: 0 }, find("DAP")), null);
  assert.equal(solveSubstitute(target, []), null);
});

test("what the lab marked on the KALRO report: pH class and deficient copper, nothing else", () => {
  const flagged = flaggedByLab(sample.results).map((f) => `${f.label}: ${f.word}`);
  assert.deepEqual(flagged, ["pH (water): Mod. acid", "Copper: Deficient"]);
});

test("quantities read naturally", () => {
  assert.equal(formatQuantity(150, "kg"), "150 kg");
  assert.equal(formatQuantity(50000, "g"), "50 kg");
  assert.equal(formatQuantity(0.5, "kg"), "500 g");
  assert.equal(formatQuantity(1, "handful"), "1 handful");
  assert.equal(formatQuantity(6000, "handful"), "6000 handfuls");
});

test("the shareable plan carries the advice, the scaled totals, and a reminder to check locally", () => {
  const lines = buildPlanLines(items, "Potato", { areaAcres: 1.5, count: 2000 });
  const text = buildPlanText({
    farmName: "Kapletundo farm", plotName: "Lower field", crop: "Potato", areaAcres: 1.5, count: 2000,
    lab: "KALRO NARL", labNumber: "18040", sampleDate: "2025-12-04", lines, totals: planTotals(lines, 1.5),
    flagged: flaggedByLab(sample.results).map((f) => ({ label: f.label, word: f.word })),
  });
  assert.match(text, /Fertilizer plan: Potato/);
  assert.match(text, /Lower field · 1.5 acres/);
  assert.match(text, /lab no\. 18040/);
  assert.match(text, /Marked by the lab: pH \(water\) – Mod\. acid; Copper – Deficient/);
  assert.match(text, /100kg\/acre \(at least 2 months before planting\) → about 150 kg in total/);
  assert.match(text, /N 60\.5 kg, P₂O₅ 34\.5 kg, K₂O 0 kg/);
  assert.match(text, /Check rates and products with a local agronomist/);
});
