import assert from "node:assert/strict";
import test from "node:test";
import express from "express";
import type { AddressInfo } from "node:net";
import { isSoilParsePath, registerSoilRoutes } from "../server/soil";
import { KALRO_READER_OUTPUT } from "./fixtures/kalro-narl-sample";

// A tiny in-memory stand-in for the parts of Supabase the route touches.
function makeFakeSupabase(opts: { plotOk?: boolean } = {}) {
  const state = { uploads: [] as string[], removed: [] as string[], inserted: [] as any[] };
  const query = (table: string) => {
    const q: any = {
      _insert: null as any[] | null,
      select() { return q; }, eq() { return q; }, contains() { return q; }, limit() { return q; },
      insert(rows: any[]) { q._insert = rows; return q; },
      update() { return q; },
      maybeSingle: async () => ({ data: table === "plots" && opts.plotOk !== false ? { id: "plot-1" } : null, error: null }),
      single: async () => ({ data: null, error: null }),
      then(resolve: any) {
        if (table === "soil_tests" && q._insert) { state.inserted.push(...q._insert); return resolve({ data: q._insert, error: null }); }
        return resolve({ data: [], error: null });
      },
    };
    return q;
  };
  const client: any = {
    from: (t: string) => query(t),
    storage: { from: () => ({
      upload: async (path: string) => { state.uploads.push(path); return { error: null }; },
      remove: async (paths: string[]) => { state.removed.push(...paths); return { error: null }; },
      download: async () => ({ data: null, error: { message: "n/a" } }),
      createSignedUrl: async () => ({ data: { signedUrl: "https://signed" }, error: null }),
    }) },
  };
  return { client, state };
}

async function withServer(fake: any, run: (url: string) => Promise<void>) {
  const app = express();
  app.use(express.json({ limit: "40mb" }));
  const requireFarmManager = (req: any, _res: any, next: any) => { req.farmId = req.params.farmId; req.farmUser = { id: "user-1" }; next(); };
  registerSoilRoutes(app, { requireFarmManager, supabaseAdmin: fake });
  const server = app.listen(0);
  try { await run(`http://127.0.0.1:${(server.address() as AddressInfo).port}`); } finally { server.close(); }
}

const JPEG = Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 16, 0x4a, 0x46, 0x49, 0x46, 0, 1, 1, 0, 0, 1, 0, 1, 0, 0]);
const PDF = Buffer.from("%PDF-1.4\n1 0 obj\n<<>>\nendobj\n");
const PNG = Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
const post = (url: string, body: unknown) =>
  fetch(`${url}/api/farms/farm-1/soil/parse`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });

function stubReader(handler: () => { status: number; json?: unknown }) {
  const real = globalThis.fetch;
  let calls = 0;
  let lastBody: any = null;
  globalThis.fetch = (async (input: any, init?: any) => {
    if (String(input).startsWith("https://api.anthropic.com")) {
      calls++;
      lastBody = JSON.parse(init.body);
      const r = handler();
      return new Response(JSON.stringify(r.json ?? {}), { status: r.status });
    }
    return real(input, init);
  }) as typeof fetch;
  process.env.ANTHROPIC_API_KEY = "test-key";
  return { restore: () => { globalThis.fetch = real; }, calls: () => calls, lastBody: () => lastBody };
}

const toolReply = (input: unknown) => ({ status: 200, json: { content: [{ type: "tool_use", name: "record_soil_report", input }] } });

test("only the report upload route gets the large request-body limit", () => {
  assert.equal(isSoilParsePath("/api/farms/abc-123/soil/parse"), true);
  assert.equal(isSoilParsePath("/api/farms/abc/soil/parse/extra"), false);
  assert.equal(isSoilParsePath("/api/migrate"), false);
  assert.equal(isSoilParsePath("/api/farms/abc/soil/report-url"), false);
});

test("the real KALRO report PDF is stored, read immediately and saved with every field", async () => {
  const reader = stubReader(() => toolReply(KALRO_READER_OUTPUT));
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "PAUL_MUTAI.pdf", media_type: "application/pdf", data: PDF.toString("base64") }] });
    const body: any = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.read_ok, true);
    assert.equal(body.saved.length, 1);
    const row = body.saved[0];
    assert.equal(row.source, "pdf");
    assert.equal(row.status, "parsed");
    assert.equal(row.lab_reference, "18040");
    assert.equal(row.received_date, "2025-12-04");
    assert.equal(row.report_date, "2025-12-23");
    assert.equal(row.sample_date, null);
    assert.deepEqual(row.intended_crops, ["Passion", "Onion", "Potato"]);
    assert.equal(row.results.length, 13);
    assert.equal(row.recommendation_items.length, 12);
    assert.match(row.recommendations, /Liming is recommended at 100kg\/acre/);
    assert.equal(row.report_files[0].media_type, "application/pdf");
    assert.ok(state.uploads[0].endsWith(".pdf"));
    // The reader was given the PDF as a document and told to copy values rather than convert them.
    const sent = reader.lastBody();
    assert.equal(sent.messages[0].content[0].type, "document");
    assert.match(sent.system, /Never calculate, convert units/);
    assert.match(sent.system, /day first/);
    // The reader is never sent the farmer's contact details field: the schema has none, and the prompt forbids them.
    assert.ok(!JSON.stringify(sent.tools).includes("phone"));
  });
  reader.restore();
});

test("a report photo with several samples saves one test per sample against the chosen plot", async () => {
  const reader = stubReader(() => toolReply({
    is_soil_report: true, lab_name: "Lab X",
    samples: [
      { label: "Field A", sample_date: "2026-09-01", results: [{ key: "ph_water", label_on_report: "pH", value: 5.5, confidence: "high" }] },
      { label: "Field B", results: [{ key: "ph_water", label_on_report: "pH", value: 6.1, confidence: "high" }] },
    ],
  }));
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "p.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") }], plot_id: "plot-1", sampling_method: "composite" });
    const body: any = await res.json();
    assert.equal(body.saved.length, 2);
    assert.equal(body.saved[0].plot_id, "plot-1");
    assert.equal(body.saved[0].farm_id, "farm-1");
    assert.equal(body.saved[0].sampling_method, "composite");
    assert.equal(body.saved[0].created_by, "user-1");
    assert.match(body.saved[1].extraction_notes, /Sample 2 of 2/);
    assert.equal(state.uploads.length, 1);
    assert.ok(state.uploads[0].startsWith("farm-1/"));
  });
  reader.restore();
});

test("a document that is not a soil report saves nothing and removes the stored file", async () => {
  const reader = stubReader(() => toolReply({ is_soil_report: false, samples: [] }));
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "x.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") }] });
    assert.equal(res.status, 422);
    assert.equal(state.inserted.length, 0);
    assert.equal(state.removed.length, 1);
  });
  reader.restore();
});

test("if reading fails the file is still kept and a retryable placeholder is saved", async () => {
  const reader = stubReader(() => ({ status: 529, json: { error: "overloaded" } }));
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "x.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") }] });
    const body: any = await res.json();
    assert.equal(res.status, 200);
    assert.equal(body.read_ok, false);
    assert.equal(body.retryable, true);
    assert.equal(body.saved.length, 1);
    assert.deepEqual(body.saved[0].results, []);
    assert.deepEqual(body.saved[0].intended_crops, []);
    assert.equal(body.saved[0].status, "needs_review");
    assert.equal(state.removed.length, 0);
    assert.equal(state.inserted.length, 1);
  });
  reader.restore();
});

test("a file whose bytes do not match its declared type is rejected before anything is stored or sent", async () => {
  const reader = stubReader(() => toolReply({ is_soil_report: true, samples: [] }));
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "x.pdf", media_type: "application/pdf", data: PNG.toString("base64") }] });
    assert.equal(res.status, 415);
    assert.equal(state.uploads.length, 0);
    assert.equal(reader.calls(), 0);
  });
  reader.restore();
});

test("a PDF mixed with photos is refused", async () => {
  const reader = stubReader(() => toolReply({}));
  const { client } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [
      { name: "a.pdf", media_type: "application/pdf", data: PDF.toString("base64") },
      { name: "b.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") },
    ] });
    assert.equal(res.status, 400);
  });
  reader.restore();
});

test("a plot from another farm is refused before anything is stored", async () => {
  const reader = stubReader(() => toolReply({ is_soil_report: true, samples: [] }));
  const { client, state } = makeFakeSupabase({ plotOk: false });
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "x.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") }], plot_id: "someone-elses-plot" });
    assert.equal(res.status, 400);
    assert.equal(state.uploads.length, 0);
  });
  reader.restore();
});

test("without a server API key the report is still saved for manual entry", async () => {
  const reader = stubReader(() => toolReply({}));
  delete process.env.ANTHROPIC_API_KEY;
  const { client, state } = makeFakeSupabase();
  await withServer(client, async (url) => {
    const res = await post(url, { files: [{ name: "x.jpg", media_type: "image/jpeg", data: JPEG.toString("base64") }] });
    const body: any = await res.json();
    assert.equal(body.read_ok, false);
    assert.equal(body.retryable, false);
    assert.equal(state.inserted.length, 1);
    assert.equal(reader.calls(), 0);
  });
  reader.restore();
});
