import assert from "node:assert/strict";
import test from "node:test";
import { looksLikeBackup, prepareBackupImport, sumSkipped } from "../lib/backup-import";

const ctx = { farmId: "farm-b", seasonId: "season-b", blockIds: ["blk-1", "blk-2"], existing: {} };

const cost = (over: Record<string, unknown> = {}) => ({
  id: "old-id", farm_id: "farm-a", season_id: "season-a", section_id: "blk-1",
  cost_category: "Inputs", description: "DAP fertiliser", cost_date: "2026-03-01", amount_kes: 5000,
  created_at: "2026-03-01T00:00:00Z", ...over,
});

test("imported records are re-scoped to the target farm and season, with new identity", () => {
  const out = prepareBackupImport({ costs: [cost()] }, ctx);
  const rec = out.costs.records[0];
  assert.equal(rec.farm_id, "farm-b");
  assert.equal(rec.season_id, "season-b");
  assert.ok(!("id" in rec) && !("created_at" in rec));
});

test("authorship from the file is discarded", () => {
  const out = prepareBackupImport({ costs: [cost({ recorded_by: "someone-else", recorded_by_email: "x@y.z" })] }, ctx);
  assert.ok(!("recorded_by" in out.costs.records[0]));
  assert.ok(!("recorded_by_email" in out.costs.records[0]));
});

test("importing the same file twice skips records already present", () => {
  const first = prepareBackupImport({ costs: [cost()] }, ctx);
  const second = prepareBackupImport({ costs: [cost()] }, { ...ctx, existing: { costs: first.costs.records } });
  assert.equal(second.costs.records.length, 0);
  assert.equal(second.costs.skipped.duplicate, 1);
});

test("two genuine identical entries in one file are both kept", () => {
  const out = prepareBackupImport({ costs: [cost(), cost({ id: "other-id" })] }, ctx);
  assert.equal(out.costs.records.length, 2);
  assert.equal(out.costs.skipped.duplicate, 0);
});

test("re-importing a file with repeated entries skips exactly as many as are already saved", () => {
  const file = { costs: [cost(), cost({ id: "b" }), cost({ id: "c" })] };
  const partial = prepareBackupImport({ costs: [cost()] }, ctx); // one of the three already saved
  const again = prepareBackupImport(file, { ...ctx, existing: { costs: partial.costs.records } });
  assert.equal(again.costs.records.length, 2);
  assert.equal(again.costs.skipped.duplicate, 1);
});

test("a block missing from this season is cleared for costs but never invented", () => {
  const out = prepareBackupImport({ costs: [cost({ section_id: "gone-block" })] }, ctx);
  assert.equal(out.costs.records[0].section_id, null);
  assert.equal(out.costs.blockCleared, 1);
});

test("harvest records need a block that exists here, otherwise they are skipped", () => {
  const harvest = (section_id: string | null) => ({
    section_id, harvest_date: "2026-06-01", bags: 10, kg_per_bag: 90, total_kg: 900,
    price_per_bag_kes: 2000, total_revenue_kes: 20000,
  });
  const out = prepareBackupImport({ harvest_records: [harvest("blk-2"), harvest("gone-block"), harvest(null)] }, ctx);
  assert.equal(out.harvest.records.length, 1);
  assert.equal(out.harvest.skipped.unknownBlock, 2);
});

test("invalid numbers and missing fields are rejected, not saved as zero", () => {
  const out = prepareBackupImport(
    { costs: [cost({ amount_kes: "abc" }), cost({ amount_kes: -5 }), cost({ description: "" }), cost({ amount_kes: NaN }), null, "x"] },
    ctx,
  );
  assert.equal(out.costs.records.length, 0);
  assert.equal(out.costs.skipped.invalid, 6);
  assert.equal(sumSkipped(out).invalid, 6);
});

test("files that are not backups are recognised", () => {
  assert.equal(looksLikeBackup({ foo: 1 }), false);
  assert.equal(looksLikeBackup([]), false);
  assert.equal(looksLikeBackup({ costs: [] }), true);
});

import { backupBlocker } from "../lib/backup-import";

test("an older backup that mixes several crop cycles is refused instead of piled into one", () => {
  const mixed = { costs: [cost({ season_id: "s1" }), cost({ season_id: "s2", description: "Seed" })] };
  assert.match(backupBlocker(mixed) ?? "", /2 crop cycles/);
});

test("an older backup from a single cycle, and any current-format backup, can be imported", () => {
  assert.equal(backupBlocker({ costs: [cost({ season_id: "s1" }), cost({ season_id: "s1", description: "Seed" })] }), null);
  assert.equal(backupBlocker({ format_version: 2, season_id: "s1", costs: [cost({ season_id: "s1" })] }), null);
});

test("a cost's link to its old activity is dropped on import, since imported activities get new ids", () => {
  const out = prepareBackupImport({ costs: [cost({ activity_log_id: "old-activity-id" })] }, ctx);
  assert.equal(out.costs.records.length, 1);
  assert.ok(!("activity_log_id" in out.costs.records[0]));
});
