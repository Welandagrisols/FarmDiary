# Soil module — setup (3 steps)

1. **Database** – in the Supabase SQL editor run `scripts/soil-module.sql` (after `sales-control.sql`). Back up first.
   It creates `plots`, `soil_tests` (with RLS) and a private `soil-reports` storage bucket.
   Check Storage → the `soil-reports` bucket exists and is **private**. If the script could not create it, create it by hand.
2. **Server** – add the secret `ANTHROPIC_API_KEY` where the Express server runs (Replit Secrets). Optional: `SOIL_PARSE_MODEL`
   (default `claude-sonnet-5-5`). Without the key reports are still saved, just not read.
3. **App** – make a **new native build** (EAS). `app.config.js` now
   declares the camera permission for `expo-image-picker`; an over-the-air update alone will not add it.

Check after step 2: upload `PAUL_MUTAI_Sironet_Passion.pdf` from Soil Tests → Scan or upload. Expect 1 test, 13 results,
lab number 18040, received 2025-12-04, reported 2025-12-23, sample date empty, crops Passion/Onion/Potato, 12 advice items.

## How it behaves
- Tests belong to the **farm** (Whole farm) or a **plot**, never to a season, so they carry across all seasons and cycles.
- A report is stored, read and saved in one step. It is saved as "Read – to confirm" (or "Check values" if anything looks odd) until you confirm it.
- Values keep the lab's own units, method and rating wording. Nothing is converted or calculated.
- A report with several samples is saved as one test per sample; change each one's plot afterwards.
- If reading fails, the file is still saved and can be re-read or typed in by hand. Reading needs internet.
- Limits: up to 5 photos or one PDF (≤15 MB in the app), 12 reads per user per 10 minutes.
- Privacy: the file is sent to the Anthropic API to be read. The farmer's name, address and phone number are not recorded.
- Hosting: report uploads can be several MB. If your host/proxy limits request size below ~40 MB, large PDFs will fail with "too large".

## Not tested here
The real reader against your PDF (no API key in my environment), the SQL on your live database, and the camera on a phone.
Everything else is covered: 47 automated tests pass, TypeScript and lint are clean, and the Android and server builds succeed.
