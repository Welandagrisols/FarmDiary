# Farm Diary — all improvements in this version

Verified after all changes: `tsc --noEmit` clean (was 1 error), 82/82 tests pass, lint 0 errors (29 warnings, was 35), Android bundle and server build succeed.
Not verified: Android build, live Supabase, runtime behaviour on a device.

## server/routes.ts — /api/migrate hardening
- Every record must have a string `id`; max 5000 rows per table.
- Existing record IDs belonging to a farm the caller isn't allowed to write are rejected (403) — stops upsert overwriting another farm's rows.
- Farms with no owner can only be claimed by someone with a `farm_memberships` row on them.
- `recorded_by` / `recorded_by_email` are set from the caller's token, not the payload.
- Set `DISABLE_MIGRATE=true` on the server once migration is finished to switch the endpoint off.

## app/cost-breakdown.tsx — planting-block support
- Tabs are built from the season's real blocks (legacy section A/B seasons still work). Previously new blocks were invisible outside "All".
- Cost/activity badges show real block names/numbers; removed two unused totals.

## app/export.tsx, server/index.ts
- Removed dead CSV helper and unused import; fixed one implicit-any type error.

## Backup import (app/export.tsx + new lib/backup-import.ts)
Verified: `tsc` clean, 18/18 tests pass (9 new in tests/backup-import.test.ts), lint 0 errors.
- Import logic moved into a pure, tested module; `export.tsx` now only handles UI.
- Duplicates: records already in the target season are skipped, so re-importing the same file no longer doubles data. Matching counts copies, so genuine repeated entries (e.g. two equal wage payments) are kept.
- Blocks: a record's block is kept only if it exists in the target season. Costs/logs/inventory/observations with an unknown block are saved without a block; harvest records (which need a block) are skipped and reported. Blocks are never invented.
- Validation: missing dates/descriptions and non-numeric, negative or NaN amounts are rejected instead of saved as zero.
- Authorship/identity from the file (`recorded_by`, ids, farm/season) is discarded; records are attributed to the person importing.
- Confirmation lists exactly what will be imported/skipped and warns if the backup is from a different farm.
- Failures are counted per type with the first error; a retry only imports what is still missing.
- Blocks the import if there is no active farm/season.

## Soil module (new) — see SOIL-SETUP.md
- Plots and soil tests (farm-wide or per plot, independent of season), photo/PDF reading, review/confirm screen, history comparison.
- Built around the KALRO NARL report format: day-first dates, received vs sampling date, meq%/ppm units, value + class columns,
  verbatim fertilizer advice plus per-crop action list, blank rows left out.
- New: scripts/soil-module.sql, lib/soil.ts, lib/soil-storage.ts, server/soil.ts, app/soil.tsx, add-soil-test.tsx, soil-result.tsx, plots.tsx, add-plot.tsx.
- Changed: server/routes.ts + server/index.ts (route + large body limit for the upload route only), lib/api.ts, app/_layout.tsx, More tab, app.config.js (camera permission).
- Import/Export row subtitle corrected (it only handles JSON backups).

## Workflow audit fixes — see WORKFLOW-AUDIT.md
- New: lib/season-finance.ts, season-rules.ts, use-season-sales.ts, write-errors.ts, cost-subcategory.ts; tests/season-workflow.test.ts.
- Changed: Dashboard, Costs tab, Season Report, Season History, Season Control, Export/Import, Log Activity, Edit Activity, Sales,
  FarmContext (closed-cycle guard) and the screens that delete or add records (so errors are shown, not swallowed).

## Activity ↔ cost links — see ACTIVITY-COST-LINKS.md
- New: lib/activity-costs.ts (planner), activity-links.ts, confirm-remove-activity.ts, scripts/activity-cost-links.sql, tests/activity-costs.test.ts.
- Changed: Log Activity (links costs), Edit Activity (updates ledger and stock with a preview), the four activity-removal points,
  By-activity breakdown, FarmContext (editCostEntry, adjustInventoryUse), backup import (drops old links).

## Fertilizer plan — see FERTILIZER-PLAN.md
- New: lib/fertilizer.ts, app/soil-plan.tsx, tests/fertilizer.test.ts. Changed: soil test screen (advice card, "Add advice", "Open fertilizer plan").
- Scales the lab's (or an advisor's) advice to a plot, totals the nutrients, suggests substitutes, estimates cost, shares as text. No invented recommendations.

## Design refresh — see DESIGN.md
- New: components/FloatingTabBar.tsx, components/BrandRow.tsx; rewritten constants/colors.ts; Manrope replaces DM Sans; type scale, cards, hero and pill styles changed across all screens. Styles only.
