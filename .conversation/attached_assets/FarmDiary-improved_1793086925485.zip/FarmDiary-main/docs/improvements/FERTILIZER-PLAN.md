# Fertilizer plan (from a soil test)

## What it is, and what it deliberately is not
The plan takes the **advice on a soil test** (the lab's written recommendation, or advice an advisor typed in) and does the arithmetic a farmer
or advisor would otherwise do by hand. **The app does not make up recommendations.** It has no soil thresholds or fertilizer rates of its own, because
wrong rates cost farmers money and yield. Every quantity traces back to wording on the report or to advice a person added.

## How to use it
1. Open a soil test, go to **Recommendations**, tap **Open fertilizer plan**.
2. Pick the **crop**. Enter the **area in acres** (prefilled from the plot, or the farm for a whole-farm test) and, for rates given per plant/tree/hole, the **number of plants**.
3. Each piece of advice shows the rate **as written**, then the **amount for your area** (for example `100kg/acre` on 1.5 acres = about 150 kg).
4. **Nutrients this plan supplies**: kg of N, P₂O₅ and K₂O for the plot and per acre, with elemental P and K alongside.
5. **Can't get this fertilizer?** Pick what you have (one or two products). It shows the quantities that deliver the same nutrients, or says plainly which nutrient it cannot match.
6. **Estimated cost**: type today's price per kg (prefilled when the same product is in your inventory in kg).
7. **Share this plan** sends a plain-text version, for example by WhatsApp.

No lab advice on the report? Tap **+ Add advice** on the soil test and write it (crop, what to apply, rate with its basis, timing). It is marked "Added by you" and flows into the plan the same way.

## Rules it follows
- A rate is only scaled when it says what it applies to (per acre, per hectare, per plant/tree/hole). Otherwise it is shown as written with a note to check the original.
- Fertilizer grade comes from the advice itself when written (`N:P:K (23:23:0)`); otherwise from typical declared grades: urea 46-0-0, CAN 26-0-0, DAP 18-46-0, TSP 0-46-0, MOP 0-0-60, sulphate of ammonia 21-0-0. The screen says when a grade is assumed. Edit `STANDARD_PRODUCTS` in `lib/fertilizer.ts` if your bags differ.
- Lime and manure are scaled but not counted in the nutrient totals (their nutrient content is not a fixed grade).
- Handfuls, bags and litres are not converted to kg, so they are not costed.
- "Marked by the lab" lists only the lab's own class words (for example "Deficient", "Mod. acid").

## Tested against your KALRO report
Potato on 1.5 acres: lime 100 kg/acre → 150 kg; NPK 23:23:0 at 150 kg/acre → 225 kg; CAN top dressing at 100 kg/acre → 150 kg.
Plan supplies 60.5 kg N and 34.5 kg P₂O₅ per acre. Swapping the 23:23:0 for DAP + urea gives 75 kg + 45.7 kg per acre for the same N and P₂O₅.
Onion/passion rates written without a basis ("5g", "50g") are shown as written and flagged, not guessed.

## Not built (needs your agronomy)
- **An engine that recommends from soil values alone** (for labs that give no advice). It needs your validated rules: crop × soil class → product and rate. If you write them as a table, building the engine around it is straightforward.
- Tracking planned vs applied, and saving a plan into a crop cycle's budget.
