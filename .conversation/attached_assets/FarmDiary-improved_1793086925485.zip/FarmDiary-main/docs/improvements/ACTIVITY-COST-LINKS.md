# Activities and their cost entries are now linked

## The problem this fixes
An activity's labour and inputs are saved as separate cost entries in the ledger, and every total uses the ledger.
Editing an activity changed only the activity, so the two drifted apart. The "By activity" view also guessed which
costs belonged to which activity by date, so two activities on one day each showed all of that day's costs.
There was no way to edit a cost entry at all, and the note I added earlier telling you to "edit it in the Costs tab" was wrong.

## Switch it on
1. Run `scripts/activity-cost-links.sql` in the Supabase SQL editor (back up first).
   - Part 1 adds `costs.activity_log_id` and widens `costs.days_worked` to a decimal (so half-day labour cannot be rejected).
   - Part 2 links existing entries, only where activity, block, date, text and amount all match exactly and only one activity fits.
2. Use this version of the app. No new build is needed for this part.
3. Restart the app once after running the SQL (the app remembers whether the column exists).
The app works before step 1; it just does not link anything until the column exists.

## How it behaves
- New activities: every cost entry they create (labour, each input, other costs) carries the activity's id.
- Editing an activity shows what the ledger will do before saving, for example
  `Labour: KES 2,000 → KES 2,500`, `Add Input: Seed: KES 500`, `Remove Input: CAN: KES 800`. Cancel changes nothing.
- It updates changed amounts, adds entries for labour or products you newly added, and removes entries for labour or
  products you took away. A changed date moves every linked entry, including transport or facilitation costs.
- It never re-creates an entry that is missing. If an older activity has no matching entry, the ledger is left alone and the
  dialog says so.
- Stock follows an edit: if you change the quantity of a product used, the inventory's "used" figure changes by the difference.
- Removing an activity that has cost entries now asks: keep the costs (they become ordinary costs) or remove them too.
- "By activity" shows each activity's own costs. Same-day matching is used only for older, unlinked data.
- Order of saving: ledger first, then the activity, then stock. If something fails part-way, open the activity and save again to finish.

## Limits
- Older activities stay unlinked unless Part 2 can match them exactly. They behave as before (editing them does not change the ledger).
- You still cannot edit a cost entry directly; it changes only through its activity, or by deleting and adding it.
- Removing an activity does not give its stock back.
- Past entries saved under the subcategory "Fungicide" are not corrected (the true category was never recorded).

## What was tested
- 72 automated tests pass (15 new), including one that applies five successive edits and checks that the ledger total always equals the activity's labour plus inputs.
- Both SQL scripts were run on a real PostgreSQL 16 using the project's own table definitions: the backfill links exactly the four expected entries and skips ambiguous, other-farm, other-block, wrong-amount and manual ones; re-running changes nothing; half-days are accepted; deleting an activity unlinks its costs.
- The soil migration (scripts/soil-module.sql) was also run twice there: constraints, plot-to-farm rule, private bucket and update trigger all behave as designed. Its row-level-security policies were not exercised, because the real Supabase roles were not available.
- Not tested: the screens on a phone.
