# Design refresh

Follows `FarmDiary-design-guide.md`, with the active tab in brand green instead of near-black. Styles only: no screen logic, data or navigation changed.
Before/after pictures are in `docs/improvements/screenshots/`.

## What the look is made of
- **Font:** Manrope (400/500/600/700), bundled with the app (`@expo-google-fonts/manrope`). DM Sans was removed.
- **Type scale:** nothing below 12px. Body 15, secondary 14, captions 13, section titles 17, screen titles 32 (semibold, tight tracking), big numbers 34 with tabular figures.
  Old sizes were moved up the same scale (for example 11 to 12, 12 to 13, 13 to 14, 14 to 15). 43% of text was 12px or smaller before.
- **Colour:** soft grey-green screens (`#F2F4F2`), white cards, brand green `#187E36`, one near-black "ink" `#141D16`, status colours as soft background + strong text pairs. All in `constants/colors.ts`.
- **Cards:** white, radius 20, soft shadow (`CARD_SHADOW`), no border.
- **Hero cards:** ink background with a faint leaf watermark (Home season summary, Log New Activity, Costs total, Season Report, Harvest summary). No gradients.
- **Filters and segmented pills:** the selected one is ink with white text.
- **Tab bar:** a floating white pill (`components/FloatingTabBar.tsx`); the current tab is a green pill. Same five tabs and navigation as before.
- **Brand row** (`components/BrandRow.tsx`): leaf mark, "FarmDiary", and the farm name, above each main tab's title.
- **System header** (screens that use it): background, title font and no divider line now match; Sales, Farm Team, Personal Expenses, Add Expense and Admin have proper titles instead of the raw route name.

## For new screens
Use `COLORS` and `CARD_SHADOW`, font names `Manrope_400Regular` ... `Manrope_700Bold`, never a font size under 12, and ink (not green) for hero cards and selected filter pills.

## How it was checked
The app was rendered in a browser at phone size with sample data, before and after, for the five main tabs, the soil, plot, report and harvest screens and 11 forms and lists (screenshots included).
The conversion was applied mechanically to every screen, so screens that were not rendered (sign-in, farm setup, add-harvest, add-personal-expense, edit-activity, the soil capture screen) got the same changes without being looked at.
A browser is not a phone: shadows, status-bar spacing and font rendering differ a little on Android and iOS. Check a few screens on your phone.
