# End-to-end workflow audit: farm → crop cycle → activity → cost → harvest → sale → report

Method: read the code for every hand-off, then wrote a one-cycle test scenario (tests/season-workflow.test.ts).
Not done: running the app on a phone or against your live database.

## Found and fixed
| # | Problem | Effect | Fix |
|---|---------|--------|-----|
| 1 | New harvest entries are saved with revenue 0 (money lives in the sales ledger), but Costs tab, Season History and the Export still added up harvest revenue only | Costs tab and Season History showed revenue 0 and a loss on a profitable cycle; Dashboard and Season Report disagreed with them | One shared rule in `lib/season-finance.ts`, used by Dashboard, Costs tab, Season Report, Season History and Export |
| 2 | Season History never loaded sales | Closed cycles showed no sales revenue | Loads the farm's sales once (owner/manager), splits per cycle |
| 3 | Export summary summed every cycle but was labelled with one; my backup import then put all cycles into one | Inflated totals after a restore | Export = open cycle only (`format_version 2`, with `season_id`); import refuses old mixed-cycle files |
| 4 | Nothing stopped adding, editing or removing records in a closed cycle | A reviewed, closed cycle's totals could change silently | Guard in FarmContext for costs, activities, observations, harvests (and sales entry); clear message shown on every screen |
| 5 | Every input used in an activity was saved under subcategory "Fungicide" | Fertilizer and seed appeared under fungicides in cost breakdowns | Subcategory now comes from the product (stock category, then catalogue, else "Other Inputs") |
| 6 | Closing a season: failed save left the button stuck; no warning about unchecked sales | Spinner stuck; pending sales silently left out of revenue | Error handling, plus a warning listing pending sales and their value |
| 7 | Mark-done from the schedule left a stuck spinner if the save failed; several delete actions failed silently | Confusing screens | try/catch/finally and a visible message |
| 9 | There was no way to edit a cost entry, and the edit screen told you to do so | Misleading note | Edits now flow from the activity; the note is accurate |
| 8 | `totalSpent`/`totalRevenue` in the farm context summed all cycles and nothing used them | A trap for future code | Removed |

## Checked and fine
- Switching farms clears everything and reloads, and rolls back if the load fails.
- Costs, activities, harvests and sales are filtered by cycle everywhere they are totalled; sales are loaded per cycle.
- Buying stock does not create a cost; the cost is recorded when stock is used in an activity, so nothing is counted twice.
- Closing a season keeps all data; there is no season delete in the app.
- Revenue rule: recorded and void-requested sales count; pending sales are shown but not counted; voided never count.

## Still open (needs your decision)
1. ~~Editing an activity does not change its cost entries.~~ **Fixed:** activities and their cost entries are now linked and kept in step. See ACTIVITY-COST-LINKS.md (needs scripts/activity-cost-links.sql).
2. **Past records still say "Fungicide"** for inputs saved before this fix. The true category is not recorded, so I did not guess.
3. **Closed-cycle protection is in the app only.** Someone using the database directly could still write to a closed cycle.
4. **Sales are not in the JSON backup**, nor are plots, soil tests and personal expenses.
5. **Stock count** uses harvest `total_kg`; a harvest saved without a weight reads as zero stock. Not changed.
6. **Not yet checked:** season setup for the first cycle of a new farm, the schedule/planting-date logic across multiple blocks on a real device, and offline replay of each form.
